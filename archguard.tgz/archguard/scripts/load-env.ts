import fs from "node:fs";
import path from "node:path";

// Tiny .env loader for scripts (Next.js loads .env itself for the web app).
const file = path.resolve(process.cwd(), ".env");
if (fs.existsSync(file)) {
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)$/.exec(line);
    if (!m || line.trim().startsWith("#")) continue;
    const key = m[1]!;
    const val = m[2]!.replace(/\s+#.*$/, "").trim();
    process.env[key] ??= val;
  }
}
