import "./load-env";
import pg from "pg";
import { runMigrations } from "../src/db/migrate";

async function main() {
  const url = process.env.DATABASE_OWNER_URL ?? "postgres://postgres:postgres@localhost:5432/archguard";
  const client = new pg.Client({ connectionString: url });
  await client.connect();
  try {
    const applied = await runMigrations({
      exec: (s) => client.query(s),
      query: (s, p) => client.query(s, p as unknown[]) as Promise<{ rows: Record<string, unknown>[] }>,
    });
    const appPw = process.env.APP_DB_PASSWORD;
    if (appPw) await client.query(`ALTER ROLE archguard_app PASSWORD '${appPw.replace(/'/g, "''")}'`);
    console.log(applied.length ? `Applied: ${applied.join(", ")}` : "Database is up to date");
  } finally {
    await client.end();
  }
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
