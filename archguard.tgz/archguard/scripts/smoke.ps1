# Local smoke test: starts the production build on port 3055, probes key routes, then stops it.
# Usage: npm run build; powershell -ExecutionPolicy Bypass -File scripts/smoke.ps1
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
$resultFile = Join-Path $PSScriptRoot "..\smoke-results.txt"
if (-not $env:TOKEN_ENCRYPTION_KEY) { $env:TOKEN_ENCRYPTION_KEY = [Convert]::ToBase64String((1..32 | ForEach-Object { 7 })) }
if (-not $env:AUTH_SECRET) { $env:AUTH_SECRET = "smoke-secret" }
$base = "http://localhost:3055"
$srv = Start-Process -FilePath "npx.cmd" -ArgumentList "next", "start", "-p", "3055" -PassThru -WindowStyle Hidden

for ($i = 0; $i -lt 40; $i++) {
  Start-Sleep 2
  try { Invoke-WebRequest "$base/signin" -UseBasicParsing -TimeoutSec 3 | Out-Null; break } catch {}
}

function Probe($path, $method = "GET") {
  try {
    $params = @{ Uri = "$base$path"; Method = $method; UseBasicParsing = $true; MaximumRedirection = 0; ErrorAction = "Stop"; TimeoutSec = 15 }
    if ($method -eq "POST") { $params.Body = "{}" }
    $r = Invoke-WebRequest @params
    return "$method $path -> $($r.StatusCode)"
  } catch {
    $resp = $_.Exception.Response
    if ($resp) { return "$method $path -> $([int]$resp.StatusCode) $($resp.Headers['Location'])" }
    return "$method $path -> ERROR $($_.Exception.Message)"
  }
}

$results = @(
  (Probe "/help"), (Probe "/help/getting-started"), (Probe "/help/troubleshooting-faq"),
  (Probe "/help?q=webhook"), (Probe "/help/nope"), (Probe "/signin"),
  (Probe "/"), (Probe "/settings"), (Probe "/api/health"), (Probe "/api/webhooks/bitbucket" "POST"),
  (Probe "/api/webhooks/github" "POST"), (Probe "/help/connect-github"), (Probe "/help/cloud-deployment")
)
try {
  $c = (Invoke-WebRequest "$base/help/connect-bitbucket" -UseBasicParsing -TimeoutSec 15).Content
  $results += "connect-bitbucket page contains 'Workspace Access Token': $($c -match 'Workspace Access Token')"
  $s = (Invoke-WebRequest "$base/help?q=webhook" -UseBasicParsing -TimeoutSec 15).Content
  # React SSR separates text nodes with <!-- --> comments, so strip them before matching.
  $plain = $s -replace "<!-- -->", ""
  $results += "help search returns results: $($plain -match '[1-9]\d* results? for')"
} catch { $results += "content checks failed: $($_.Exception.Message)" }

Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -Filter "name='node.exe'" | Where-Object { $_.CommandLine -match "next" -and $_.CommandLine -match "3055" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

$results | Set-Content -Path $resultFile
$results | ForEach-Object { Write-Output $_ }
