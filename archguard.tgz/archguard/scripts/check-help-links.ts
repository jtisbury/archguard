import { checkHelp, loadHelpPages } from "../src/help/content";

const pages = loadHelpPages();
const problems = checkHelp(pages);
if (problems.length) {
  console.error(`Help check failed:\n - ${problems.join("\n - ")}`);
  process.exit(1);
}
console.log(`Help check passed: ${pages.length} pages, all internal links and anchors resolve.`);
