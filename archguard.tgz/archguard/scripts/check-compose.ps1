# Static check of docker-compose.prod.yml (no Docker needed): only migrate gets owner credentials,
# only Caddy publishes ports. Usage: powershell -File scripts/check-compose.ps1
$ErrorActionPreference = "Stop"
$json = & npx.cmd -y js-yaml@4 (Join-Path $PSScriptRoot "..\docker-compose.prod.yml") | Out-String
$c = $json | ConvertFrom-Json
$fail = @()
foreach ($s in "app", "worker") {
  $e = $c.services.$s.environment
  if ($e.DATABASE_OWNER_URL -or $e.POSTGRES_PASSWORD -or $e.APP_DB_PASSWORD) { $fail += "$s receives owner credentials" }
  if (-not $e.DATABASE_URL) { $fail += "$s has no DATABASE_URL" }
}
$m = $c.services.migrate.environment
if (-not $m.DATABASE_OWNER_URL -or -not $m.APP_DB_PASSWORD) { $fail += "migrate lacks owner credentials" }
if ($m.POSTGRES_PASSWORD) { $fail += "migrate receives raw POSTGRES_PASSWORD" }
foreach ($name in $c.services.PSObject.Properties.Name) {
  if ($name -ne "caddy" -and $c.services.$name.ports) { $fail += "$name publishes ports" }
}
if ($fail.Count) { Write-Output "Compose check FAILED:"; $fail | ForEach-Object { Write-Output " - $_" }; exit 1 }
Write-Output "Compose check passed: owner credentials only in migrate; only caddy publishes ports ($($c.services.caddy.ports -join ', '))."
