import "./load-env";
import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { sql } from "drizzle-orm";
import { schema } from "../src/db/schema";
import { withTenant, type Db } from "../src/db/client";
import { seedStarterRules } from "../src/rules/starter";

/**
 * Bootstraps organizations (owner role only; the app role cannot create orgs) and seeds the
 * five starter guardrails for every existing org. Usage: npm run db:seed -- <slug> "<Name>"
 */
async function main() {
  const [slug = process.env.AUTH_DEFAULT_ORG_SLUG ?? "pilot", name = "Pilot Organization"] = process.argv.slice(2);
  const pool = new pg.Pool({ connectionString: process.env.DATABASE_OWNER_URL ?? "postgres://postgres:postgres@localhost:5432/archguard" });
  const db = drizzle(pool, { schema }) as unknown as Db;
  try {
    await db.execute(sql`insert into organizations (name, slug) values (${name}, ${slug}) on conflict (slug) do nothing`);
    const orgs = await db.select({ id: schema.organizations.id, slug: schema.organizations.slug }).from(schema.organizations);
    for (const o of orgs) {
      const n = await withTenant(db, o.id, (tx) => seedStarterRules(tx, o.id));
      console.log(`org ${o.slug}: ${n} starter rule(s) added`);
    }
  } finally {
    await pool.end();
  }
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
