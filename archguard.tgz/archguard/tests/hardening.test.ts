import { afterAll, beforeAll, describe, expect, it } from "vitest";
import fc from "fast-check";
import { withTenant } from "../src/db/client";
import { adrDrafts, guardrailRules, organizationMembers, organizations, prEvaluations, repositories, users } from "../src/db/schema";
import { redact, logger, sink } from "../src/lib/logger";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";

describe("PROPERTY: RLS tenant isolation across all tenant tables", () => {
  let t: TestDb;
  let orgs: string[] = [];
  beforeAll(async () => {
    t = await createTestDb();
    orgs = [(await createOrg(t, "t1")).id, (await createOrg(t, "t2")).id, (await createOrg(t, "t3")).id];
    const [u] = await t.owner((db) => db.insert(users).values({ email: "u@x.io" }).returning());
    for (const org of orgs) {
      await withTenant(t.db, org, async (tx) => {
        await tx.insert(organizationMembers).values({ orgId: org, userId: u!.id, role: "viewer" });
      });
    }
  });
  afterAll(() => t.close());

  it("whatever each tenant writes, every tenant reads back exactly its own rows and nothing else", async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.array(fc.record({ tenant: fc.integer({ min: 0, max: 2 }), rules: fc.integer({ min: 0, max: 3 }), evals: fc.integer({ min: 0, max: 3 }) }), { minLength: 1, maxLength: 4 }),
        async (ops) => {
          const expected = new Map<string, { rules: number; evals: number }>();
          for (const o of ops) {
            const org = orgs[o.tenant]!;
            const tag = crypto.randomUUID();
            await withTenant(t.db, org, async (tx) => {
              const [repo] = await tx.insert(repositories).values({ orgId: org, scmRepoId: tag, repoSlug: tag, fullName: tag }).returning();
              for (let i = 0; i < o.rules; i++) await tx.insert(guardrailRules).values({ orgId: org, name: `${tag}-${i}`, severity: "warning", rulePrompt: "p" });
              for (let i = 0; i < o.evals; i++) {
                const [ev] = await tx.insert(prEvaluations).values({ orgId: org, repoId: repo!.id, prId: i, commitSha: "c", status: "passed" }).returning();
                await tx.insert(adrDrafts).values({ orgId: org, repoId: repo!.id, evaluationId: ev!.id, adrNumber: i + 1, title: tag, markdownContent: "m" });
              }
            });
            const cur = expected.get(org) ?? { rules: 0, evals: 0 };
            expected.set(org, { rules: cur.rules + o.rules, evals: cur.evals + o.evals });
          }
          for (const org of orgs) {
            const seen = await withTenant(t.db, org, async (tx) => ({
              rules: (await tx.select().from(guardrailRules)).filter((r) => r.orgId !== org),
              evalsForeign: (await tx.select().from(prEvaluations)).filter((r) => r.orgId !== org),
              draftsForeign: (await tx.select().from(adrDrafts)).filter((r) => r.orgId !== org),
              reposForeign: (await tx.select().from(repositories)).filter((r) => r.orgId !== org),
              members: await tx.select().from(organizationMembers),
              orgRows: await tx.select().from(organizations),
            }));
            expect(seen.rules).toHaveLength(0);
            expect(seen.evalsForeign).toHaveLength(0);
            expect(seen.draftsForeign).toHaveLength(0);
            expect(seen.reposForeign).toHaveLength(0);
            expect(seen.members.every((m) => m.orgId === org)).toBe(true);
            expect(seen.orgRows.map((o) => o.id)).toEqual([org]);
          }
          return true;
        },
      ),
      { numRuns: 8 },
    );
  });
});

describe("log redaction", () => {
  it("redacts diff, token, secret and content-like keys and truncates long strings", () => {
    const out = redact({ diff: "SECRET CODE", apiKey: "k", nested: { Authorization: "Bearer x", webhookSecret: "s", markdown: "# adr", ok: "fine" }, long: "x".repeat(1000) }) as any;
    expect(out.diff).toBe("[REDACTED]");
    expect(out.apiKey).toBe("[REDACTED]");
    expect(out.nested).toEqual({ Authorization: "[REDACTED]", webhookSecret: "[REDACTED]", markdown: "[REDACTED]", ok: "fine" });
    expect(out.long.length).toBeLessThan(400);
  });
  it("logger writes redacted JSON lines", () => {
    const lines: string[] = [];
    const orig = sink.write;
    process.env.LOG_LEVEL = "info";
    sink.write = (l) => void lines.push(l);
    try {
      logger.info("hello", { diff: "TOP SECRET", repoId: "r1", error: new Error("boom") });
    } finally {
      sink.write = orig;
      process.env.LOG_LEVEL = "silent";
    }
    const rec = JSON.parse(lines[0]!);
    expect(rec).toMatchObject({ msg: "hello", diff: "[REDACTED]", repoId: "r1", error: { message: "boom" } });
    expect(lines[0]).not.toContain("TOP SECRET");
  });
});
