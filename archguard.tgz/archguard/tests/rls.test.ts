import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { sql } from "drizzle-orm";
import { rowsOf, withTenant } from "../src/db/client";
import { adrDrafts, guardrailRules, organizations, prEvaluations, repositories } from "../src/db/schema";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";

let t: TestDb;
let orgA: { id: string };
let orgB: { id: string };

beforeAll(async () => {
  t = await createTestDb();
  orgA = await createOrg(t, "org-a");
  orgB = await createOrg(t, "org-b");
  for (const [org, label] of [[orgA, "A"], [orgB, "B"]] as const) {
    await withTenant(t.db, org.id, async (tx) => {
      const [repo] = await tx
        .insert(repositories)
        .values({ orgId: org.id, scmRepoId: `{repo-${label}}`, repoSlug: `r${label}`, fullName: `w/r${label}` })
        .returning();
      await tx.insert(guardrailRules).values({ orgId: org.id, name: `rule-${label}`, severity: "blocking", rulePrompt: "p" });
      const [ev] = await tx
        .insert(prEvaluations)
        .values({ orgId: org.id, repoId: repo!.id, prId: 1, commitSha: "abc", status: "passed" })
        .returning();
      await tx.insert(adrDrafts).values({ orgId: org.id, repoId: repo!.id, evaluationId: ev!.id, adrNumber: 1, title: "t", markdownContent: "m" });
    });
  }
});
afterAll(() => t.close());

describe("row level security", () => {
  it("each tenant sees only its own rows in every tenant table", async () => {
    for (const table of [repositories, guardrailRules, prEvaluations, adrDrafts]) {
      const rows = await withTenant(t.db, orgA.id, (tx) => tx.select().from(table));
      expect(rows.length).toBe(1);
      expect(rows.every((r) => (r as { orgId: string }).orgId === orgA.id)).toBe(true);
    }
    const orgs = await withTenant(t.db, orgB.id, (tx) => tx.select().from(organizations));
    expect(orgs.map((o) => o.id)).toEqual([orgB.id]);
  });

  it("returns nothing without a tenant context", async () => {
    const rows = await t.db.select().from(repositories);
    expect(rows).toEqual([]);
    const orgs = await t.db.select().from(organizations);
    expect(orgs).toEqual([]);
  });

  it("blocks writing rows for another tenant", async () => {
    await expect(
      withTenant(t.db, orgA.id, (tx) =>
        tx.insert(guardrailRules).values({ orgId: orgB.id, name: "evil", severity: "warning", rulePrompt: "x" }),
      ),
    ).rejects.toThrow();
  });

  it("cannot update or delete another tenant's rows", async () => {
    await withTenant(t.db, orgA.id, async (tx) => {
      await tx.update(guardrailRules).set({ name: "hijack" });
      await tx.delete(adrDrafts);
    });
    const rulesB = await withTenant(t.db, orgB.id, (tx) => tx.select().from(guardrailRules));
    expect(rulesB[0]?.name).toBe("rule-B");
    const draftsB = await withTenant(t.db, orgB.id, (tx) => tx.select().from(adrDrafts));
    expect(draftsB.length).toBe(1);
  });

  it("tenant context does not leak after the transaction ends", async () => {
    await withTenant(t.db, orgA.id, (tx) => tx.select().from(repositories));
    const res = await t.db.execute(sql`select app_org_id() as id`);
    expect(rowsOf<{ id: string | null }>(res)[0]!.id).toBeNull();
  });

  it("rejects malformed tenant ids", async () => {
    await expect(withTenant(t.db, "x'; drop table organizations;--", async () => 1)).rejects.toThrow(/invalid/);
  });

  it("app role cannot create organizations", async () => {
    await expect(t.db.insert(organizations).values({ name: "x", slug: "x" })).rejects.toThrow();
  });
});
