import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { GitHubAdapter, nextLink } from "../src/github/adapter";
import { DiffTooLargeError, ScmError } from "../src/scm/provider";
import { ingestWebhook, readDelivery } from "../src/webhooks/ingest";
import { signBody } from "../src/webhooks/signature";
import { connectScm, enableRepository } from "../src/services/connection";
import { withTenant } from "../src/db/client";
import { repositories } from "../src/db/schema";
import { processEvaluation, type EvaluateDeps } from "../src/worker/evaluate";
import type { DedupeStore, EvaluateJob } from "../src/queue/types";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";
import { FakeProvider } from "./helpers/fakeProvider";
import { FakeLlm } from "./helpers/fakeLlm";

type Call = { url: string; method: string; headers: Headers; body: unknown };
function mock(responder: (c: Call) => Response | Promise<Response>, owner = "acme") {
  const calls: Call[] = [];
  const fetchImpl = (async (url: string | URL | Request, init?: RequestInit) => {
    const call: Call = { url: String(url), method: init?.method ?? "GET", headers: new Headers(init?.headers), body: init?.body };
    calls.push(call);
    return responder(call);
  }) as typeof fetch;
  return { calls, gh: new GitHubAdapter({ owner, token: "ghp_x", fetchImpl, retryDelayMs: 0 }) };
}
const json = (b: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(b), { status, headers: { "content-type": "application/json", ...headers } });

describe("GitHubAdapter", () => {
  it("sends Bearer token, API version and User-Agent", async () => {
    const { calls, gh } = mock(() => json({ login: "acme" }));
    expect(await gh.validateCredentials()).toEqual({ ok: true });
    const h = calls[0]!.headers;
    expect(h.get("authorization")).toBe("Bearer ghp_x");
    expect(h.get("x-github-api-version")).toBe("2022-11-28");
    expect(h.get("user-agent")).toBe("ArchGuard");
    expect(h.get("accept")).toBe("application/vnd.github+json");
  });

  it("validates org owners and maps errors", async () => {
    const org = mock((c) => (c.url.endsWith("/user") ? json({ login: "someone" }) : json({}, 404)));
    expect(await org.gh.validateCredentials()).toMatchObject({ ok: false, reason: expect.stringMatching(/Owner not found/) });
    const bad = mock(() => json({}, 401));
    expect(await bad.gh.validateCredentials()).toMatchObject({ ok: false, reason: expect.stringMatching(/rejected/) });
  });

  it("lists user-owned vs organization repositories with Link pagination, skipping archived and foreign repos", async () => {
    const user = mock((c) => {
      if (c.url.endsWith("/user")) return json({ login: "acme" });
      if (c.url.includes("page=2")) return json([{ id: 2, name: "b", full_name: "acme/b", owner: { login: "acme" } }]);
      return json(
        [
          { id: 1, name: "a", full_name: "acme/a", owner: { login: "acme" } },
          { id: 9, name: "old", full_name: "acme/old", owner: { login: "acme" }, archived: true },
          { id: 7, name: "x", full_name: "other/x", owner: { login: "other" } },
        ],
        200,
        { link: `<https://api.github.com/user/repos?page=2>; rel="next", <https://api.github.com/user/repos?page=2>; rel="last"` },
      );
    });
    expect(await user.gh.listRepositories()).toEqual([
      { id: "1", slug: "a", fullName: "acme/a" },
      { id: "2", slug: "b", fullName: "acme/b" },
    ]);
    expect(user.calls[1]!.url).toContain("/user/repos?affiliation=owner");

    const org = mock((c) => (c.url.endsWith("/user") ? json({ login: "me" }) : json([])));
    await org.gh.listRepositories();
    expect(org.calls[1]!.url).toContain("/orgs/acme/repos");
    expect(nextLink(null)).toBeUndefined();
  });

  it("creates a pull_request webhook with a JSON payload and secret", async () => {
    const { calls, gh } = mock(() => json({ id: 4242 }, 201));
    expect(await gh.createWebhook("svc", "https://h/api/webhooks/github", "s3cret")).toEqual({ uuid: "4242" });
    const body = JSON.parse(String(calls[0]!.body));
    expect(calls[0]!.url).toBe("https://api.github.com/repos/acme/svc/hooks");
    expect(body).toMatchObject({ name: "web", active: true, events: ["pull_request"], config: { url: "https://h/api/webhooks/github", content_type: "json", secret: "s3cret", insecure_ssl: "0" } });
  });

  it("maps PR state including merged and closed", async () => {
    const base = { number: 5, title: "t", head: { ref: "feat", sha: "abc" }, base: { ref: "main" } };
    for (const [pr, state] of [[{ state: "open" }, "OPEN"], [{ state: "closed", merged: true }, "MERGED"], [{ state: "closed", merged_at: null }, "DECLINED"]] as const) {
      const { gh } = mock(() => json({ ...base, ...pr }));
      expect(await gh.getPullRequest("svc", 5)).toEqual({ id: 5, title: "t", state, sourceBranch: "feat", destinationBranch: "main", sourceCommit: "abc" });
    }
  });

  it("lists changed files, fetches the diff media type, and turns 406 into DiffTooLargeError", async () => {
    const files = mock(() => json([{ filename: "infra/main.tf", status: "renamed", previous_filename: "infra/old.tf" }]));
    expect(await files.gh.getDiffstat("svc", 5)).toEqual([{ status: "renamed", path: "infra/main.tf", oldPath: "infra/old.tf" }]);
    expect(files.calls[0]!.url).toBe("https://api.github.com/repos/acme/svc/pulls/5/files?per_page=100");

    const diff = mock(() => new Response("diff --git a/x b/x", { status: 200 }));
    expect(await diff.gh.getDiff("svc", 5)).toContain("diff --git");
    expect(diff.calls[0]!.headers.get("accept")).toBe("application/vnd.github.diff");

    const big = mock(() => new Response('{"message":"Sorry, the diff exceeded the maximum number of files (300)."}', { status: 406 }));
    await expect(big.gh.getDiff("svc", 5)).rejects.toBeInstanceOf(DiffTooLargeError);
  });

  it("posts commit statuses with the ArchGuard context and mapped states, description capped at 140", async () => {
    const { calls, gh } = mock(() => json({}, 201));
    await gh.postBuildStatus("svc", "abc", { state: "INPROGRESS", description: "x".repeat(300), refname: "feat", url: "https://ag/" });
    await gh.postBuildStatus("svc", "abc", { state: "FAILED", description: "bad", refname: "feat" });
    await gh.postBuildStatus("svc", "abc", { state: "SUCCESSFUL", description: "ok", refname: "feat" });
    const bodies = calls.map((c) => JSON.parse(String(c.body)));
    expect(calls[0]!.url).toBe("https://api.github.com/repos/acme/svc/statuses/abc");
    expect(bodies.map((b) => b.state)).toEqual(["pending", "failure", "success"]);
    expect(bodies.every((b) => b.context === "ArchGuard")).toBe(true);
    expect(bodies[0].description).toHaveLength(140);
    expect(bodies[0].target_url).toBe("https://ag/");
    expect(bodies[1].target_url).toBeUndefined();
  });

  it("creates and updates issue comments, recreating when the old one is gone", async () => {
    let patchStatus = 200;
    const { calls, gh } = mock((c) => (c.method === "PATCH" ? json({ id: 5 }, patchStatus) : json({ id: 9 }, 201)));
    expect(await gh.upsertPullRequestComment("svc", 3, "hi")).toBe("9");
    expect(calls[0]!.url).toBe("https://api.github.com/repos/acme/svc/issues/3/comments");
    expect(await gh.upsertPullRequestComment("svc", 3, "hi", "5")).toBe("5");
    expect(calls[1]!.url).toBe("https://api.github.com/repos/acme/svc/issues/comments/5");
    patchStatus = 404;
    expect(await gh.upsertPullRequestComment("svc", 3, "hi", "5")).toBe("9");
  });

  it("lists ADR files via the contents API and commits a new file with base64 content", async () => {
    const list = mock(() => json([{ name: "0001-a.md", type: "file" }, { name: "sub", type: "dir" }]));
    expect(await list.gh.listFileNames("svc", "feat/x", "/docs/adr/")).toEqual(["0001-a.md"]);
    expect(list.calls[0]!.url).toBe("https://api.github.com/repos/acme/svc/contents/docs/adr?ref=feat%2Fx");
    const missing = mock(() => json({}, 404));
    expect(await missing.gh.listFileNames("svc", "main", "docs/adr")).toEqual([]);

    const put = mock(() => json({ commit: { sha: "c0ffee" } }, 201));
    expect(await put.gh.commitFile("svc", { branch: "feat", path: "docs/adr/0002-x.md", content: "# X ✓", message: "m" })).toEqual({ commitSha: "c0ffee" });
    const body = JSON.parse(String(put.calls[0]!.body));
    expect(put.calls[0]!.method).toBe("PUT");
    expect(put.calls[0]!.url).toBe("https://api.github.com/repos/acme/svc/contents/docs/adr/0002-x.md");
    expect(Buffer.from(body.content, "base64").toString("utf8")).toBe("# X ✓");
    expect(body).toMatchObject({ branch: "feat", message: "m" });
  });

  it("retries on secondary rate limits and 5xx, never leaks response bodies", async () => {
    let n = 0;
    const flaky = mock(() => (n++ < 2 ? new Response("", { status: 403, headers: { "x-ratelimit-remaining": "0" } }) : json({ default_branch: "trunk" })));
    expect(await flaky.gh.getMainBranch("svc")).toBe("trunk");
    const bad = mock(() => new Response("SOURCE LEAK", { status: 422 }));
    const err = await bad.gh.getMainBranch("svc").catch((e) => e);
    expect(err).toBeInstanceOf(ScmError);
    expect(err.message).not.toContain("LEAK");
  });
});

class MemDedupe implements DedupeStore {
  keys = new Set<string>();
  async set(key: string) {
    if (this.keys.has(key)) return null;
    this.keys.add(key);
    return "OK" as const;
  }
  async del(key: string) {
    return this.keys.delete(key) ? 1 : 0;
  }
}

describe("GitHub webhook ingestion", () => {
  let t: TestDb;
  let orgId: string;
  let repoId: string;
  let hookId: string;
  let secret: string;
  const gh = new FakeProvider("github");
  gh.repos = [{ id: "555", slug: "svc", fullName: "acme/svc" }];

  beforeAll(async () => {
    t = await createTestDb();
    orgId = (await createOrg(t, "acme")).id;
    await connectScm(t.db, orgId, { provider: "github", owner: "acme", token: "ghp" }, () => gh);
    const [repo] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    repoId = repo!.id;
    hookId = (await enableRepository(t.db, orgId, repoId, gh, "https://x/api/webhooks/github")).webhookUuid;
    secret = gh.hooks.get(hookId)!.secret;
  });
  afterAll(() => t.close());

  const deliver = (payload: object, over: Record<string, string | undefined> = {}, queue: EvaluateJob[] = [], dedupe = new MemDedupe()) => {
    const raw = JSON.stringify(payload);
    const h: Record<string, string | undefined> = {
      "x-github-event": "pull_request",
      "x-github-hook-id": hookId,
      "x-github-delivery": "d-1",
      "x-hub-signature-256": signBody(raw, secret),
      "x-hub-signature": "sha1=ignored",
      ...over,
    };
    return ingestWebhook(
      { rawBody: raw, headers: { get: (n) => h[n.toLowerCase()] ?? null } },
      { db: t.db, dedupe, queue: { enqueue: async (j) => void queue.push(j) } },
    );
  };

  it("reads GitHub delivery headers and never uses the SHA-1 signature", () => {
    const h: Record<string, string> = { "x-github-event": "pull_request", "x-github-hook-id": "1", "x-github-delivery": "d", "x-hub-signature": "sha1=x" };
    expect(readDelivery({ get: (n) => h[n] ?? null })).toEqual({ provider: "github", hookId: "1", signature: null, requestId: "d", event: "pull_request" });
  });

  it("accepts opened/synchronize/reopened/ready_for_review and enqueues the PR number", async () => {
    for (const action of ["opened", "synchronize", "reopened", "ready_for_review"]) {
      const q: EvaluateJob[] = [];
      expect((await deliver({ action, pull_request: { number: 12 } }, { "x-github-delivery": `d-${action}` }, q)).body).toEqual({ accepted: true });
      expect(q[0]).toEqual({ orgId, repoId, prId: 12, eventKey: "pull_request", requestUuid: `d-${action}` });
    }
  });

  it("ignores ping, closed/labeled actions and other events", async () => {
    const q: EvaluateJob[] = [];
    expect((await deliver({ zen: "hi", hook_id: 1 }, { "x-github-event": "ping" }, q)).body).toEqual({ ignored: true });
    expect((await deliver({ action: "closed", pull_request: { number: 1 } }, {}, q)).body).toEqual({ ignored: true });
    expect((await deliver({ action: "labeled", pull_request: { number: 1 } }, {}, q)).body).toEqual({ ignored: true });
    expect(q).toHaveLength(0);
  });

  it("rejects bad signatures and unknown hooks with 401", async () => {
    expect((await deliver({ action: "opened", pull_request: { number: 1 } }, { "x-hub-signature-256": "sha256=" + "0".repeat(64) })).status).toBe(401);
    expect((await deliver({ action: "opened", pull_request: { number: 1 } }, { "x-hub-signature-256": undefined })).status).toBe(401);
    expect((await deliver({ action: "opened", pull_request: { number: 1 } }, { "x-github-hook-id": "999999" })).status).toBe(401);
  });

  it("dedupes redeliveries by X-GitHub-Delivery", async () => {
    const q: EvaluateJob[] = [];
    const dedupe = new MemDedupe();
    await deliver({ action: "synchronize", pull_request: { number: 3 } }, { "x-github-delivery": "same" }, q, dedupe);
    const second = await deliver({ action: "synchronize", pull_request: { number: 3 } }, { "x-github-delivery": "same" }, q, dedupe);
    expect(second.body).toEqual({ duplicate: true });
    expect(q).toHaveLength(1);
    expect([...dedupe.keys]).toEqual(["archguard:webhook:github:same"]);
  });

  it("worker: a diff GitHub refuses (406) becomes a neutral 'too large to evaluate' result", async () => {
    gh.diffstat = [{ status: "modified", path: "infra/main.tf" }];
    gh.diffTooLarge = true;
    const llm = new FakeLlm(() => ({ violations: [], adrDraft: null }));
    const deps: EvaluateDeps = {
      db: t.db,
      makeProvider: () => gh,
      llm: () => llm,
      appBaseUrl: "https://ag.example",
      limits: { maxDiffBytes: 50_000, maxInputTokens: 50_000 },
      pilotMode: true,
    };
    const res = await processEvaluation({ orgId, repoId, prId: 7, eventKey: "pull_request", requestUuid: "w-1" }, deps);
    expect(res.status).toBe("neutral");
    expect(gh.lastStatus).toMatchObject({ state: "SUCCESSFUL", url: "https://ag.example/" });
    expect(gh.lastStatus!.description).toMatch(/too large to evaluate/);
    expect(llm.requests).toHaveLength(0);
  });
});
