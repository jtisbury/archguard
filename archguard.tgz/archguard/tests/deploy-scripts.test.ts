import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

// Static checks only: Bash is not available on the build machine, so these guard known
// pitfalls rather than executing the scripts.
const DIR = path.resolve(process.cwd(), "deploy", "vm");
const scripts = fs.readdirSync(DIR).filter((f) => f.endsWith(".sh"));
const read = (f: string) => fs.readFileSync(path.join(DIR, f), "utf8");

describe("deploy/vm scripts", () => {
  it("all four scripts exist", () => {
    expect(scripts.sort()).toEqual(["backup.sh", "deploy.sh", "duckdns-update.sh", "setup-vm.sh"]);
  });

  for (const f of scripts) {
    it(`${f}: bash shebang, strict mode, LF line endings`, () => {
      const s = read(f);
      expect(s.startsWith("#!/usr/bin/env bash\n")).toBe(true);
      expect(s).toContain("set -euo pipefail");
      expect(s).not.toContain("\r\n");
    });
  }

  it("setup-vm.sh never inserts iptables rules at a fixed position (fails on empty INPUT chains)", () => {
    const s = read("setup-vm.sh");
    expect(s).not.toMatch(/iptables -I INPUT \d/);
    expect(s).toMatch(/iptables -I INPUT "\$first_block"/);
  });

  it("setup-vm.sh only touches iptables when an existing REJECT/DROP rule is found, and never replaces ufw", () => {
    const s = read("setup-vm.sh");
    const ufwBranch = s.indexOf("ufw status");
    const iptablesInstall = s.indexOf("iptables-persistent");
    expect(ufwBranch).toBeGreaterThan(-1);
    expect(iptablesInstall).toBeGreaterThan(ufwBranch); // installed only in the non-ufw branch
    expect(s).toContain('[ -n "$first_block" ]');
    expect(s).toContain("No host firewall found");
  });

  it("setup-vm.sh works as root: no '$SUDO VAR=value cmd' assignments", () => {
    const s = read("setup-vm.sh");
    expect(s).not.toMatch(/\$SUDO [A-Z_]+=/);
    expect(s).toContain("$SUDO env DEBIAN_FRONTEND=noninteractive");
  });

  it("deploy.sh refuses to run with required secrets blank and reads the domain from .env.production", () => {
    const s = read("deploy.sh");
    for (const v of ["POSTGRES_PASSWORD", "APP_DB_PASSWORD", "TOKEN_ENCRYPTION_KEY", "AUTH_SECRET", "ARCHGUARD_DOMAIN"]) expect(s).toContain(v);
    expect(s).toContain("chmod 600 .env.production");
    expect(s).toMatch(/domain=\$\(grep -E '\^ARCHGUARD_DOMAIN='/);
  });

  it("script comments and cron examples point at deploy/vm", () => {
    for (const f of scripts) expect(read(f)).not.toContain("deploy/oci");
  });
});
