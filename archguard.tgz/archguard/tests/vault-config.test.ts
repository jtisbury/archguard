import { describe, expect, it } from "vitest";
import { randomBytes } from "node:crypto";
import { decrypt, encrypt } from "../src/lib/vault";
import { parseConfig } from "../src/lib/config";
import { canRunEvaluation } from "../src/lib/billing";

const key = () => randomBytes(32).toString("base64");

describe("vault", () => {
  it("round-trips and uses a fresh IV each time", () => {
    const k = key();
    const a = encrypt("secret-token", k);
    const b = encrypt("secret-token", k);
    expect(a).not.toBe(b);
    expect(a.startsWith("v1:")).toBe(true);
    expect(decrypt(a, k)).toBe("secret-token");
  });
  it("detects tampering", () => {
    const k = key();
    const parts = encrypt("abc", k).split(":");
    const ct = Buffer.from(parts[3]!, "base64");
    ct[0] = ct[0]! ^ 1;
    parts[3] = ct.toString("base64");
    expect(() => decrypt(parts.join(":"), k)).toThrow(/decryption failed/);
  });
  it("fails with the wrong key and rejects bad keys/payloads", () => {
    const p = encrypt("abc", key());
    expect(() => decrypt(p, key())).toThrow();
    expect(() => encrypt("abc", "short")).toThrow(/32 bytes/);
    expect(() => decrypt("v9:a:b:c", key())).toThrow(/Unsupported/);
  });
});

describe("config + billing gate", () => {
  const base = { TOKEN_ENCRYPTION_KEY: key() };
  it("requires a valid encryption key", () => {
    expect(() => parseConfig({})).toThrow(/TOKEN_ENCRYPTION_KEY/);
    expect(() => parseConfig({ TOKEN_ENCRYPTION_KEY: "abc" })).toThrow(/32 bytes/);
  });
  it("parses flags, csv lists and inline comments", () => {
    const c = parseConfig({
      ...base,
      ENTERPRISE_PILOT_MODE: "true",
      AUTH_ROLE_ADMIN_GROUPS: "a, b",
      LLM_PROVIDER: "bedrock   # comment",
    });
    expect(c.ENTERPRISE_PILOT_MODE).toBe(true);
    expect(c.AUTH_ROLE_ADMIN_GROUPS).toEqual(["a", "b"]);
    expect(c.LLM_PROVIDER).toBe("bedrock");
    expect(parseConfig(base).ENTERPRISE_PILOT_MODE).toBe(false);
  });
  it("pilot mode bypasses billing limits", () => {
    const org = { planTier: "free", monthlyEvalCount: 9999 };
    expect(canRunEvaluation(org, true)).toBe(true);
    expect(canRunEvaluation(org, false)).toBe(false);
    expect(canRunEvaluation({ planTier: "pilot", monthlyEvalCount: 9999 }, false)).toBe(true);
  });
});
