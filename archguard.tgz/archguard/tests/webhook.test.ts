import { afterAll, beforeAll, describe, expect, it } from "vitest";
import fc from "fast-check";
import RedisMock from "ioredis-mock";
import { signBody, verifySignature } from "../src/webhooks/signature";
import { ingestWebhook, DEDUPE_TTL_SECONDS } from "../src/webhooks/ingest";
import { rateLimit } from "../src/webhooks/ratelimit";
import { enableRepository } from "../src/services/connection";
import { withTenant } from "../src/db/client";
import { repositories } from "../src/db/schema";
import type { DedupeStore, EvaluateJob, EvaluateQueue } from "../src/queue/types";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";
import { FakeProvider } from "./helpers/fakeProvider";

describe("signature", () => {
  it("matches Atlassian's published test vector", () => {
    expect(signBody("Hello World!", "It's a Secret to Everybody")).toBe(
      "sha256=a4771c39fbe90f317c7824e83ddef3caae9cb3d976c214ace1f2937e133263c9",
    );
  });
  it("accepts valid and rejects tampered/missing/malformed signatures", () => {
    const sig = signBody("body", "s3cret");
    expect(verifySignature("body", sig, "s3cret")).toBe(true);
    expect(verifySignature("body ", sig, "s3cret")).toBe(false);
    expect(verifySignature("body", sig, "other")).toBe(false);
    expect(verifySignature("body", null, "s3cret")).toBe(false);
    expect(verifySignature("body", "sha1=abc", "s3cret")).toBe(false);
    expect(verifySignature("body", "sha256=zz", "s3cret")).toBe(false);
  });
});

class MemDedupe implements DedupeStore {
  keys = new Map<string, number>();
  async set(key: string, _v: string, _m: "EX", ttl: number, _nx: "NX") {
    if (this.keys.has(key)) return null;
    this.keys.set(key, ttl);
    return "OK" as const;
  }
  async del(key: string) {
    return this.keys.delete(key) ? 1 : 0;
  }
}

describe("ingestWebhook", () => {
  let t: TestDb;
  let hookUuid: string;
  let secret: string;
  let orgId: string;
  let repoId: string;
  const queued: EvaluateJob[] = [];
  const queue: EvaluateQueue = { enqueue: async (j) => void queued.push(j) };

  const body = JSON.stringify({ pullrequest: { id: 42 } });
  const hdr = (over: Record<string, string | undefined> = {}, b = body) => {
    const h: Record<string, string | undefined> = {
      "x-hook-uuid": hookUuid,
      "x-hub-signature": signBody(b, secret),
      "x-request-uuid": "req-1",
      "x-event-key": "pullrequest:updated",
      ...over,
    };
    return { get: (n: string) => h[n.toLowerCase()] ?? null };
  };

  beforeAll(async () => {
    t = await createTestDb();
    orgId = (await createOrg(t, "acme")).id;
    const fake = new FakeProvider();
    await withTenant(t.db, orgId, (tx) =>
      tx.insert(repositories).values({ orgId, scmRepoId: "{r1}", repoSlug: "svc", fullName: "acme/svc" }),
    );
    const [repo] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    repoId = repo!.id;
    const r = await enableRepository(t.db, orgId, repoId, fake, "https://x/api/webhooks/bitbucket");
    hookUuid = r.webhookUuid;
    secret = fake.hooks.get(hookUuid)!.secret;
  });
  afterAll(() => t.close());

  it("rejects missing, bad and unknown-hook signatures with 401 and never enqueues", async () => {
    const deps = { db: t.db, dedupe: new MemDedupe(), queue };
    expect((await ingestWebhook({ rawBody: body, headers: hdr({ "x-hub-signature": undefined }) }, deps)).status).toBe(401);
    expect((await ingestWebhook({ rawBody: body, headers: hdr({ "x-hub-signature": "sha256=" + "0".repeat(64) }) }, deps)).status).toBe(401);
    expect((await ingestWebhook({ rawBody: body, headers: hdr({ "x-hook-uuid": "{nope}" }) }, deps)).status).toBe(401);
    expect((await ingestWebhook({ rawBody: body + " ", headers: hdr() }, deps)).status).toBe(401); // body altered after signing
    expect(queued).toHaveLength(0);
  });

  it("accepts a valid delivery (hook uuid with or without braces) and enqueues the tenant-scoped job", async () => {
    const deps = { db: t.db, dedupe: new MemDedupe(), queue };
    const res = await ingestWebhook({ rawBody: body, headers: hdr({ "x-hook-uuid": hookUuid.replace(/[{}]/g, "") }) }, deps);
    expect(res.status).toBe(202);
    expect(queued.at(-1)).toEqual({ orgId, repoId, prId: 42, eventKey: "pullrequest:updated", requestUuid: "req-1" });
  });

  it("drops duplicates and uses a 24h TTL", async () => {
    const dedupe = new MemDedupe();
    const deps = { db: t.db, dedupe, queue };
    const before = queued.length;
    const a = await ingestWebhook({ rawBody: body, headers: hdr({ "x-request-uuid": "dup" }) }, deps);
    const b = await ingestWebhook({ rawBody: body, headers: hdr({ "x-request-uuid": "dup" }) }, deps);
    expect(a.body).toEqual({ accepted: true });
    expect(b.body).toEqual({ duplicate: true });
    expect(queued.length - before).toBe(1);
    expect(dedupe.keys.get("archguard:webhook:bitbucket:dup")).toBe(DEDUPE_TTL_SECONDS);
  });

  it("works with a real Redis client API (SET NX EX)", async () => {
    const redis = new RedisMock();
    const deps = { db: t.db, dedupe: redis as unknown as DedupeStore, queue };
    const before = queued.length;
    await ingestWebhook({ rawBody: body, headers: hdr({ "x-request-uuid": "redis-1" }) }, deps);
    await ingestWebhook({ rawBody: body, headers: hdr({ "x-request-uuid": "redis-1" }) }, deps);
    expect(queued.length - before).toBe(1);
    expect(await redis.ttl("archguard:webhook:bitbucket:redis-1")).toBeGreaterThan(86000);
  });

  it("ignores other events and returns 503 (and releases the key) when the queue is down", async () => {
    const deps = { db: t.db, dedupe: new MemDedupe(), queue };
    const ignored = await ingestWebhook({ rawBody: body, headers: hdr({ "x-event-key": "repo:push", "x-request-uuid": "e1" }) }, deps);
    expect(ignored).toEqual({ status: 202, body: { ignored: true } });

    const dedupe = new MemDedupe();
    const failing: EvaluateQueue = { enqueue: async () => { throw new Error("redis down"); } };
    const r = await ingestWebhook({ rawBody: body, headers: hdr({ "x-request-uuid": "e2" }) }, { db: t.db, dedupe, queue: failing });
    expect(r.status).toBe(503);
    expect(dedupe.keys.has("archguard:webhook:bitbucket:e2")).toBe(false);
  });

  it("PROPERTY: any number of repeated deliveries of one request enqueues exactly once", async () => {
    await fc.assert(
      fc.asyncProperty(fc.uuid(), fc.integer({ min: 1, max: 8 }), async (uuid, repeats) => {
        const local: EvaluateJob[] = [];
        const deps = { db: t.db, dedupe: new MemDedupe(), queue: { enqueue: async (j: EvaluateJob) => void local.push(j) } };
        for (let i = 0; i < repeats; i++) {
          await ingestWebhook({ rawBody: body, headers: hdr({ "x-request-uuid": uuid }) }, deps);
        }
        return local.length === 1;
      }),
      { numRuns: 25 },
    );
  });

  it("PROPERTY: any single-byte body mutation invalidates the signature", () => {
    fc.assert(
      fc.property(fc.string({ minLength: 1 }), fc.nat(), (b, i) => {
        const sig = signBody(b, "k");
        const idx = i % b.length;
        const mutated = b.slice(0, idx) + (b[idx] === "x" ? "y" : "x") + b.slice(idx + 1);
        return verifySignature(b, sig, "k") && !verifySignature(mutated, sig, "k");
      }),
    );
  });
});

describe("rateLimit", () => {
  it("blocks after the limit within a window", async () => {
    const redis = new RedisMock();
    const results: boolean[] = [];
    for (let i = 0; i < 5; i++) results.push(await rateLimit(redis as never, "ip:1", 3, 1_000_000));
    expect(results).toEqual([true, true, true, false, false]);
    expect(await rateLimit(redis as never, "ip:2", 3, 1_000_000)).toBe(true);
  });
});
