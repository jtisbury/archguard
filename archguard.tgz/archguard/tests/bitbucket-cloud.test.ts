import { describe, expect, it } from "vitest";
import { BitbucketCloudAdapter } from "../src/bitbucket/cloud";
import { BitbucketDataCenterAdapter } from "../src/bitbucket/datacenter";
import { ScmError as BitbucketError } from "../src/scm/provider";

type Call = { url: string; method: string; headers: Headers; body: unknown };

function mock(responder: (c: Call) => Response | Promise<Response>) {
  const calls: Call[] = [];
  const fetchImpl = (async (url: string | URL | Request, init?: RequestInit) => {
    const call: Call = { url: String(url), method: init?.method ?? "GET", headers: new Headers(init?.headers), body: init?.body };
    calls.push(call);
    return responder(call);
  }) as typeof fetch;
  return { calls, adapter: new BitbucketCloudAdapter({ workspace: "acme", token: "tok", fetchImpl, retryDelayMs: 0 }) };
}
const json = (b: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(b), { status, headers: { "content-type": "application/json", ...headers } });

describe("BitbucketCloudAdapter", () => {
  it("sends the workspace token as a Bearer header", async () => {
    const { calls, adapter } = mock(() => json({ values: [] }));
    await adapter.validateCredentials();
    expect(calls[0]!.headers.get("authorization")).toBe("Bearer tok");
  });

  it("maps credential failures to readable reasons", async () => {
    for (const [status, text] of [[401, /rejected/], [403, /scope/], [404, /not found/]] as const) {
      const { adapter } = mock(() => json({}, status));
      const r = await adapter.validateCredentials();
      expect(r.ok).toBe(false);
      if (!r.ok) expect(r.reason).toMatch(text);
    }
  });

  it("follows pagination for repositories and diffstat", async () => {
    const { calls, adapter } = mock((c) => {
      if (c.url.includes("/diffstat")) {
        return c.url.includes("page=2")
          ? json({ values: [{ status: "removed", old: { path: "b.tf" }, new: null }] })
          : json({ values: [{ status: "modified", old: { path: "a.tf" }, new: { path: "a.tf" } }], next: c.url + "&page=2" });
      }
      return c.url.includes("page=2")
        ? json({ values: [{ uuid: "{2}", slug: "b", full_name: "acme/b" }] })
        : json({ values: [{ uuid: "{1}", slug: "a", full_name: "acme/a" }], next: c.url + "&page=2" });
    });
    expect((await adapter.listRepositories()).map((r) => r.slug)).toEqual(["a", "b"]);
    const stat = await adapter.getDiffstat("a", 7);
    expect(stat.map((s) => s.path)).toEqual(["a.tf", "b.tf"]);
    expect(calls.length).toBe(4);
  });

  it("posts build status with the fixed ARCHGUARD key and refname (same key overwrites)", async () => {
    const { calls, adapter } = mock(() => json({}));
    await adapter.postBuildStatus("repo", "abc", { state: "INPROGRESS", description: "x", refname: "feature/x" });
    await adapter.postBuildStatus("repo", "abc", { state: "SUCCESSFUL", description: "y", refname: "feature/x" });
    expect(calls.every((c) => c.url.endsWith("/repositories/acme/repo/commit/abc/statuses/build"))).toBe(true);
    const bodies = calls.map((c) => JSON.parse(String(c.body)));
    expect(bodies.map((b) => b.key)).toEqual(["ARCHGUARD", "ARCHGUARD"]);
    expect(bodies[1]).toMatchObject({ state: "SUCCESSFUL", refname: "feature/x" });
  });

  it("creates then updates a PR comment, recreating it if the old one is gone", async () => {
    let putStatus = 200;
    const { calls, adapter } = mock((c) => (c.method === "PUT" ? json({ id: 5 }, putStatus) : json({ id: 9 })));
    expect(await adapter.upsertPullRequestComment("r", 1, "hello")).toBe("9");
    expect(await adapter.upsertPullRequestComment("r", 1, "again", "5")).toBe("5");
    putStatus = 404;
    expect(await adapter.upsertPullRequestComment("r", 1, "again", "5")).toBe("9");
    expect(calls.map((c) => c.method)).toEqual(["POST", "PUT", "PUT", "POST"]);
  });

  it("commits a file with multipart/form-data using the path as the field name", async () => {
    const { calls, adapter } = mock(() => new Response(null, { status: 201, headers: { location: "https://api.bitbucket.org/2.0/repositories/acme/r/commit/deadbeef" } }));
    const res = await adapter.commitFile("r", { branch: "feature/x", path: "docs/adr/0001-x.md", content: "# X", message: "ADR" });
    expect(res.commitSha).toBe("deadbeef");
    const c = calls[0]!;
    expect(c.url).toBe("https://api.bitbucket.org/2.0/repositories/acme/r/src");
    expect(c.method).toBe("POST");
    const form = c.body as FormData;
    expect(form.get("docs/adr/0001-x.md")).toBe("# X");
    expect(form.get("branch")).toBe("feature/x");
    expect(form.get("message")).toBe("ADR");
    expect(c.headers.get("content-type")).toBeNull(); // fetch sets the multipart boundary
  });

  it("lists ADR file names and treats a missing directory as empty", async () => {
    const ok = mock(() => json({ values: [{ path: "docs/adr/0001-a.md", type: "commit_file" }, { path: "docs/adr/sub", type: "commit_directory" }] }));
    expect(await ok.adapter.listFileNames("r", "main", "docs/adr")).toEqual(["0001-a.md"]);
    const missing = mock(() => json({}, 404));
    expect(await missing.adapter.listFileNames("r", "main", "docs/adr")).toEqual([]);
  });

  it("retries 5xx then succeeds, and surfaces errors without bodies", async () => {
    let n = 0;
    const flaky = mock(() => (n++ < 2 ? new Response("boom with secret code", { status: 503 }) : json({ values: [] })));
    await expect(flaky.adapter.listRepositories()).resolves.toEqual([]);
    const bad = mock(() => new Response("SOURCE CODE LEAK", { status: 400 }));
    const err = await bad.adapter.getDiff("r", 1).catch((e) => e);
    expect(err).toBeInstanceOf(BitbucketError);
    expect(String(err.message)).not.toContain("LEAK");
  });

  it("treats a 404 on webhook delete as success", async () => {
    const { adapter } = mock(() => json({}, 404));
    await expect(adapter.deleteWebhook("r", "{h}")).resolves.toBeUndefined();
  });
});

describe("BitbucketDataCenterAdapter", () => {
  it("is a stub that throws not implemented", async () => {
    await expect(new BitbucketDataCenterAdapter().listRepositories()).rejects.toThrow(/not implemented/i);
  });
});
