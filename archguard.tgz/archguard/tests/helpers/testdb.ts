import { PGlite } from "@electric-sql/pglite";
import { drizzle } from "drizzle-orm/pglite";
import { sql } from "drizzle-orm";
import { runMigrations } from "../../src/db/migrate";
import { schema } from "../../src/db/schema";
import type { Db } from "../../src/db/client";

export interface TestDb {
  /** App-role handle: RLS enforced, exactly like production. */
  db: Db;
  /** Owner (superuser) handle for bootstrap tasks such as creating organizations. */
  owner: <T>(fn: (db: Db) => Promise<T>) => Promise<T>;
  close: () => Promise<void>;
}

/** In-process Postgres (PGlite) with real migrations and the restricted app role. */
export async function createTestDb(): Promise<TestDb> {
  const pg = new PGlite();
  await runMigrations({
    exec: (s) => pg.exec(s),
    query: (s, p) => pg.query(s, p as unknown[]) as Promise<{ rows: Record<string, unknown>[] }>,
  });
  const db = drizzle(pg, { schema }) as unknown as Db;
  const owner = async <T>(fn: (db: Db) => Promise<T>): Promise<T> => {
    await pg.exec("RESET ROLE");
    try {
      return await fn(db);
    } finally {
      await pg.exec("SET ROLE archguard_app");
    }
  };
  await pg.exec("SET ROLE archguard_app");
  return { db, owner, close: () => pg.close() };
}

export async function createOrg(t: TestDb, slug: string, extra: Partial<typeof schema.organizations.$inferInsert> = {}) {
  return t.owner(async (db) => {
    const [org] = await db
      .insert(schema.organizations)
      .values({ name: slug.toUpperCase(), slug, ...extra })
      .returning();
    return org!;
  });
}

export { sql };
