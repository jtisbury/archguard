import {
  DiffTooLargeError,
  ScmError,
  type BuildStatusInput,
  type CommitFileInput,
  type DiffstatEntry,
  type IScmProvider,
  type PullRequestInfo,
  type RepoInfo,
  type ScmProviderKind,
} from "../../src/scm/provider";

/** In-memory SCM used by service and worker tests. Records every write. */
export class FakeProvider implements IScmProvider {
  constructor(public kind: ScmProviderKind = "bitbucket_cloud") {}
  repos: RepoInfo[] = [];
  diffTooLarge = false;
  validOk = true;
  mainBranch = "main";
  adrFiles: string[] = [];
  pr: PullRequestInfo = { id: 7, title: "Add infra", state: "OPEN", sourceBranch: "feature/x", destinationBranch: "main", sourceCommit: "sha123" };
  diffstat: DiffstatEntry[] = [];
  diff = "";
  hooks = new Map<string, { slug: string; url: string; secret: string }>();
  statuses: { sha: string; status: BuildStatusInput }[] = [];
  comments: { id: string; prId: number; body: string }[] = [];
  commits: { slug: string; input: CommitFileInput }[] = [];
  failDiff = false;
  commitFailsWithStatus: number | null = null;
  private seq = 0;

  async validateCredentials() {
    return this.validOk ? { ok: true as const } : { ok: false as const, reason: "bad token" };
  }
  async listRepositories() {
    return this.repos;
  }
  async getMainBranch() {
    return this.mainBranch;
  }
  async createWebhook(slug: string, url: string, secret: string) {
    const uuid = this.kind === "github" ? String(1000 + ++this.seq) : `{hook-${++this.seq}}`;
    this.hooks.set(uuid, { slug, url, secret });
    return { uuid };
  }
  async deleteWebhook(_slug: string, uuid: string) {
    this.hooks.delete(uuid);
  }
  async getPullRequest() {
    return this.pr;
  }
  async getDiffstat() {
    return this.diffstat;
  }
  async getDiff() {
    if (this.failDiff) throw new Error("diff unavailable");
    if (this.diffTooLarge) throw new DiffTooLargeError();
    return this.diff;
  }
  async postBuildStatus(_slug: string, sha: string, status: BuildStatusInput) {
    this.statuses.push({ sha, status });
  }
  async upsertPullRequestComment(_slug: string, prId: number, body: string, existing?: string) {
    const found = existing ? this.comments.find((c) => c.id === existing) : undefined;
    if (found) {
      found.body = body;
      return found.id;
    }
    const id = String(100 + ++this.seq);
    this.comments.push({ id, prId, body });
    return id;
  }
  async listFileNames() {
    return this.adrFiles;
  }
  async commitFile(slug: string, input: CommitFileInput) {
    if (this.commitFailsWithStatus) {
      throw new ScmError("commit failed", this.commitFailsWithStatus);
    }
    this.commits.push({ slug, input });
    return { commitSha: `commit-${this.commits.length}` };
  }
  get lastStatus() {
    return this.statuses[this.statuses.length - 1]?.status;
  }
}
