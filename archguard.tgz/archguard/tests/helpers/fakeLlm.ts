import type { ILlmProvider, StructuredRequest, StructuredResponse } from "../../src/llm/types";

type Responder = (req: StructuredRequest, call: number) => unknown;

/** Scripted LLM: returns whatever the responder produces; records every request. */
export class FakeLlm implements ILlmProvider {
  requests: StructuredRequest[] = [];
  constructor(private respond: Responder, private tokens = 100) {}
  async generateStructured(req: StructuredRequest): Promise<StructuredResponse> {
    this.requests.push(req);
    const data = this.respond(req, this.requests.length);
    if (data instanceof Error) throw data;
    return { data, tokensUsed: this.tokens };
  }
}

export const ADR = {
  title: "Adopt Kafka for events",
  context: "We need async messaging.",
  decisionDrivers: ["Decoupling"],
  consideredOptions: [{ name: "Kafka", pros: ["scales"], cons: ["ops cost"] }],
  decisionOutcome: "Use Kafka.",
  consequences: ["Need a cluster"],
};

export const makeDiff = (files: Record<string, string>) =>
  Object.entries(files)
    .map(([p, body]) => `diff --git a/${p} b/${p}\n--- a/${p}\n+++ b/${p}\n@@ -1 +1 @@\n${body}\n`)
    .join("");
