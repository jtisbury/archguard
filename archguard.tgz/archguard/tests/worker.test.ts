import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";
import { withTenant } from "../src/db/client";
import { adrDrafts, guardrailRules, organizations, prEvaluations, repositories } from "../src/db/schema";
import { finalizeFailure, NO_IMPACT_DESCRIPTION, processEvaluation, type EvaluateDeps } from "../src/worker/evaluate";
import { STARTER_RULES, seedStarterRules } from "../src/rules/starter";
import { saveAdrDraft, maxAdrNumberFromFiles } from "../src/adr/drafts";
import { DEFAULT_STRUCTURAL_TRIGGERS } from "../src/triage/triggers";
import { sink } from "../src/lib/logger";
import type { EvaluateJob } from "../src/queue/types";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";
import { FakeProvider } from "./helpers/fakeProvider";
import { ADR, FakeLlm, makeDiff } from "./helpers/fakeLlm";

let t: TestDb;
let orgId: string;
let repoId: string;
let provider: FakeProvider;
let llm: FakeLlm;
let deps: EvaluateDeps;
let n = 0;
const job = (prId = 7): EvaluateJob => ({ orgId, repoId, prId, eventKey: "pullrequest:updated", requestUuid: `req-${++n}` });
const evals = () => withTenant(t.db, orgId, (tx) => tx.select().from(prEvaluations).orderBy(prEvaluations.createdAt));

beforeAll(async () => {
  t = await createTestDb();
  orgId = (await createOrg(t, "acme", { scmOwner: "acme" })).id;
  await withTenant(t.db, orgId, async (tx) => {
    await seedStarterRules(tx, orgId);
    const [r] = await tx
      .insert(repositories)
      .values({ orgId, scmRepoId: "{r}", repoSlug: "svc", fullName: "acme/svc", isActive: true, structuralTriggers: DEFAULT_STRUCTURAL_TRIGGERS })
      .returning();
    repoId = r!.id;
  });
});
afterAll(() => t.close());

beforeEach(() => {
  provider = new FakeProvider();
  llm = new FakeLlm(() => ({ violations: [], adrDraft: null }));
  deps = {
    db: t.db,
    makeProvider: () => provider,
    llm: () => llm,
    appBaseUrl: "http://localhost:3000",
    limits: { maxDiffBytes: 50_000, maxInputTokens: 50_000 },
    pilotMode: true,
  };
});

describe("triage (REQ-2.2)", () => {
  it("README-only PR: INPROGRESS then SUCCESSFUL 'No architectural impact detected', no diff fetch, no LLM", async () => {
    provider.diffstat = [{ status: "modified", path: "README.md" }];
    const res = await processEvaluation(job(), deps);
    expect(res.status).toBe("passed");
    expect(provider.statuses.map((s) => s.status.state)).toEqual(["INPROGRESS", "SUCCESSFUL"]);
    expect(provider.lastStatus!.description).toBe(NO_IMPACT_DESCRIPTION);
    expect(provider.statuses.every((s) => s.status.refname === "feature/x" && s.sha === "sha123")).toBe(true);
    expect(llm.requests).toHaveLength(0);
    expect((await evals()).at(-1)).toMatchObject({ status: "passed", outcomeReason: "no_structural_changes" });
  });

  it("Terraform PR stays INPROGRESS until the LLM result is in", async () => {
    provider.diffstat = [{ status: "added", path: "infra/main.tf" }];
    provider.diff = makeDiff({ "infra/main.tf": "+resource" });
    let sawInProgressOnly = false;
    llm = new FakeLlm(() => {
      sawInProgressOnly = provider.statuses.length === 1 && provider.statuses[0]!.status.state === "INPROGRESS";
      return { violations: [], adrDraft: null };
    });
    await processEvaluation(job(), deps);
    expect(sawInProgressOnly).toBe(true);
    expect(llm.requests).toHaveLength(1);
  });
});

describe("gating (REQ-2.5) and ADR drafting (REQ-2.6, 2.7)", () => {
  it("blocking violation: FAILED status, summary comment, persisted evaluation without source code", async () => {
    provider.diffstat = [{ status: "added", path: "db/migrations/001.sql" }];
    provider.diff = makeDiff({ "db/migrations/001.sql": "+DROP TABLE customers_secret_name;" });
    llm = new FakeLlm(() => ({
      violations: [{ ruleName: "Destructive Schema Migration Guard", severity: "blocking", filePath: "db/migrations/001.sql", line: 1, message: "Drops a table", remediation: "Use expand/contract" }],
      adrDraft: null,
    }));
    const res = await processEvaluation(job(), deps);
    expect(res.status).toBe("failed");
    expect(provider.lastStatus).toMatchObject({ state: "FAILED", description: "ArchGuard: 1 blocking violation" });
    expect(provider.comments).toHaveLength(1);
    expect(provider.comments[0]!.body).toContain("Destructive Schema Migration Guard");
    const row = (await evals()).at(-1)!;
    expect(row.status).toBe("failed");
    expect(row.tokensUsed).toBe(100);
    expect(JSON.stringify(row)).not.toContain("customers_secret_name"); // raw diff never persisted
    const [org] = await withTenant(t.db, orgId, (tx) => tx.select().from(organizations));
    expect(org!.monthlyEvalCount).toBeGreaterThan(0);
  });

  it("re-run updates the same PR comment instead of adding a new one", async () => {
    provider.diffstat = [{ status: "modified", path: "package.json" }];
    provider.diff = makeDiff({ "package.json": '+"dep": "1"' });
    llm = new FakeLlm(() => ({ violations: [], adrDraft: null }));
    await processEvaluation(job(21), deps);
    await processEvaluation(job(21), deps);
    expect(provider.comments).toHaveLength(1);
  });

  it("warnings only: SUCCESSFUL; dependency PR yields a pending ADR draft with a dashboard link", async () => {
    provider.diffstat = [{ status: "modified", path: "package.json" }];
    provider.diff = makeDiff({ "package.json": '+"kafkajs": "2"' });
    provider.adrFiles = ["0003-old-decision.md"];
    llm = new FakeLlm(() => ({
      violations: [{ ruleName: "New External Dependency & License Check", severity: "warning", filePath: "package.json", line: 5, message: "New dependency kafkajs", remediation: "Record an ADR" }],
      adrDraft: ADR,
    }));
    const res = await processEvaluation(job(30), deps);
    expect(res.status).toBe("passed");
    expect(provider.lastStatus!.state).toBe("SUCCESSFUL");
    const drafts = await withTenant(t.db, orgId, (tx) => tx.select().from(adrDrafts).where(eq(adrDrafts.prId, 30)));
    expect(drafts).toHaveLength(1);
    expect(drafts[0]).toMatchObject({ status: "pending", adrNumber: 4, title: ADR.title });
    expect(drafts[0]!.markdownContent).toContain("## Decision Outcome");
    expect(provider.comments.at(-1)!.body).toContain(`http://localhost:3000/adrs/${drafts[0]!.id}`);

    // Re-run for the same PR refreshes the pending draft rather than consuming number 5.
    await processEvaluation(job(30), deps);
    const again = await withTenant(t.db, orgId, (tx) => tx.select().from(adrDrafts).where(eq(adrDrafts.prId, 30)));
    expect(again).toHaveLength(1);
  });

  it("skips ADR drafting when the PR already contains an ADR file", async () => {
    provider.diffstat = [{ status: "modified", path: "package.json" }, { status: "added", path: "docs/adr/0009-x.md" }];
    provider.diff = makeDiff({ "package.json": "+x" });
    llm = new FakeLlm(() => ({ violations: [], adrDraft: ADR }));
    await processEvaluation(job(31), deps);
    const drafts = await withTenant(t.db, orgId, (tx) => tx.select().from(adrDrafts).where(eq(adrDrafts.prId, 31)));
    expect(drafts).toHaveLength(0);
  });
});

describe("neutral outcomes and resilience", () => {
  it("too large -> neutral, SUCCESSFUL 'too large to evaluate', no LLM call", async () => {
    provider.diffstat = [{ status: "modified", path: "infra/main.tf" }];
    provider.diff = makeDiff({ "infra/main.tf": "+" + "x".repeat(100_000) });
    const res = await processEvaluation(job(40), deps);
    expect(res.status).toBe("neutral");
    expect(provider.lastStatus).toMatchObject({ state: "SUCCESSFUL" });
    expect(provider.lastStatus!.description).toMatch(/too large to evaluate/);
    expect(llm.requests).toHaveLength(0);
    expect((await evals()).at(-1)!.outcomeReason).toBe("too_large");
  });

  it("invalid LLM output twice -> neutral", async () => {
    provider.diffstat = [{ status: "modified", path: "infra/main.tf" }];
    provider.diff = makeDiff({ "infra/main.tf": "+x" });
    llm = new FakeLlm(() => "not json object");
    expect((await processEvaluation(job(41), deps)).status).toBe("neutral");
  });

  it("infrastructure errors throw (so BullMQ retries) and finalizeFailure never leaves INPROGRESS stuck", async () => {
    provider.diffstat = [{ status: "modified", path: "infra/main.tf" }];
    provider.failDiff = true;
    const j = job(42);
    await expect(processEvaluation(j, deps)).rejects.toThrow("diff unavailable");
    expect(provider.lastStatus!.state).toBe("INPROGRESS");
    await finalizeFailure(j, deps);
    expect(provider.lastStatus).toMatchObject({ state: "SUCCESSFUL" });
    expect(provider.lastStatus!.description).toMatch(/neutral/);
    expect((await evals()).at(-1)).toMatchObject({ status: "neutral", outcomeReason: "evaluation_error" });
  });

  it("retry of the same request does not duplicate the evaluation row", async () => {
    provider.diffstat = [{ status: "modified", path: "README.md" }];
    const j = job(43);
    await processEvaluation(j, deps);
    await processEvaluation(j, deps);
    const rows = (await evals()).filter((e) => e.prId === 43);
    expect(rows).toHaveLength(1);
  });

  it("skips closed PRs and inactive repositories", async () => {
    provider.pr = { ...provider.pr, state: "MERGED" };
    expect((await processEvaluation(job(44), deps)).status).toBe("skipped");
    expect(provider.statuses).toHaveLength(0);
  });

  it("never logs the diff", async () => {
    const lines: string[] = [];
    const orig = sink.write;
    process.env.LOG_LEVEL = "debug";
    sink.write = (l) => void lines.push(l);
    try {
      provider.diffstat = [{ status: "modified", path: "infra/main.tf" }];
      provider.diff = makeDiff({ "infra/main.tf": "+TOP_SECRET_CODE" });
      llm = new FakeLlm(() => ({ nope: 1 }));
      await processEvaluation(job(45), deps);
    } finally {
      sink.write = orig;
      process.env.LOG_LEVEL = "silent";
    }
    expect(lines.length).toBeGreaterThan(0);
    expect(lines.join("\n")).not.toContain("TOP_SECRET_CODE");
  });
});

describe("ADR numbering", () => {
  it("parses highest number from file names", () => {
    expect(maxAdrNumberFromFiles(["0001-a.md", "0012_b.md", "README.md"])).toBe(12);
  });
  it("concurrent drafts for different PRs get distinct, increasing numbers", async () => {
    const evs = await evals();
    const results = await Promise.all([200, 201, 202, 203].map((p) => saveAdrDraft(t.db, orgId, { repoId, prId: p, evaluationId: evs[0]!.id, data: ADR, existingFileNames: ["0100-x.md"] })));
    const nums = results.map((r) => r.adrNumber).sort((a, b) => a - b);
    expect(new Set(nums).size).toBe(4);
    expect(nums[0]).toBeGreaterThan(100);
  });
});

describe("starter rule library (Task 13)", () => {
  it("seeds five rules once per org", async () => {
    const rules = await withTenant(t.db, orgId, (tx) => tx.select().from(guardrailRules));
    expect(rules).toHaveLength(5);
    expect(await withTenant(t.db, orgId, (tx) => seedStarterRules(tx, orgId))).toBe(0);
    expect(STARTER_RULES.map((r) => r.name)).toEqual([
      "No Cross-Domain Database Coupling",
      "Breaking API Contract Detection",
      "Unapproved Cloud / IaC Provisioning",
      "Destructive Schema Migration Guard",
      "New External Dependency & License Check",
    ]);
  });

  // Each starter rule's sample diff must reach the model with its rule included, and the contract
  // result must come back as a violation. (Live-model quality is checked separately, see below.)
  const samples: [string, string, string][] = [
    ["No Cross-Domain Database Coupling", "services/orders/repo.ts", "+import { Customer } from '../../billing/entities/customer';"],
    ["Breaking API Contract Detection", "api/openapi.yaml", "-        email:\n-          type: string"],
    ["Unapproved Cloud / IaC Provisioning", "infra/sg.tf", '+cidr_blocks = ["0.0.0.0/0"]'],
    ["Destructive Schema Migration Guard", "db/migrations/002.sql", "+ALTER TABLE a DROP COLUMN b;"],
    ["New External Dependency & License Check", "package.json", '+"left-pad": "^1.3.0"'],
  ];
  for (const [rule, file, body] of samples) {
    it(`fixture: ${rule}`, async () => {
      // Source-code rules only run when the repo lists its domain boundary paths as structural triggers.
      await withTenant(t.db, orgId, (tx) =>
        tx.update(repositories).set({ structuralTriggers: [...DEFAULT_STRUCTURAL_TRIGGERS, "services/**"] }).where(eq(repositories.id, repoId)),
      );
      provider.diffstat = [{ status: "modified", path: file }];
      provider.diff = makeDiff({ [file]: body });
      const sev = STARTER_RULES.find((r) => r.name === rule)!.severity;
      llm = new FakeLlm(() => ({ violations: [{ ruleName: rule, severity: "warning", filePath: file, line: 1, message: "m", remediation: "r" }], adrDraft: null }));
      const res = await processEvaluation(job(300 + n), deps);
      expect(llm.requests[0]!.user).toContain(rule);
      expect(llm.requests[0]!.user).toContain(body.slice(1, 12));
      expect(res.status).toBe(sev === "blocking" ? "failed" : "passed");
    });
  }

  it.skipIf(!process.env.LIVE_LLM_EVAL)("optional live-LLM evaluation (set LIVE_LLM_EVAL=1 with LLM_* env)", async () => {
    const { createLlmProvider } = await import("../src/llm/factory");
    const { parseConfig } = await import("../src/lib/config");
    const live = createLlmProvider(parseConfig(process.env));
    const { evaluateDiff } = await import("../src/llm/evaluator");
    for (const [rule, file, body] of samples) {
      const out = await evaluateDiff({
        llm: live,
        rules: STARTER_RULES.map((r) => ({ ...r, description: r.description })),
        diff: makeDiff({ [file]: body }),
        changedPaths: [file],
        structuralPaths: [file],
        existingAdrTitles: [],
        prTitle: "sample",
        adrAlreadyInPr: false,
        limits: { maxDiffBytes: 50_000, maxInputTokens: 50_000 },
      });
      expect(out.kind).toBe("ok");
      if (out.kind === "ok") expect(out.violations.some((v) => v.ruleName === rule)).toBe(true);
    }
  });
});
