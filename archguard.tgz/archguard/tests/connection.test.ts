import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { withTenant } from "../src/db/client";
import { organizations, repositories } from "../src/db/schema";
import { adrTitleFromFileName, connectScm, disableRepository, enableRepository } from "../src/services/connection";
import { decrypt } from "../src/lib/vault";
import { webhookPath } from "../src/scm/factory";
import { matchStructuralPaths, DEFAULT_STRUCTURAL_TRIGGERS } from "../src/triage/triggers";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";
import { FakeProvider } from "./helpers/fakeProvider";

let t: TestDb;
let orgId: string;
const fake = new FakeProvider();
fake.repos = [
  { id: "{r1}", slug: "svc-a", fullName: "acme/svc-a" },
  { id: "{r2}", slug: "svc-b", fullName: "acme/svc-b" },
];
const bb = (owner: string, token: string) => ({ provider: "bitbucket_cloud" as const, owner, token });

beforeAll(async () => {
  t = await createTestDb();
  orgId = (await createOrg(t, "acme")).id;
});
afterAll(() => t.close());

describe("connectScm (REQ-1.1)", () => {
  it("rejects invalid credentials without storing anything", async () => {
    const bad = new FakeProvider();
    bad.validOk = false;
    const r = await connectScm(t.db, orgId, bb("acme", "x"), () => bad);
    expect(r).toEqual({ ok: false, reason: "bad token" });
    const [org] = await withTenant(t.db, orgId, (tx) => tx.select().from(organizations));
    expect(org!.encryptedAccessToken).toBeNull();
  });
  it("rejects malformed owners, empty tokens and unsupported providers", async () => {
    expect((await connectScm(t.db, orgId, bb("a/b", "x"), () => fake)).ok).toBe(false);
    expect((await connectScm(t.db, orgId, bb("acme", " "), () => fake)).ok).toBe(false);
    expect(await connectScm(t.db, orgId, { provider: "bitbucket_datacenter", owner: "acme", token: "x" }, () => fake)).toMatchObject({ ok: false });
  });
  it("stores the token encrypted and syncs repositories (idempotently)", async () => {
    const r = await connectScm(t.db, orgId, bb("acme", "secret-token"), () => fake);
    expect(r).toEqual({ ok: true, repositories: 2 });
    await connectScm(t.db, orgId, bb("acme", "secret-token"), () => fake);
    const [org] = await withTenant(t.db, orgId, (tx) => tx.select().from(organizations));
    expect(org).toMatchObject({ scmProvider: "bitbucket_cloud", scmOwner: "acme" });
    expect(org!.encryptedAccessToken).not.toContain("secret-token");
    expect(decrypt(org!.encryptedAccessToken!)).toBe("secret-token");
    const repos = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    expect(repos).toHaveLength(2);
    expect(repos[0]).toMatchObject({ isActive: false, scmProvider: "bitbucket_cloud", structuralTriggers: DEFAULT_STRUCTURAL_TRIGGERS });
  });
});

describe("enable / disable repository (REQ-1.2)", () => {
  it("registers the webhook with a generated secret and scans ADR baseline", async () => {
    fake.adrFiles = ["0001-use-postgres.md", "0002_adopt-kafka.md", "README.md", "template.md"];
    const [repo] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    const r = await enableRepository(t.db, orgId, repo!.id, fake, "https://hooks.example/api/webhooks/bitbucket");
    expect(r.baselineAdrs).toBe(2);
    const hook = fake.hooks.get(r.webhookUuid)!;
    expect(hook.secret).toMatch(/^[0-9a-f]{64}$/);
    const [after] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    expect(after!.isActive).toBe(true);
    expect(after!.baselineAdrTitles).toEqual(["use postgres", "adopt kafka"]);
    expect(decrypt(after!.encryptedWebhookSecret!)).toBe(hook.secret);
  });
  it("re-enable leaves exactly one webhook and rotates the secret", async () => {
    const [repo] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    const before = fake.hooks.size;
    await enableRepository(t.db, orgId, repo!.id, fake, "https://hooks.example/api/webhooks/bitbucket");
    expect(fake.hooks.size).toBe(before);
  });
  it("disable removes the webhook and secret", async () => {
    const [repo] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    await disableRepository(t.db, orgId, repo!.id, fake);
    const [after] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    expect(after).toMatchObject({ isActive: false, webhookUuid: null, encryptedWebhookSecret: null });
    expect(fake.hooks.size).toBe(0);
  });
});

describe("switching provider (one provider per organization)", () => {
  const gh = new FakeProvider("github");
  gh.repos = [{ id: "123456", slug: "svc-a", fullName: "acme/svc-a" }];
  const ghInput = { provider: "github" as const, owner: "acme", token: "ghp" };

  it("is refused while any repository of the current provider is enabled", async () => {
    const [repo] = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    await enableRepository(t.db, orgId, repo!.id, fake, "https://x/api/webhooks/bitbucket");
    const r = await connectScm(t.db, orgId, ghInput, () => gh);
    expect(r).toEqual({ ok: false, reason: "Disable all Bitbucket Cloud repositories before connecting GitHub." });
    await disableRepository(t.db, orgId, repo!.id, fake);
  });

  it("succeeds once nothing is enabled; old repositories keep their history but cannot be managed", async () => {
    const r = await connectScm(t.db, orgId, ghInput, () => gh);
    expect(r).toEqual({ ok: true, repositories: 1 });
    const repos = await withTenant(t.db, orgId, (tx) => tx.select().from(repositories));
    expect(repos.map((x) => x.scmProvider).sort()).toEqual(["bitbucket_cloud", "bitbucket_cloud", "github"]);
    const old = repos.find((x) => x.scmProvider === "bitbucket_cloud")!;
    await expect(enableRepository(t.db, orgId, old.id, gh, "https://x/api/webhooks/github")).rejects.toThrow(/previous Bitbucket Cloud connection/);
    const ghRepo = repos.find((x) => x.scmProvider === "github")!;
    const e = await enableRepository(t.db, orgId, ghRepo.id, gh, "https://x/api/webhooks/github");
    expect(e.webhookUuid).toMatch(/^\d+$/);
  });

  it("routes webhooks per provider", () => {
    expect(webhookPath("github")).toBe("/api/webhooks/github");
    expect(webhookPath("bitbucket_cloud")).toBe("/api/webhooks/bitbucket");
  });
});

describe("helpers", () => {
  it("parses ADR file names", () => {
    expect(adrTitleFromFileName("0003-use-redis.md")).toBe("use redis");
    expect(adrTitleFromFileName("README.md")).toBeNull();
  });
  it("matches structural trigger globs (REQ-2.1)", () => {
    const paths = ["README.md", "src/app.ts", "infra/main.tf", "svc/Dockerfile", "db/migrations/001.sql", "package.json", "api/openapi.yaml", "docker-compose.prod.yml", "a/b/go.mod"];
    expect(matchStructuralPaths(paths, DEFAULT_STRUCTURAL_TRIGGERS)).toEqual([
      "infra/main.tf", "svc/Dockerfile", "db/migrations/001.sql", "package.json", "api/openapi.yaml", "docker-compose.prod.yml", "a/b/go.mod",
    ]);
    expect(matchStructuralPaths(["README.md", "docs/a.md"], DEFAULT_STRUCTURAL_TRIGGERS)).toEqual([]);
    expect(matchStructuralPaths(["x.tf"], [])).toEqual([]);
  });
});
