import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { withTenant } from "../src/db/client";
import { adrDrafts, prEvaluations, repositories } from "../src/db/schema";
import { AdrError, approveAndCommit, dismissAdrDraft, getAdrDraft, listAdrDrafts, updateAdrDraft } from "../src/services/adrs";
import { deleteRule, listRules, parsePatterns, saveRule, setRuleEnabled } from "../src/services/rules";
import { approvedTimeline, getDashboard } from "../src/services/dashboard";
import { ForbiddenError, type Principal } from "../src/auth/roles";
import { renderMadr } from "../src/adr/madr";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";
import { FakeProvider } from "./helpers/fakeProvider";
import { ADR } from "./helpers/fakeLlm";

let t: TestDb;
let orgId: string;
let otherOrgId: string;
let repoId: string;
let architect: Principal;
let viewer: Principal;
let provider: FakeProvider;

async function newDraft(prId: number, number: number) {
  return withTenant(t.db, orgId, async (tx) => {
    const [d] = await tx.insert(adrDrafts).values({ orgId, repoId, prId, adrNumber: number, title: ADR.title, markdownContent: renderMadr(number, ADR) }).returning();
    return d!;
  });
}

beforeAll(async () => {
  t = await createTestDb();
  orgId = (await createOrg(t, "acme")).id;
  otherOrgId = (await createOrg(t, "other")).id;
  architect = { userId: "00000000-0000-0000-0000-000000000001", orgId, role: "architect" };
  viewer = { ...architect, role: "viewer" };
  await withTenant(t.db, orgId, async (tx) => {
    const [r] = await tx.insert(repositories).values({ orgId, scmRepoId: "{r}", repoSlug: "svc", fullName: "acme/svc", isActive: true }).returning();
    repoId = r!.id;
  });
});
afterAll(() => t.close());
const fresh = () => (provider = new FakeProvider());

describe("ADR approve & commit (REQ-2.8)", () => {
  it("commits to the PR source branch via the provider and records the sha/path", async () => {
    fresh();
    const d = await newDraft(1, 5);
    const r = await approveAndCommit(t.db, architect, d.id, provider);
    expect(r).toMatchObject({ path: "docs/adr/0005-adopt-kafka-for-events.md", commitSha: "commit-1", adrNumber: 5 });
    expect(provider.commits[0]!.input).toMatchObject({ branch: "feature/x", path: r.path });
    expect(provider.commits[0]!.input.content).toContain("## Consequences");
    const row = (await getAdrDraft(t.db, orgId, d.id))!.draft;
    expect(row).toMatchObject({ status: "approved_committed", committedSha: "commit-1", committedPath: r.path });
  });

  it("commits to the target branch when the PR is already merged; refuses declined PRs", async () => {
    fresh();
    provider.pr = { ...provider.pr, state: "MERGED" };
    const d = await newDraft(2, 6);
    await approveAndCommit(t.db, architect, d.id, provider);
    expect(provider.commits[0]!.input.branch).toBe("main");

    fresh();
    provider.pr = { ...provider.pr, state: "DECLINED" };
    const d2 = await newDraft(3, 7);
    await expect(approveAndCommit(t.db, architect, d2.id, provider)).rejects.toMatchObject({ code: "pr_declined" });
    expect(provider.commits).toHaveLength(0);
  });

  it("double click commits once", async () => {
    fresh();
    const d = await newDraft(4, 8);
    const results = await Promise.allSettled([approveAndCommit(t.db, architect, d.id, provider), approveAndCommit(t.db, architect, d.id, provider)]);
    expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(1);
    expect((results.find((r) => r.status === "rejected") as PromiseRejectedResult).reason).toMatchObject({ code: "not_pending" });
    expect(provider.commits).toHaveLength(1);
  });

  it("renumbers when the number is already taken on the branch", async () => {
    fresh();
    provider.adrFiles = ["0009-something-else.md", "0010-another.md"];
    const d = await newDraft(5, 9);
    const r = await approveAndCommit(t.db, architect, d.id, provider);
    expect(r.adrNumber).toBe(11);
    expect(r.path).toBe("docs/adr/0011-adopt-kafka-for-events.md");
    expect(provider.commits[0]!.input.content).toContain("# 0011.");
    expect((await getAdrDraft(t.db, orgId, d.id))!.draft.adrNumber).toBe(11);
  });

  it("failed Bitbucket commit leaves the draft pending so it can be retried", async () => {
    fresh();
    provider.commitFailsWithStatus = 409;
    const d = await newDraft(6, 12);
    await expect(approveAndCommit(t.db, architect, d.id, provider)).rejects.toThrow();
    expect((await getAdrDraft(t.db, orgId, d.id))!.draft.status).toBe("pending");
  });

  it("requires the architect role and is tenant isolated", async () => {
    fresh();
    const d = await newDraft(7, 13);
    await expect(approveAndCommit(t.db, viewer, d.id, provider)).rejects.toBeInstanceOf(ForbiddenError);
    await expect(updateAdrDraft(t.db, viewer, d.id, { title: "x", markdown: "x" })).rejects.toBeInstanceOf(ForbiddenError);
    await expect(dismissAdrDraft(t.db, viewer, d.id)).rejects.toBeInstanceOf(ForbiddenError);
    const outsider: Principal = { ...architect, orgId: otherOrgId };
    await expect(approveAndCommit(t.db, outsider, d.id, provider)).rejects.toMatchObject({ code: "not_found" });
    expect(await getAdrDraft(t.db, otherOrgId, d.id)).toBeNull();
  });

  it("edit and dismiss work only on pending drafts", async () => {
    const d = await newDraft(8, 14);
    await updateAdrDraft(t.db, architect, d.id, { title: "Edited", markdown: "# edited" });
    expect((await getAdrDraft(t.db, orgId, d.id))!.draft).toMatchObject({ title: "Edited", markdownContent: "# edited" });
    await expect(updateAdrDraft(t.db, architect, d.id, { title: "", markdown: "x" })).rejects.toBeInstanceOf(AdrError);
    await dismissAdrDraft(t.db, architect, d.id);
    await expect(dismissAdrDraft(t.db, architect, d.id)).rejects.toMatchObject({ code: "not_pending" });
    await expect(updateAdrDraft(t.db, architect, d.id, { title: "again", markdown: "x" })).rejects.toMatchObject({ code: "not_pending" });
  });

  it("lists and searches", async () => {
    expect((await listAdrDrafts(t.db, orgId, { status: "pending" })).every((d) => d.status === "pending")).toBe(true);
    expect((await approvedTimeline(t.db, orgId)).length).toBeGreaterThanOrEqual(3);
    expect(await approvedTimeline(t.db, orgId, "no-such-text-zzz")).toHaveLength(0);
    expect((await listAdrDrafts(t.db, orgId, { q: "Kafka%_" })).length).toBe(0); // wildcards are escaped
  });
});

describe("guardrail rule CRUD (Task 9)", () => {
  const input = { name: "No Foo", severity: "blocking" as const, rulePrompt: "Flag any usage of foo()", targetPatterns: ["**/*.ts"] };
  it("architect can create, edit, disable and delete; viewer cannot", async () => {
    const rule = await saveRule(t.db, architect, input);
    expect(rule).toMatchObject({ name: "No Foo", isEnabled: true });
    const edited = await saveRule(t.db, architect, { ...input, severity: "warning" }, rule.id);
    expect(edited.severity).toBe("warning");
    await setRuleEnabled(t.db, architect, rule.id, false);
    expect((await listRules(t.db, orgId)).find((r) => r.id === rule.id)!.isEnabled).toBe(false);
    await expect(saveRule(t.db, viewer, input)).rejects.toBeInstanceOf(ForbiddenError);
    await expect(deleteRule(t.db, viewer, rule.id)).rejects.toBeInstanceOf(ForbiddenError);
    await deleteRule(t.db, architect, rule.id);
    expect((await listRules(t.db, orgId)).some((r) => r.id === rule.id)).toBe(false);
  });
  it("validates input and isolates tenants", async () => {
    await expect(saveRule(t.db, architect, { ...input, rulePrompt: "short" })).rejects.toThrow();
    await expect(saveRule(t.db, architect, { ...input, severity: "nope" as never })).rejects.toThrow();
    expect(await listRules(t.db, otherOrgId)).toEqual([]);
    expect(parsePatterns("a/**, b\n\n c ")).toEqual(["a/**", "b", "c"]);
  });
});

describe("dashboard (REQ-2.9)", () => {
  it("computes compliance on the latest evaluation per PR, neutral excluded, and drift alerts", async () => {
    const now = new Date();
    const v = { ruleName: "Destructive Schema Migration Guard", severity: "blocking" as const, filePath: "m.sql", line: 1, message: "m", remediation: "r" };
    await withTenant(t.db, orgId, async (tx) => {
      const add = (prId: number, status: "passed" | "failed" | "neutral", violations: unknown[] = [], ago = 0) =>
        tx.insert(prEvaluations).values({
          orgId, repoId, prId, commitSha: "c", status, violations: violations as never, requestUuid: `dash-${prId}-${status}-${ago}`,
          createdAt: new Date(now.getTime() - ago * 1000),
        });
      await add(901, "failed", [v], 100); await add(901, "passed", [], 10); // fixed after failing: counts as passed
      await add(902, "failed", [v]); await add(903, "failed", [v]); await add(904, "failed", [v]);
      await add(905, "neutral");
    });
    const d = await getDashboard(t.db, orgId, now);
    const repo = d.repos.find((r) => r.repoId === repoId)!;
    expect(repo).toMatchObject({ passed: 1 + 0, failed: 3, neutral: 1 });
    expect(repo.complianceRate).toBeCloseTo(0.25 );
    expect(d.driftAlerts).toEqual([{ repoName: "acme/svc", ruleName: "Destructive Schema Migration Guard", prCount: 3 }]);
    expect(d.recentFailures.length).toBe(3);
    expect(d.pendingDrafts).toBeGreaterThanOrEqual(1);
    const empty = await getDashboard(t.db, otherOrgId, now);
    expect(empty).toMatchObject({ repos: [], overallRate: null, driftAlerts: [] });
  });
});

