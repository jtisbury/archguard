import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { checkHelp, getHelpPage, loadHelpPages, renderHelp, searchHelp } from "../src/help/content";

describe("online help", () => {
  const pages = loadHelpPages();

  it("covers every required topic", () => {
    const slugs = pages.map((p) => p.slug);
    for (const s of [
      "getting-started", "local-setup", "connect-bitbucket", "enable-repositories", "how-evaluation-works",
      "build-statuses-and-comments", "guardrail-rules", "adr-workflow", "roles-and-permissions", "dashboard",
      "pilot-and-shadow-mode", "security-and-data-handling", "troubleshooting-faq", "connect-github", "cloud-deployment",
    ]) expect(slugs).toContain(s);
    // Ordering: cloud deployment follows local setup; GitHub follows Bitbucket.
    expect(slugs.indexOf("cloud-deployment")).toBe(slugs.indexOf("local-setup") + 1);
    expect(slugs.indexOf("connect-github")).toBe(slugs.indexOf("connect-bitbucket") + 1);
  });

  it("link check: every internal link and anchor resolves, every page has a title and summary", () => {
    expect(checkHelp(pages)).toEqual([]);
  });

  it("the link checker catches broken links and anchors", () => {
    const bad = [{ slug: "a", title: "A", order: 1, summary: "s", body: "## Real\n[x](nope) [y](a#missing) [z](#gone) [ok](a#real)" }];
    expect(checkHelp(bad).sort()).toEqual(["a: broken anchor #gone", "a: broken anchor a#missing", "a: broken link nope"]);
  });

  it("renders Markdown with heading ids and rewrites relative links to /help", () => {
    const html = renderHelp("## Neutral results\n\n[go](build-statuses-and-comments#neutral-results) and [ext](https://example.com)");
    expect(html).toContain('<h2 id="neutral-results">');
    expect(html).toContain('href="/help/build-statuses-and-comments#neutral-results"');
    expect(html).toContain('href="https://example.com"');
  });

  it("search ranks title matches first and returns snippets", () => {
    const hits = searchHelp("webhook signature");
    expect(hits.length).toBeGreaterThan(0);
    expect(hits[0]!.snippet.length).toBeGreaterThan(10);
    expect(searchHelp("ADR approve")[0]!.page.slug).toBe("adr-workflow");
    expect(searchHelp("zzzzqqqq")).toEqual([]);
    // Parenthesised prose survives in snippets; link URLs do not.
    const hit = searchHelp("default docs adr").find((h) => h.page.slug === "enable-repositories")!;
    expect(hit.snippet).toMatch(/\(default docs\/adr\s?\)/);
    expect(searchHelp("how-evaluation-works").every((h) => !h.snippet.includes("](")) ).toBe(true);
    expect(getHelpPage("dashboard", pages)?.title).toBe("Using the dashboard");
  });

  it("documentation matches implementation facts", () => {
    const text = pages.map((p) => p.body).join("\n");
    expect(text).toContain("ArchGuard: No architectural impact detected");
    expect(text).toContain("archguard-admins");
    // GitHub + cloud facts that must stay in sync with the code and deployment files.
    expect(text).toContain("/api/webhooks/github");
    expect(text).toContain("/api/auth/callback/oidc");
    expect(text).toContain("https://archguard.app/roles");
    expect(text).toContain("deploy/vm/deploy.sh");
    expect(text).not.toContain("deploy/oci/");
    // Hetzner is the only worked hosting example.
    expect(text).not.toMatch(/Oracle|OVH|\bOCI\b/i);
    expect(text).toContain("Hetzner");
    // Every script the docs tell people to run must exist.
    for (const m of text.matchAll(/deploy\/vm\/([a-z-]+\.sh)/g)) {
      expect(fs.existsSync(path.resolve(process.cwd(), "deploy", "vm", m[1]!)), m[1]).toBe(true);
    }
    for (const rule of ["No Cross-Domain Database Coupling", "Breaking API Contract Detection", "Unapproved Cloud / IaC Provisioning", "Destructive Schema Migration Guard", "New External Dependency & License Check"]) {
      expect(text).toContain(rule);
    }
  });
});
