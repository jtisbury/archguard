import { describe, expect, it } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { runMigrations } from "../src/db/migrate";

const SRC = path.resolve(process.cwd(), "src", "db", "migrations");

describe("migration 0002 (Bitbucket-only -> SCM providers)", () => {
  it("upgrades an existing database in place without losing data", async () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "ag-mig-"));
    fs.copyFileSync(path.join(SRC, "0001_init.sql"), path.join(dir, "0001_init.sql"));
    const pg = new PGlite();
    const ex = { exec: (s: string) => pg.exec(s), query: (s: string, p?: unknown[]) => pg.query(s, p) as Promise<{ rows: Record<string, unknown>[] }> };
    try {
      await runMigrations(ex, dir);
      await pg.exec(`
        INSERT INTO organizations (id, name, slug, bitbucket_type, bitbucket_workspace_or_project)
          VALUES ('00000000-0000-0000-0000-0000000000a1', 'A', 'a', 'cloud', 'ws-a'),
                 ('00000000-0000-0000-0000-0000000000b2', 'B', 'b', 'datacenter', 'PROJ');
        INSERT INTO repositories (org_id, bitbucket_repo_uuid, repo_slug, full_name, webhook_uuid)
          VALUES ('00000000-0000-0000-0000-0000000000a1', '{r1}', 'svc', 'ws-a/svc', '{h1}');`);

      fs.copyFileSync(path.join(SRC, "0002_scm_providers.sql"), path.join(dir, "0002_scm_providers.sql"));
      expect(await runMigrations(ex, dir)).toEqual(["0002_scm_providers.sql"]);

      const orgs = (await pg.query(`SELECT slug, scm_provider, scm_owner FROM organizations ORDER BY slug`)).rows;
      expect(orgs).toEqual([
        { slug: "a", scm_provider: "bitbucket_cloud", scm_owner: "ws-a" },
        { slug: "b", scm_provider: "bitbucket_datacenter", scm_owner: "PROJ" },
      ]);
      const repos = (await pg.query(`SELECT scm_repo_id, scm_provider FROM repositories`)).rows;
      expect(repos).toEqual([{ scm_repo_id: "{r1}", scm_provider: "bitbucket_cloud" }]);
      // Webhook lookup still works after the rename.
      const hook = (await pg.query(`SELECT repo_id FROM lookup_repo_for_webhook('h1')`)).rows;
      expect(hook).toHaveLength(1);
      // New constraint: same repo id allowed under a different provider, rejected under the same one.
      await pg.exec(`INSERT INTO repositories (org_id, scm_provider, scm_repo_id, repo_slug, full_name) VALUES ('00000000-0000-0000-0000-0000000000a1', 'github', '{r1}', 'svc', 'ws-a/svc')`);
      await expect(pg.exec(`INSERT INTO repositories (org_id, scm_provider, scm_repo_id, repo_slug, full_name) VALUES ('00000000-0000-0000-0000-0000000000a1', 'github', '{r1}', 'x', 'x')`)).rejects.toThrow();
      await expect(pg.exec(`UPDATE organizations SET scm_provider = 'gitlab'`)).rejects.toThrow();
    } finally {
      await pg.close();
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });
});
