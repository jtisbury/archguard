import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { hasRole, mapGroupsToRole, normalizeGroups, requireRole, ForbiddenError, UnauthenticatedError } from "../src/auth/roles";
import { provisionUser, type ProvisionOptions } from "../src/auth/provision";
import { withTenant } from "../src/db/client";
import { organizationMembers } from "../src/db/schema";
import { createOrg, createTestDb, type TestDb } from "./helpers/testdb";
import type { Role } from "../src/db/schema";

const map = { admin: ["archguard-admins"], architect: ["archguard-architects"], viewer: ["archguard-viewers"] };

describe("role mapping", () => {
  it("picks the highest role and is case-insensitive", () => {
    expect(mapGroupsToRole(["ARCHGUARD-VIEWERS", "archguard-admins"], map)).toBe("admin");
    expect(mapGroupsToRole(["archguard-architects", "archguard-viewers"], map)).toBe("architect");
    expect(mapGroupsToRole(["other"], map)).toBeNull();
    expect(mapGroupsToRole([], map)).toBeNull();
  });
  it("normalizes odd group claims", () => {
    expect(normalizeGroups("a, b c")).toEqual(["a", "b", "c"]);
    expect(normalizeGroups(undefined)).toEqual([]);
    expect(normalizeGroups(["x", 1])).toEqual(["x", "1"]);
  });
  it("role matrix", () => {
    const roles: Role[] = ["viewer", "architect", "admin"];
    const expected: Record<Role, Record<Role, boolean>> = {
      viewer: { viewer: true, architect: false, admin: false },
      architect: { viewer: true, architect: true, admin: false },
      admin: { viewer: true, architect: true, admin: true },
    };
    for (const actual of roles) for (const min of roles) expect(hasRole(actual, min)).toBe(expected[actual][min]);
    expect(hasRole(null, "viewer")).toBe(false);
  });
  it("requireRole throws the right errors", () => {
    const viewer = { userId: "u", orgId: "o", role: "viewer" as const };
    expect(() => requireRole(null, "viewer")).toThrow(UnauthenticatedError);
    expect(() => requireRole(viewer, "admin")).toThrow(ForbiddenError);
    expect(requireRole(viewer, "viewer")).toBe(viewer);
  });
});

describe("provisionUser (OIDC claims from a simulated IdP)", () => {
  let t: TestDb;
  let orgId: string;
  const opts: ProvisionOptions = { defaultOrgSlug: "pilot", groupsClaim: "groups", roleMap: map };
  beforeAll(async () => {
    t = await createTestDb();
    orgId = (await createOrg(t, "pilot")).id;
  });
  afterAll(() => t.close());

  it("creates user + membership with the mapped role", async () => {
    const p = await provisionUser(t.db, { sub: "s1", email: "Ann@Corp.com", groups: ["archguard-architects"] }, opts);
    expect(p).toMatchObject({ role: "architect", orgId, email: "ann@corp.com" });
  });
  it("updates the role at next sign-in", async () => {
    const p = await provisionUser(t.db, { sub: "s1", email: "ann@corp.com", groups: ["archguard-admins"] }, opts);
    expect(p?.role).toBe("admin");
  });
  it("refuses users without an ArchGuard group and removes membership", async () => {
    expect(await provisionUser(t.db, { sub: "s1", email: "ann@corp.com", groups: ["nobody"] }, opts)).toBeNull();
    const members = await withTenant(t.db, orgId, (tx) => tx.select().from(organizationMembers));
    expect(members).toHaveLength(0);
  });
  it("refuses profiles without email or when the org does not exist", async () => {
    expect(await provisionUser(t.db, { sub: "s2", groups: ["archguard-admins"] }, opts)).toBeNull();
    expect(await provisionUser(t.db, { sub: "s3", email: "x@y.z", groups: ["archguard-admins"] }, { ...opts, defaultOrgSlug: "missing" })).toBeNull();
  });
});
