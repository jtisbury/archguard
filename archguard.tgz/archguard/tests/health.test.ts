import { describe, expect, it } from "vitest";
import { getHealth } from "../src/lib/health";
import { withTimeout } from "../src/lib/redis";

describe("health", () => {
  it("reports ok when both dependencies are up", async () => {
    expect(await getHealth({ pingDb: async () => true, pingRedis: async () => true })).toEqual({ status: "ok", db: "up", redis: "up" });
  });
  it("reports degraded and which dependency is down", async () => {
    expect(await getHealth({ pingDb: async () => true, pingRedis: async () => false })).toEqual({ status: "degraded", db: "up", redis: "down" });
  });
  it("withTimeout rejects a hung operation instead of waiting forever", async () => {
    const never = new Promise<string>(() => {});
    await expect(withTimeout(never, 50, "redis ping")).rejects.toThrow(/timed out after 50ms/);
    await expect(withTimeout(Promise.resolve("PONG"), 50)).resolves.toBe("PONG");
  });
});
