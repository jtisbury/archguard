/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  serverExternalPackages: ["pg", "ioredis", "bullmq", "@aws-sdk/client-bedrock-runtime"],
};
export default nextConfig;
