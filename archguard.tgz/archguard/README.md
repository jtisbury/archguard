# ArchGuard

Automated architectural governance for **Bitbucket Cloud** and **GitHub.com** pull requests (one provider per organization): structural triage, LLM guardrail checks, build-status gating, and MADR ADR drafts that an Architect approves and commits back.

- Specs: [`specs/requirements.md`](specs/requirements.md), [`specs/design.md`](specs/design.md)
- Steering: [`../.kiro/steering/architecture.md`](../.kiro/steering/architecture.md)
- Online help (in the app at `/help`, sources in [`docs/help`](docs/help))

## Quickstart (clone to a gated pull request)

Prerequisites: Node.js 22+, Docker.

```bash
docker compose up -d                 # Postgres 16, Redis 7, mock OIDC
cp .env.example .env                 # then set TOKEN_ENCRYPTION_KEY, AUTH_SECRET, LLM_* values
npm install
npm run db:migrate                   # owner role: tables, RLS, archguard_app role
npm run db:seed -- pilot "My Company"   # creates the org + 5 starter rules
npm run dev                          # http://localhost:3000
npm run worker                       # second terminal
```

1. Sign in (members of `archguard-admins` become Admins).
2. **Settings**: paste a Bitbucket Workspace Access Token and workspace slug, then **Enable** a repository.
3. Open a PR that edits a `.tf` file or `package.json`. The **ArchGuard** check and a PR comment appear.
4. Keep "Require successful builds to merge" **unchecked** for the first week (shadow mode), then switch it on.

`WEBHOOK_PUBLIC_URL` must be reachable from Bitbucket (use an approved tunnel when running locally).

## Token permissions

- **Bitbucket Cloud Workspace Access Token** (per Atlassian's API reference): `repository` (read), `repository:write` (ADR commits and build statuses), `pullrequest` (read and comment), `webhook`.
- **GitHub fine-grained PAT** (per GitHub's per-endpoint permission list): Metadata read, Contents read/write, Pull requests read/write, Commit statuses read/write, Webhooks read/write.

**Neither has been verified against a live account** in this build; see below.

## Cloud deployment

Single-VM Docker Compose behind Caddy (automatic HTTPS) on any Ubuntu server with 2 vCPU / 4 GB or more. Worked example: Hetzner Cloud CX23/CAX11 (CPX22 also works), with a DuckDNS name and Auth0 sign-in. Full walkthrough: `/help/cloud-deployment` ([source](docs/help/cloud-deployment.md)).

| File | Purpose |
|---|---|
| `Dockerfile` | One image for app, worker and migrations (native arm64/amd64) |
| `docker-compose.prod.yml` | postgres, redis, app, worker, caddy, `migrate` (tools profile) |
| `.env.production.example` | All production settings |
| `deploy/Caddyfile` | TLS, security headers, reverse proxy |
| `deploy/vm/setup-vm.sh` | Any Ubuntu 22.04/24.04: Docker install, host firewall (ufw, rejecting iptables rules, or none), swap on small servers, unattended upgrades |
| `deploy/vm/deploy.sh` | Build, migrate, seed, start (idempotent) |
| `deploy/vm/backup.sh` | Nightly `pg_dump`, 14-day retention |
| `deploy/vm/duckdns-update.sh` | Keeps the DuckDNS name on the server's IP (optional with a fixed IP) |
| `scripts/check-compose.ps1` | Static check: owner DB credentials only in `migrate`; only Caddy publishes ports |

Use personal or test repositories only on a personal cloud account (see the steering file, section 3).

## Commands

| Command | Purpose |
|---|---|
| `npm test` | Vitest suite (in-process Postgres via PGlite; no Docker needed) |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run docs:check` | Help link and anchor check |
| `powershell -File scripts/smoke.ps1` | After `npm run build`: starts the app on port 3055, probes help, auth redirects, health and webhook, writes `smoke-results.txt` |
| `npm run build` | Production build of the web app |
| `npm run db:migrate` / `db:seed` | Schema and bootstrap (owner connection) |

## Verified vs mocked

Verified automatically in this repository:
- RLS isolation (including property-based tests), `withTenant`, restricted app role (PGlite with the real migrations).
- AES-256-GCM vault, config validation, billing gate.
- Webhook signature (Atlassian's published test vector), dedupe and idempotency (ioredis-mock), rate limit.
- Bitbucket Cloud adapter request shapes, pagination, retries, multipart commit (recorded/mocked HTTP).
- GitHub adapter request shapes, Link pagination, status mapping, 406 "diff too large", contents-API commit; GitHub webhook ingestion (`X-Hub-Signature-256`, hook id lookup, delivery dedupe, action filtering); provider switching rules.
- Migration `0002` upgrading an existing Bitbucket database in place.
- Compose file: parses, owner credentials only in `migrate`, only Caddy publishes ports (`scripts/check-compose.ps1`). Deployment scripts use LF line endings.
- Worker pipeline, triage, gating, neutral outcomes, retries, ADR numbering and approve/commit (fake provider and fake LLM).
- OpenAI-compatible and Bedrock request construction (mocked transports).
- Help content: required topics, links, anchors, search.

**Not verified live** (needs credentials or Docker that were unavailable during the build):
- Real Bitbucket workspace: token scopes, webhook delivery headers (`X-Hook-UUID`, `X-Request-UUID`), the `/src` commit response `Location` header, build status display.
- Real GitHub account: fine-grained token permissions, webhook deliveries, statuses and comments.
- The Docker image build, `docker-compose.prod.yml` at runtime, Caddy certificate issuance, the `deploy/vm/*.sh` scripts (no Docker or Bash on the build machine), Auth0 sign-in.
- A real OIDC identity provider and the Auth.js sign-in flow (role mapping logic is unit tested with simulated claims).
- A real LLM endpoint (optional live check: `LIVE_LLM_EVAL=1 npm test` with `LLM_*` set).
- `docker compose` stack and a live Postgres/Redis/BullMQ run.
- Real concurrency of ADR numbering across database connections (PGlite serializes transactions).

## Limitations

- Bitbucket Data Center is a stub (`BitbucketDataCenterAdapter` throws "not implemented"). GitHub Enterprise Server and GitHub Apps are not supported.
- One source-control provider per organization.
- `monthly_eval_count` is incremented but never reset (billing is a stub).
- Organizations are created by the seed script; all users sign in to the org named by `AUTH_DEFAULT_ORG_SLUG`.
