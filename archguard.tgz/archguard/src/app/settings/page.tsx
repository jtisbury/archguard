import Link from "next/link";
import { eq } from "drizzle-orm";
import { connectAction, repoSettingsAction, syncAction, toggleRepoAction } from "@/app/actions";
import { pagePrincipal } from "@/auth/page";
import { getDb, withTenant } from "@/db/client";
import { organizations, repositories } from "@/db/schema";
import { getConfig } from "@/lib/config";
import { SCM_LABELS } from "@/scm/provider";
import { Badge, Flash, Forbidden } from "../components";

export const dynamic = "force-dynamic";

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ msg?: string; error?: string }> }) {
  const { principal, allowed } = await pagePrincipal("admin");
  if (!allowed) return <Forbidden need="Admin" />;
  const sp = await searchParams;
  const { org, allRepos } = await withTenant(getDb(), principal.orgId, async (tx) => ({
    org: (await tx.select().from(organizations).where(eq(organizations.id, principal.orgId)))[0],
    allRepos: await tx.select().from(repositories).orderBy(repositories.fullName),
  }));
  const connected = !!org?.encryptedAccessToken;
  const kind = org?.scmProvider ?? "bitbucket_cloud";
  // Repositories from a previous provider keep their history on the dashboard but are not manageable here.
  const repos = allRepos.filter((r) => r.scmProvider === kind);
  const pilot = getConfig().ENTERPRISE_PILOT_MODE;

  return (
    <>
      <h1>Settings</h1>
      <p className="muted">Help: <Link href="/help/connect-bitbucket">connect Bitbucket</Link> · <Link href="/help/connect-github">connect GitHub</Link> · <Link href="/help/enable-repositories">enable repositories</Link> · <Link href="/help/pilot-and-shadow-mode">pilot and shadow mode</Link></p>
      <Flash msg={sp.msg} error={sp.error} />
      <div className="card">
        <h2>Source control connection</h2>
        <p>Status: {connected ? <Badge kind="passed">{SCM_LABELS[kind]}: {org?.scmOwner}</Badge> : <Badge kind="neutral">not connected</Badge>}</p>
        <form action={connectAction}>
          <label>Provider
            <select name="provider" defaultValue={kind === "github" ? "github" : "bitbucket_cloud"}>
              <option value="bitbucket_cloud">Bitbucket Cloud (Workspace Access Token)</option>
              <option value="github">GitHub.com (fine-grained personal access token)</option>
            </select>
          </label>
          <label>Bitbucket workspace slug, or GitHub user / organization<input name="owner" defaultValue={org?.scmOwner ?? ""} required pattern="[A-Za-z0-9_.\-]+" /></label>
          <label>Access token<input name="token" type="password" autoComplete="off" required placeholder="Paste a token with the permissions listed in Help" /></label>
          <div className="row" style={{ marginTop: 8 }}><button type="submit">{connected ? "Replace token and sync" : "Validate and connect"}</button></div>
        </form>
        <p className="muted">The token is encrypted at rest (AES-256-GCM) and is never shown again.</p>
      </div>

      <div className="card">
        <div className="row"><h2 style={{ margin: 0 }}>Repositories</h2>{connected && <form action={syncAction}><button type="submit" className="secondary">Sync now</button></form>}</div>
        <p className="muted">Enabling a repository registers a signed webhook. Tip: for the first week, don&rsquo;t make the ArchGuard check required (Bitbucket: &ldquo;Require successful builds to merge&rdquo;; GitHub: branch protection &ldquo;Require status checks&rdquo;). This is shadow mode.</p>
        {repos.length === 0 ? <p>No repositories synced yet.</p> : repos.map((r) => (
          <div key={r.id} style={{ borderTop: "1px solid var(--line)", padding: "10px 0" }}>
            <div className="row">
              <strong>{r.fullName}</strong> {r.isActive ? <Badge kind="passed">enabled</Badge> : <Badge kind="dismissed">disabled</Badge>}
              <form action={toggleRepoAction}><input type="hidden" name="repoId" value={r.id} /><input type="hidden" name="enable" value={r.isActive ? "0" : "1"} /><button type="submit" className={r.isActive ? "secondary" : undefined}>{r.isActive ? "Disable" : "Enable"}</button></form>
            </div>
            <details>
              <summary>Triage settings</summary>
              <form action={repoSettingsAction}>
                <input type="hidden" name="repoId" value={r.id} />
                <label>Structural triggers (glob patterns, one per line)<textarea name="triggers" defaultValue={r.structuralTriggers.join("\n")} style={{ minHeight: 140 }} /></label>
                <label>ADR directory<input name="adrDir" defaultValue={r.adrDirectoryPath} /></label>
                <div className="row" style={{ marginTop: 8 }}><button type="submit">Save</button></div>
              </form>
            </details>
          </div>
        ))}
      </div>

      <div className="card">
        <h2>Deployment mode</h2>
        <p>ENTERPRISE_PILOT_MODE is <strong>{pilot ? "on" : "off"}</strong>. {pilot ? "Billing limits are bypassed; tenant isolation is unchanged." : "Plan limits apply."}</p>
      </div>
    </>
  );
}
