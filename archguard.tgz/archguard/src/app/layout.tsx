import type { ReactNode } from "react";
import Link from "next/link";
import { getPrincipal } from "@/auth";
import "./globals.css";

export const metadata = { title: "ArchGuard", description: "Architectural governance for Bitbucket" };

export default async function RootLayout({ children }: { children: ReactNode }) {
  const principal = await getPrincipal().catch(() => null);
  return (
    <html lang="en">
      <body>
        <header className="nav">
          <Link href="/" className="brand">ArchGuard</Link>
          <nav>
            {principal && <Link href="/">Dashboard</Link>}
            {principal && <Link href="/adrs">ADR drafts</Link>}
            {principal && <Link href="/rules">Guardrails</Link>}
            {principal?.role === "admin" && <Link href="/settings">Settings</Link>}
            <Link href="/help">Help</Link>
          </nav>
          <span className="who">{principal ? `${principal.email} · ${principal.role}` : "Signed out"}</span>
        </header>
        <main className="page">{children}</main>
      </body>
    </html>
  );
}
