import Link from "next/link";
import { pagePrincipal } from "@/auth/page";
import { getDb } from "@/db/client";
import { approvedTimeline, getDashboard } from "@/services/dashboard";
import { Badge, pct } from "./components";

export const dynamic = "force-dynamic";

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { principal } = await pagePrincipal("viewer");
  const { q } = await searchParams;
  const [d, timeline] = await Promise.all([getDashboard(getDb(), principal.orgId), approvedTimeline(getDb(), principal.orgId, q)]);

  return (
    <>
      <h1>Architecture compliance</h1>
      <p className="muted">Help: <Link href="/help/dashboard">how these numbers are calculated</Link></p>
      <div className="grid">
        <div className="card"><div className="muted">Overall compliance (30 days)</div><div className="stat">{pct(d.overallRate)}</div></div>
        <div className="card"><div className="muted">Pending ADR drafts</div><div className="stat"><Link href="/adrs">{d.pendingDrafts}</Link></div></div>
        <div className="card"><div className="muted">Drift alerts</div><div className="stat">{d.driftAlerts.length}</div></div>
      </div>

      <div className="card">
        <h2>Repositories</h2>
        {d.repos.length === 0 ? <p className="muted">No repositories yet. An admin can connect Bitbucket under Settings.</p> : (
          <table>
            <thead><tr><th>Repository</th><th>Enabled</th><th>Passed</th><th>Failed</th><th>Neutral</th><th>Compliance</th></tr></thead>
            <tbody>
              {d.repos.map((r) => (
                <tr key={r.repoId}><td>{r.repoName}</td><td>{r.isActive ? "Yes" : "No"}</td><td>{r.passed}</td><td>{r.failed}</td><td>{r.neutral}</td><td>{pct(r.complianceRate)}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h2>Architectural drift alerts</h2>
        <p className="muted">The same rule violated in 3 or more pull requests of one repository in the last 14 days.</p>
        {d.driftAlerts.length === 0 ? <p>No drift detected.</p> : (
          <table><thead><tr><th>Repository</th><th>Rule</th><th>Pull requests</th></tr></thead>
            <tbody>{d.driftAlerts.map((a) => <tr key={a.repoName + a.ruleName}><td>{a.repoName}</td><td>{a.ruleName}</td><td>{a.prCount}</td></tr>)}</tbody></table>
        )}
      </div>

      <div className="card">
        <h2>Recent failing pull requests</h2>
        {d.recentFailures.length === 0 ? <p>None.</p> : (
          <table><thead><tr><th>Repository</th><th>PR</th><th>Title</th></tr></thead>
            <tbody>{d.recentFailures.map((f) => <tr key={f.repoName + f.prId}><td>{f.repoName}</td><td>#{f.prId}</td><td>{f.prTitle}</td></tr>)}</tbody></table>
        )}
      </div>

      <div className="card">
        <h2>Approved ADR timeline</h2>
        <form className="row" action="/" method="get"><input name="q" placeholder="Search approved ADRs" defaultValue={q ?? ""} style={{ maxWidth: 320 }} /><button type="submit" className="secondary">Search</button></form>
        {timeline.length === 0 ? <p className="muted">No approved ADRs{q ? " match your search" : " yet"}.</p> : (
          <table><thead><tr><th>Date</th><th>ADR</th><th>Repository</th><th>File</th></tr></thead>
            <tbody>{timeline.map((a) => (
              <tr key={a.id}><td>{a.createdAt.toISOString().slice(0, 10)}</td><td><Link href={`/adrs/${a.id}`}>{String(a.adrNumber).padStart(4, "0")} {a.title}</Link> <Badge kind={a.status} /></td><td>{a.repoName}</td><td><code>{a.committedPath}</code></td></tr>
            ))}</tbody></table>
        )}
      </div>
    </>
  );
}
