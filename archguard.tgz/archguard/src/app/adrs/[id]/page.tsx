import Link from "next/link";
import { notFound } from "next/navigation";
import { approveAdrAction, dismissAdrAction, saveAdrAction } from "@/app/actions";
import { pagePrincipal } from "@/auth/page";
import { getDb } from "@/db/client";
import { getAdrDraft } from "@/services/adrs";
import { Badge, Flash } from "../../components";

export const dynamic = "force-dynamic";

const UUID = /^[0-9a-f-]{36}$/i;

export default async function AdrPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ msg?: string; error?: string }> }) {
  const { principal } = await pagePrincipal("viewer");
  const { id } = await params;
  const sp = await searchParams;
  if (!UUID.test(id)) notFound();
  const row = await getAdrDraft(getDb(), principal.orgId, id);
  if (!row) notFound();
  const { draft } = row;
  const canEdit = (principal.role === "architect" || principal.role === "admin") && draft.status === "pending";

  return (
    <>
      <h1>ADR {String(draft.adrNumber).padStart(4, "0")}: {draft.title} <Badge kind={draft.status} /></h1>
      <p className="muted">{row.repoName}{draft.prId ? ` · pull request #${draft.prId}` : ""}</p>
      <Flash msg={sp.msg} error={sp.error} />
      {draft.committedPath && <div className="card">Committed as <code>{draft.committedPath}</code> in commit <code>{draft.committedSha}</code>.</div>}
      {canEdit ? (
        <form action={saveAdrAction} className="card">
          <input type="hidden" name="id" value={draft.id} />
          <label>Title<input name="title" defaultValue={draft.title} maxLength={120} required /></label>
          <label>Markdown (MADR)<textarea name="markdown" defaultValue={draft.markdownContent} required /></label>
          <div className="row" style={{ marginTop: 12 }}><button type="submit" className="secondary">Save changes</button></div>
        </form>
      ) : (
        <pre className="card" style={{ whiteSpace: "pre-wrap" }}>{draft.markdownContent}</pre>
      )}
      {canEdit && (
        <div className="row">
          <form action={approveAdrAction}><input type="hidden" name="id" value={draft.id} /><button type="submit">Approve &amp; Commit ADR</button></form>
          <form action={dismissAdrAction}><input type="hidden" name="id" value={draft.id} /><button type="submit" className="danger">Dismiss</button></form>
        </div>
      )}
      {!canEdit && draft.status === "pending" && <p className="muted">Only Architects and Admins can edit or approve drafts.</p>}
      <p className="muted">Help: <Link href="/help/adr-workflow">reviewing and committing ADRs</Link></p>
    </>
  );
}
