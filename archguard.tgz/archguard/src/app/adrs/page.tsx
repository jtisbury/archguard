import Link from "next/link";
import { pagePrincipal } from "@/auth/page";
import { getDb } from "@/db/client";
import { listAdrDrafts } from "@/services/adrs";
import { Badge, Flash } from "../components";

export const dynamic = "force-dynamic";

export default async function AdrsPage({ searchParams }: { searchParams: Promise<{ msg?: string; error?: string }> }) {
  const { principal } = await pagePrincipal("viewer");
  const sp = await searchParams;
  const drafts = await listAdrDrafts(getDb(), principal.orgId, { status: "pending" });
  return (
    <>
      <h1>ADR drafts</h1>
      <p className="muted">Help: <Link href="/help/adr-workflow">reviewing and committing ADRs</Link></p>
      <Flash msg={sp.msg} error={sp.error} />
      <div className="card">
        {drafts.length === 0 ? <p className="muted">No pending drafts. Drafts appear when a pull request introduces a new pattern, dependency, schema change or service contract.</p> : (
          <table>
            <thead><tr><th>#</th><th>Title</th><th>Repository</th><th>PR</th><th>Status</th></tr></thead>
            <tbody>{drafts.map((d) => (
              <tr key={d.id}><td>{String(d.adrNumber).padStart(4, "0")}</td><td><Link href={`/adrs/${d.id}`}>{d.title}</Link></td><td>{d.repoName}</td><td>{d.prId ? `#${d.prId}` : ""}</td><td><Badge kind={d.status} /></td></tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </>
  );
}
