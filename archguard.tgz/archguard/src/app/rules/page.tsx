import Link from "next/link";
import { deleteRuleAction, saveRuleAction, toggleRuleAction } from "@/app/actions";
import { pagePrincipal } from "@/auth/page";
import { getDb } from "@/db/client";
import { listRules } from "@/services/rules";
import { Badge, Flash } from "../components";

export const dynamic = "force-dynamic";

export default async function RulesPage({ searchParams }: { searchParams: Promise<{ msg?: string; error?: string }> }) {
  const { principal } = await pagePrincipal("viewer");
  const sp = await searchParams;
  const rules = await listRules(getDb(), principal.orgId);
  const canEdit = principal.role === "architect" || principal.role === "admin";
  return (
    <>
      <h1>Guardrail rules</h1>
      <p className="muted">Help: <Link href="/help/guardrail-rules">how rules work and how to tune them</Link></p>
      <Flash msg={sp.msg} error={sp.error} />
      {rules.map((r) => (
        <div className="card" key={r.id}>
          <div className="row"><strong>{r.name}</strong> <Badge kind={r.severity} /> {!r.isEnabled && <Badge kind="dismissed">disabled</Badge>}</div>
          <p className="muted">{r.description}</p>
          {canEdit ? (
            <details>
              <summary>Edit</summary>
              <form action={saveRuleAction}>
                <input type="hidden" name="id" value={r.id} />
                <label>Name<input name="name" defaultValue={r.name} required /></label>
                <label>Description<input name="description" defaultValue={r.description} /></label>
                <label>Severity<select name="severity" defaultValue={r.severity}><option value="blocking">blocking</option><option value="warning">warning</option></select></label>
                <label>Instruction for the reviewer<textarea name="rulePrompt" defaultValue={r.rulePrompt} style={{ minHeight: 100 }} required /></label>
                <label>Target file patterns (one per line; empty = all files)<textarea name="targetPatterns" defaultValue={r.targetPatterns.join("\n")} style={{ minHeight: 70 }} /></label>
                <label><input type="checkbox" name="isEnabled" defaultChecked={r.isEnabled} style={{ width: "auto" }} /> Enabled</label>
                <div className="row" style={{ marginTop: 8 }}><button type="submit">Save</button></div>
              </form>
              <div className="row" style={{ marginTop: 8 }}>
                <form action={toggleRuleAction}><input type="hidden" name="id" value={r.id} /><input type="hidden" name="enabled" value={r.isEnabled ? "0" : "1"} /><button type="submit" className="secondary">{r.isEnabled ? "Disable" : "Enable"}</button></form>
                <form action={deleteRuleAction}><input type="hidden" name="id" value={r.id} /><button type="submit" className="danger">Delete</button></form>
              </div>
            </details>
          ) : <p className="muted">{r.rulePrompt}</p>}
        </div>
      ))}
      {canEdit && (
        <div className="card">
          <h2>New rule</h2>
          <form action={saveRuleAction}>
            <label>Name<input name="name" required /></label>
            <label>Description<input name="description" /></label>
            <label>Severity<select name="severity" defaultValue="warning"><option value="blocking">blocking</option><option value="warning">warning</option></select></label>
            <label>Instruction for the reviewer<textarea name="rulePrompt" style={{ minHeight: 100 }} required placeholder="Describe what to flag, in plain language." /></label>
            <label>Target file patterns (one per line)<textarea name="targetPatterns" style={{ minHeight: 70 }} placeholder="**/*.tf" /></label>
            <input type="hidden" name="isEnabled" value="on" />
            <div className="row" style={{ marginTop: 8 }}><button type="submit">Create rule</button></div>
          </form>
        </div>
      )}
    </>
  );
}
