import { handleWebhook } from "@/webhooks/handler";

export const dynamic = "force-dynamic";

export function POST(req: Request) {
  return handleWebhook(req);
}
