import { NextResponse } from "next/server";
import { pingDb } from "@/db/client";
import { getHealth } from "@/lib/health";
import { pingRedis } from "@/lib/redis";

export const dynamic = "force-dynamic";

export async function GET() {
  const health = await getHealth({ pingDb, pingRedis });
  return NextResponse.json(health, { status: health.status === "ok" ? 200 : 503 });
}
