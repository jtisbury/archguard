import Link from "next/link";
import { notFound } from "next/navigation";
import { getHelpPage, loadHelpPages, renderHelp } from "@/help/content";

export const dynamic = "force-dynamic";

export default async function HelpTopic({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!/^[a-z0-9-]+$/.test(slug)) notFound();
  const pages = loadHelpPages();
  const page = getHelpPage(slug, pages);
  if (!page) notFound();
  const i = pages.indexOf(page);
  const prev = pages[i - 1];
  const next = pages[i + 1];
  return (
    <>
      <h1>{page.title}</h1>
      {/* Trusted content: our own Markdown files in docs/help, rendered at request time. */}
      <div dangerouslySetInnerHTML={{ __html: renderHelp(page.body) }} />
      <hr />
      <div className="row" style={{ justifyContent: "space-between" }}>
        {prev ? <Link href={`/help/${prev.slug}`}>← {prev.title}</Link> : <span />}
        {next ? <Link href={`/help/${next.slug}`}>{next.title} →</Link> : <span />}
      </div>
    </>
  );
}
