import Link from "next/link";
import type { ReactNode } from "react";
import { loadHelpPages } from "@/help/content";

export default function HelpLayout({ children }: { children: ReactNode }) {
  const pages = loadHelpPages();
  return (
    <div className="help">
      <aside>
        <form action="/help" method="get" style={{ marginBottom: 12 }}>
          <input name="q" placeholder="Search help" aria-label="Search help" />
        </form>
        <ul>
          <li><Link href="/help">All topics</Link></li>
          {pages.map((p) => <li key={p.slug}><Link href={`/help/${p.slug}`}>{p.title}</Link></li>)}
        </ul>
      </aside>
      <article>{children}</article>
    </div>
  );
}
