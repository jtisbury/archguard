import Link from "next/link";
import { loadHelpPages, searchHelp } from "@/help/content";

export const dynamic = "force-dynamic";

export default async function HelpIndex({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const pages = loadHelpPages();
  const hits = q ? searchHelp(q, pages) : [];
  return (
    <>
      <h1>ArchGuard Help</h1>
      {q ? (
        <>
          <p className="muted">{hits.length} result{hits.length === 1 ? "" : "s"} for &ldquo;{q}&rdquo;</p>
          {hits.map((h) => (
            <div className="card" key={h.page.slug}>
              <Link href={`/help/${h.page.slug}`}><strong>{h.page.title}</strong></Link>
              <div className="muted">{h.snippet}</div>
            </div>
          ))}
          {hits.length === 0 && <p>No matches. Try a different word, or browse <Link href="/help">all topics</Link>.</p>}
        </>
      ) : (
        <>
          <p>Guides for connecting Bitbucket, understanding pull request checks, managing guardrails and approving ADRs.</p>
          <div className="grid">
            {pages.map((p) => (
              <div className="card" key={p.slug}>
                <Link href={`/help/${p.slug}`}><strong>{p.title}</strong></Link>
                <div className="muted">{p.summary}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}
