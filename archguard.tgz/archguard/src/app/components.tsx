import Link from "next/link";
import type { ReactNode } from "react";

export function Flash({ msg, error }: { msg?: string; error?: string }) {
  if (!msg && !error) return null;
  return (
    <div className="card" role="status" style={{ borderColor: error ? "var(--bad)" : "var(--ok)" }}>
      <span className={error ? "error" : undefined}>{error ?? msg}</span>
    </div>
  );
}

export function Forbidden({ need }: { need: string }) {
  return (
    <div className="card">
      <h1>Not allowed</h1>
      <p>This page requires the <strong>{need}</strong> role. Ask an administrator to add you to the matching group in your identity provider. <Link href="/help/roles-and-permissions">Learn about roles</Link>.</p>
    </div>
  );
}

export function Badge({ kind, children }: { kind: string; children?: ReactNode }) {
  return <span className={`badge ${kind}`}>{children ?? kind.replace("_", " ")}</span>;
}

export const pct = (r: number | null) => (r == null ? "n/a" : `${Math.round(r * 100)}%`);
