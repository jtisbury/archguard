import { signIn } from "@/auth";

export default function SignInPage() {
  return (
    <div className="card" style={{ maxWidth: 480 }}>
      <h1>Sign in to ArchGuard</h1>
      <p className="muted">Use your enterprise single sign-on. Access requires membership of an ArchGuard group in your identity provider.</p>
      <form
        action={async () => {
          "use server";
          await signIn("oidc", { redirectTo: "/" });
        }}
      >
        <button type="submit">Sign in with SSO</button>
      </form>
    </div>
  );
}
