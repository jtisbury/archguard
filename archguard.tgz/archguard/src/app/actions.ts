"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requirePrincipal } from "@/auth";
import { createProvider, providerFor, webhookPath } from "@/scm/factory";
import type { ScmProviderKind } from "@/scm/provider";
import { getDb, withTenant } from "@/db/client";
import { organizations } from "@/db/schema";
import { getConfig } from "@/lib/config";
import { AdrError, approveAndCommit, dismissAdrDraft, updateAdrDraft } from "@/services/adrs";
import { connectScm, disableRepository, enableRepository, syncRepositories, updateRepoSettings } from "@/services/connection";
import { deleteRule, parsePatterns, saveRule, setRuleEnabled } from "@/services/rules";

const str = (f: FormData, k: string) => String(f.get(k) ?? "");
const back = (path: string, msg: string, error = false): never =>
  redirect(`${path}${path.includes("?") ? "&" : "?"}${error ? "error" : "msg"}=${encodeURIComponent(msg)}`);

async function orgProvider(orgId: string) {
  const org = await withTenant(getDb(), orgId, async (tx) => (await tx.select().from(organizations).where(eq(organizations.id, orgId)))[0]);
  if (!org) throw new Error("Organization not found");
  return createProvider(org);
}

export async function connectAction(form: FormData) {
  const p = await requirePrincipal("admin");
  const provider = (str(form, "provider") || "bitbucket_cloud") as ScmProviderKind;
  const res = await connectScm(getDb(), p.orgId, { provider, owner: str(form, "owner"), token: str(form, "token") }, providerFor);
  revalidatePath("/settings");
  if (!res.ok) back("/settings", res.reason, true);
  else back("/settings", `Connected. ${res.repositories} repositories synced.`);
}

export async function syncAction() {
  const p = await requirePrincipal("admin");
  try {
    const n = await syncRepositories(getDb(), p.orgId, await orgProvider(p.orgId));
    revalidatePath("/settings");
    back("/settings", `${n} repositories synced.`);
  } catch (e) {
    if (e && typeof e === "object" && "digest" in e) throw e; // Next.js redirect
    back("/settings", "Sync failed. Check the Bitbucket connection.", true);
  }
}

export async function toggleRepoAction(form: FormData) {
  const p = await requirePrincipal("admin");
  const repoId = str(form, "repoId");
  const provider = await orgProvider(p.orgId);
  try {
    if (str(form, "enable") === "1") {
      const url = `${getConfig().WEBHOOK_PUBLIC_URL.replace(/\/+$/, "")}${webhookPath(provider.kind)}`;
      const r = await enableRepository(getDb(), p.orgId, repoId, provider, url);
      revalidatePath("/settings");
      back("/settings", `Repository enabled. ${r.baselineAdrs} existing ADR(s) found.`);
    } else {
      await disableRepository(getDb(), p.orgId, repoId, provider);
      revalidatePath("/settings");
      back("/settings", "Repository disabled and webhook removed.");
    }
  } catch (e) {
    if (e && typeof e === "object" && "digest" in e) throw e;
    const detail = e instanceof Error && /previous .* connection/.test(e.message) ? e.message : "Check the token's webhook and repository permissions.";
    back("/settings", `Could not change the repository. ${detail}`, true);
  }
}

export async function repoSettingsAction(form: FormData) {
  const p = await requirePrincipal("admin");
  try {
    await updateRepoSettings(getDb(), p.orgId, str(form, "repoId"), {
      structuralTriggers: parsePatterns(str(form, "triggers")),
      adrDirectoryPath: str(form, "adrDir") || "docs/adr",
    });
  } catch {
    back("/settings", "Invalid repository settings.", true);
  }
  revalidatePath("/settings");
  back("/settings", "Repository settings saved.");
}

export async function saveRuleAction(form: FormData) {
  const p = await requirePrincipal("architect");
  const id = str(form, "id") || undefined;
  try {
    await saveRule(
      getDb(),
      p,
      {
        name: str(form, "name"),
        description: str(form, "description"),
        severity: str(form, "severity") as "blocking" | "warning",
        rulePrompt: str(form, "rulePrompt"),
        targetPatterns: parsePatterns(str(form, "targetPatterns")),
        isEnabled: form.get("isEnabled") === "on",
      },
      id,
    );
  } catch {
    back("/rules", "Rule not saved. Check the name (must be unique) and instruction (10+ characters).", true);
  }
  revalidatePath("/rules");
  back("/rules", "Rule saved.");
}

export async function toggleRuleAction(form: FormData) {
  const p = await requirePrincipal("architect");
  await setRuleEnabled(getDb(), p, str(form, "id"), str(form, "enabled") === "1");
  revalidatePath("/rules");
  back("/rules", "Rule updated.");
}

export async function deleteRuleAction(form: FormData) {
  const p = await requirePrincipal("architect");
  await deleteRule(getDb(), p, str(form, "id"));
  revalidatePath("/rules");
  back("/rules", "Rule deleted.");
}

export async function saveAdrAction(form: FormData) {
  const p = await requirePrincipal("architect");
  const id = str(form, "id");
  try {
    await updateAdrDraft(getDb(), p, id, { title: str(form, "title"), markdown: str(form, "markdown") });
  } catch (e) {
    back(`/adrs/${id}`, e instanceof AdrError ? e.message : "Could not save", true);
  }
  revalidatePath(`/adrs/${id}`);
  back(`/adrs/${id}`, "Draft saved.");
}

export async function approveAdrAction(form: FormData) {
  const p = await requirePrincipal("architect");
  const id = str(form, "id");
  try {
    const provider = await orgProvider(p.orgId);
    const r = await approveAndCommit(getDb(), p, id, provider);
    revalidatePath("/adrs");
    back(`/adrs/${id}`, `Committed ${r.path}`);
  } catch (e) {
    if (e && typeof e === "object" && "digest" in e) throw e;
    back(`/adrs/${id}`, e instanceof AdrError ? e.message : "Commit failed. Check the token has write access to repository contents.", true);
  }
}

export async function dismissAdrAction(form: FormData) {
  const p = await requirePrincipal("architect");
  const id = str(form, "id");
  try {
    await dismissAdrDraft(getDb(), p, id);
  } catch (e) {
    back(`/adrs/${id}`, e instanceof AdrError ? e.message : "Could not dismiss", true);
  }
  revalidatePath("/adrs");
  back("/adrs", "Draft dismissed.");
}
