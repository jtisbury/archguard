import { and, eq } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { withTenant, type Db } from "../db/client";
import { organizations, repositories } from "../db/schema";
import { encrypt } from "../lib/vault";
import { SCM_LABELS, type IScmProvider, type ScmProviderKind } from "../scm/provider";
import { DEFAULT_STRUCTURAL_TRIGGERS } from "../triage/triggers";

export const CONNECTABLE_PROVIDERS: ScmProviderKind[] = ["bitbucket_cloud", "github"];

/** Bitbucket workspace slugs and GitHub logins share this safe character set. */
const OWNER_RE = /^[A-Za-z0-9_.-]{1,100}$/;

export type ConnectResult = { ok: true; repositories: number } | { ok: false; reason: string };

/**
 * REQ-1.1: validate credentials, store the encrypted token, then sync repositories.
 * One provider per organization: switching provider is refused while repositories are enabled,
 * so no live webhook is left pointing at a connection that no longer exists.
 */
export async function connectScm(
  db: Db,
  orgId: string,
  input: { provider: ScmProviderKind; owner: string; token: string },
  makeProvider: (provider: ScmProviderKind, owner: string, token: string) => IScmProvider,
): Promise<ConnectResult> {
  if (!CONNECTABLE_PROVIDERS.includes(input.provider)) return { ok: false, reason: `${SCM_LABELS[input.provider] ?? "This provider"} is not supported yet.` };
  const owner = input.owner.trim();
  const token = input.token.trim();
  if (!OWNER_RE.test(owner)) return { ok: false, reason: "Invalid workspace or owner name." };
  if (!token) return { ok: false, reason: "An access token is required." };

  const current = await withTenant(db, orgId, async (tx) => ({
    org: (await tx.select().from(organizations).where(eq(organizations.id, orgId)))[0],
    active: await tx.select({ id: repositories.id }).from(repositories).where(eq(repositories.isActive, true)),
  }));
  if (!current.org) return { ok: false, reason: "Organization not found." };
  const switching = !!current.org.encryptedAccessToken && current.org.scmProvider !== input.provider;
  if (switching && current.active.length > 0) {
    return {
      ok: false,
      reason: `Disable all ${SCM_LABELS[current.org.scmProvider]} repositories before connecting ${SCM_LABELS[input.provider]}.`,
    };
  }

  const provider = makeProvider(input.provider, owner, token);
  const check = await provider.validateCredentials();
  if (!check.ok) return check;

  await withTenant(db, orgId, (tx) =>
    tx
      .update(organizations)
      .set({ scmProvider: input.provider, scmOwner: owner, encryptedAccessToken: encrypt(token) })
      .where(eq(organizations.id, orgId)),
  );
  const repositoriesSynced = await syncRepositories(db, orgId, provider);
  return { ok: true, repositories: repositoriesSynced };
}

/** Upserts repositories visible to the token. New repos start inactive with default triggers. */
export async function syncRepositories(db: Db, orgId: string, provider: IScmProvider): Promise<number> {
  const repos = await provider.listRepositories();
  await withTenant(db, orgId, async (tx) => {
    for (const r of repos) {
      await tx
        .insert(repositories)
        .values({
          orgId,
          scmProvider: provider.kind,
          scmRepoId: r.id,
          repoSlug: r.slug,
          fullName: r.fullName,
          structuralTriggers: DEFAULT_STRUCTURAL_TRIGGERS,
        })
        .onConflictDoUpdate({
          target: [repositories.orgId, repositories.scmProvider, repositories.scmRepoId],
          set: { repoSlug: r.slug, fullName: r.fullName },
        });
    }
  });
  return repos.length;
}

/** Parses "0001-use-postgres.md" into a human title; non-ADR names are ignored. */
export function adrTitleFromFileName(name: string): string | null {
  const m = /^(\d{1,6})[-_](.+)\.md$/i.exec(name);
  return m ? m[2]!.replace(/[-_]+/g, " ").trim() : null;
}

async function loadRepo(db: Db, orgId: string, repoId: string, provider: IScmProvider) {
  const repo = await withTenant(db, orgId, async (tx) => (await tx.select().from(repositories).where(eq(repositories.id, repoId)))[0]);
  if (!repo) throw new Error("Repository not found");
  if (repo.scmProvider !== provider.kind) {
    throw new Error(`This repository belongs to a previous ${SCM_LABELS[repo.scmProvider]} connection.`);
  }
  return repo;
}

/**
 * REQ-1.2: register the PR webhook with a fresh HMAC secret and scan the ADR directory for
 * baseline context. Re-enabling replaces the previous webhook so exactly one exists.
 */
export async function enableRepository(
  db: Db,
  orgId: string,
  repoId: string,
  provider: IScmProvider,
  webhookUrl: string,
): Promise<{ webhookUuid: string; baselineAdrs: number }> {
  const repo = await loadRepo(db, orgId, repoId, provider);
  if (repo.webhookUuid) await provider.deleteWebhook(repo.repoSlug, repo.webhookUuid);

  const secret = randomBytes(32).toString("hex");
  const hook = await provider.createWebhook(repo.repoSlug, webhookUrl, secret);

  let titles: string[] = [];
  try {
    const mainBranch = await provider.getMainBranch(repo.repoSlug);
    const files = await provider.listFileNames(repo.repoSlug, mainBranch, repo.adrDirectoryPath);
    titles = files.map(adrTitleFromFileName).filter((t): t is string => !!t);
  } catch {
    // Baseline scan is best effort; evaluation still works without it.
  }

  await withTenant(db, orgId, (tx) =>
    tx
      .update(repositories)
      .set({ webhookUuid: hook.uuid, encryptedWebhookSecret: encrypt(secret), isActive: true, baselineAdrTitles: titles })
      .where(and(eq(repositories.id, repoId), eq(repositories.orgId, orgId))),
  );
  return { webhookUuid: hook.uuid, baselineAdrs: titles.length };
}

export async function disableRepository(db: Db, orgId: string, repoId: string, provider: IScmProvider): Promise<void> {
  const repo = await loadRepo(db, orgId, repoId, provider);
  if (repo.webhookUuid) await provider.deleteWebhook(repo.repoSlug, repo.webhookUuid);
  await withTenant(db, orgId, (tx) =>
    tx.update(repositories).set({ isActive: false, webhookUuid: null, encryptedWebhookSecret: null }).where(eq(repositories.id, repoId)),
  );
}

/** Admin edit of per-repository triage settings. */
export async function updateRepoSettings(
  db: Db,
  orgId: string,
  repoId: string,
  input: { structuralTriggers: string[]; adrDirectoryPath: string },
): Promise<void> {
  const dir = input.adrDirectoryPath.trim().replace(/^\/+|\/+$/g, "");
  if (!dir || dir.includes("..")) throw new Error("Invalid ADR directory");
  const triggers = input.structuralTriggers.map((s) => s.trim()).filter(Boolean);
  await withTenant(db, orgId, (tx) =>
    tx.update(repositories).set({ structuralTriggers: triggers, adrDirectoryPath: dir }).where(eq(repositories.id, repoId)),
  );
}
