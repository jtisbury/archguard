import { and, asc, eq } from "drizzle-orm";
import { z } from "zod";
import { requireRole, type Principal } from "../auth/roles";
import { withTenant, type Db } from "../db/client";
import { guardrailRules } from "../db/schema";

export const ruleInputSchema = z.object({
  name: z.string().trim().min(1).max(120),
  description: z.string().trim().max(500).default(""),
  severity: z.enum(["blocking", "warning"]),
  rulePrompt: z.string().trim().min(10, "The rule instruction must be at least 10 characters").max(4000),
  targetPatterns: z.array(z.string().trim().min(1).max(200)).max(50).default([]),
  isEnabled: z.boolean().default(true),
});
export type RuleInput = z.input<typeof ruleInputSchema>;

export function parsePatterns(text: string): string[] {
  return text.split(/\r?\n|,/).map((s) => s.trim()).filter(Boolean);
}

export const listRules = (db: Db, orgId: string) =>
  withTenant(db, orgId, (tx) => tx.select().from(guardrailRules).orderBy(asc(guardrailRules.name)));

export async function saveRule(db: Db, principal: Principal, input: RuleInput, id?: string) {
  requireRole(principal, "architect");
  const data = ruleInputSchema.parse(input);
  return withTenant(db, principal.orgId, async (tx) => {
    if (id) {
      const [row] = await tx.update(guardrailRules).set(data).where(and(eq(guardrailRules.id, id))).returning();
      if (!row) throw new Error("Rule not found");
      return row;
    }
    const [row] = await tx.insert(guardrailRules).values({ ...data, orgId: principal.orgId }).returning();
    return row!;
  });
}

export async function setRuleEnabled(db: Db, principal: Principal, id: string, enabled: boolean) {
  requireRole(principal, "architect");
  await withTenant(db, principal.orgId, (tx) => tx.update(guardrailRules).set({ isEnabled: enabled }).where(eq(guardrailRules.id, id)));
}

export async function deleteRule(db: Db, principal: Principal, id: string) {
  requireRole(principal, "architect");
  await withTenant(db, principal.orgId, (tx) => tx.delete(guardrailRules).where(eq(guardrailRules.id, id)));
}
