import { and, desc, eq, ilike, or } from "drizzle-orm";
import { adrFilePath, pad4 } from "../adr/madr";
import { maxAdrNumberFromFiles } from "../adr/drafts";
import type { IScmProvider } from "../scm/provider";
import { withTenant, type Db } from "../db/client";
import { adrDrafts, repositories } from "../db/schema";
import { requireRole, type Principal } from "../auth/roles";

export class AdrError extends Error {
  constructor(message: string, public readonly code: "not_found" | "not_pending" | "pr_declined" | "invalid") {
    super(message);
    this.name = "AdrError";
  }
}

export async function listAdrDrafts(db: Db, orgId: string, opts: { status?: "pending" | "approved_committed" | "dismissed"; q?: string } = {}) {
  return withTenant(db, orgId, async (tx) => {
    const where = [
      opts.status ? eq(adrDrafts.status, opts.status) : undefined,
      opts.q ? or(ilike(adrDrafts.title, `%${opts.q.replace(/[%_]/g, "\\$&")}%`), ilike(adrDrafts.markdownContent, `%${opts.q.replace(/[%_]/g, "\\$&")}%`)) : undefined,
    ].filter(Boolean);
    return tx
      .select({
        id: adrDrafts.id,
        adrNumber: adrDrafts.adrNumber,
        title: adrDrafts.title,
        status: adrDrafts.status,
        prId: adrDrafts.prId,
        committedPath: adrDrafts.committedPath,
        createdAt: adrDrafts.createdAt,
        repoName: repositories.fullName,
      })
      .from(adrDrafts)
      .innerJoin(repositories, eq(repositories.id, adrDrafts.repoId))
      .where(and(...(where as never[])))
      .orderBy(desc(adrDrafts.createdAt));
  });
}

export async function getAdrDraft(db: Db, orgId: string, id: string) {
  return withTenant(db, orgId, async (tx) => {
    const [row] = await tx
      .select({ draft: adrDrafts, repoName: repositories.fullName })
      .from(adrDrafts)
      .innerJoin(repositories, eq(repositories.id, adrDrafts.repoId))
      .where(eq(adrDrafts.id, id));
    return row ?? null;
  });
}

export async function updateAdrDraft(db: Db, principal: Principal, id: string, input: { title: string; markdown: string }) {
  requireRole(principal, "architect");
  const title = input.title.trim();
  if (!title || title.length > 120) throw new AdrError("Title must be 1-120 characters", "invalid");
  if (!input.markdown.trim()) throw new AdrError("ADR content cannot be empty", "invalid");
  const rows = await withTenant(db, principal.orgId, (tx) =>
    tx
      .update(adrDrafts)
      .set({ title, markdownContent: input.markdown })
      .where(and(eq(adrDrafts.id, id), eq(adrDrafts.status, "pending")))
      .returning({ id: adrDrafts.id }),
  );
  if (!rows.length) throw new AdrError("Draft not found or no longer pending", "not_pending");
}

export async function dismissAdrDraft(db: Db, principal: Principal, id: string) {
  requireRole(principal, "architect");
  const rows = await withTenant(db, principal.orgId, (tx) =>
    tx.update(adrDrafts).set({ status: "dismissed" }).where(and(eq(adrDrafts.id, id), eq(adrDrafts.status, "pending"))).returning({ id: adrDrafts.id }),
  );
  if (!rows.length) throw new AdrError("Draft not found or no longer pending", "not_pending");
}

/**
 * REQ-2.8: commit the approved ADR to the PR source branch (or the target branch once merged).
 * The draft row is locked (SELECT … FOR UPDATE) for the duration, so a double click can never
 * commit twice: the second caller waits, then sees the draft is no longer pending.
 */
export async function approveAndCommit(
  db: Db,
  principal: Principal,
  id: string,
  provider: IScmProvider,
): Promise<{ path: string; commitSha: string; adrNumber: number }> {
  requireRole(principal, "architect");
  return withTenant(db, principal.orgId, async (tx) => {
    const [draft] = await tx.select().from(adrDrafts).where(eq(adrDrafts.id, id)).for("update");
    if (!draft) throw new AdrError("Draft not found", "not_found");
    if (draft.status !== "pending") throw new AdrError("Draft is no longer pending", "not_pending");
    const [repo] = await tx.select().from(repositories).where(eq(repositories.id, draft.repoId));
    if (!repo) throw new AdrError("Repository not found", "not_found");

    let branch: string;
    if (draft.prId == null) throw new AdrError("Draft is not linked to a pull request", "invalid");
    const pr = await provider.getPullRequest(repo.repoSlug, draft.prId);
    if (pr.state === "OPEN") branch = pr.sourceBranch;
    else if (pr.state === "MERGED") branch = pr.destinationBranch;
    else throw new AdrError("The pull request was declined; the ADR cannot be committed", "pr_declined");

    // Resolve number collisions against what is on the branch right now.
    const dir = repo.adrDirectoryPath;
    const existing = await provider.listFileNames(repo.repoSlug, branch, dir);
    const taken = existing.some((f) => new RegExp(`^${pad4(draft.adrNumber)}[-_]`).test(f));
    let number = draft.adrNumber;
    let markdown = draft.markdownContent;
    if (taken) {
      number = maxAdrNumberFromFiles(existing) + 1;
      markdown = markdown.replace(/^# \d+\./m, `# ${pad4(number)}.`);
    }
    const path = adrFilePath(dir, number, draft.title);
    const { commitSha } = await provider.commitFile(repo.repoSlug, {
      branch,
      path,
      content: markdown,
      message: `docs(adr): ${pad4(number)} ${draft.title} (approved via ArchGuard)`,
    });
    await tx
      .update(adrDrafts)
      .set({ status: "approved_committed", adrNumber: number, markdownContent: markdown, committedSha: commitSha, committedPath: path })
      .where(eq(adrDrafts.id, id));
    return { path, commitSha, adrNumber: number };
  });
}
