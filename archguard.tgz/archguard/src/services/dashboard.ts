import { desc, eq, gte } from "drizzle-orm";
import { withTenant, type Db } from "../db/client";
import { adrDrafts, prEvaluations, repositories, type Violation } from "../db/schema";
import { listAdrDrafts } from "./adrs";

export const DRIFT_WINDOW_DAYS = 14;
export const DRIFT_MIN_PRS = 3;
export const COMPLIANCE_WINDOW_DAYS = 30;

export interface RepoCompliance {
  repoId: string;
  repoName: string;
  isActive: boolean;
  passed: number;
  failed: number;
  neutral: number;
  /** passed / (passed + failed) over the latest evaluation of each PR; null when nothing was decided. */
  complianceRate: number | null;
}
export interface DriftAlert {
  repoName: string;
  ruleName: string;
  prCount: number;
}
export interface DashboardData {
  repos: RepoCompliance[];
  overallRate: number | null;
  driftAlerts: DriftAlert[];
  pendingDrafts: number;
  recentFailures: { repoName: string; prId: number; prTitle: string; createdAt: Date }[];
}

const daysAgo = (d: number, now: Date) => new Date(now.getTime() - d * 86_400_000);

/**
 * Compliance counts the latest evaluation per pull request in the last 30 days.
 * Drift alert = the same rule violated in 3+ distinct PRs of one repository in the last 14 days.
 */
export async function getDashboard(db: Db, orgId: string, now = new Date()): Promise<DashboardData> {
  return withTenant(db, orgId, async (tx) => {
    const repos = await tx.select().from(repositories);
    const evals = await tx
      .select()
      .from(prEvaluations)
      .where(gte(prEvaluations.createdAt, daysAgo(COMPLIANCE_WINDOW_DAYS, now)))
      .orderBy(desc(prEvaluations.createdAt))
      .limit(5000);
    const pending = await tx.select({ id: adrDrafts.id }).from(adrDrafts).where(eq(adrDrafts.status, "pending"));

    const latest = new Map<string, (typeof evals)[number]>();
    for (const e of evals) {
      const k = `${e.repoId}:${e.prId}`;
      if (!latest.has(k)) latest.set(k, e);
    }
    const byRepo = new Map<string, RepoCompliance>(
      repos.map((r) => [r.id, { repoId: r.id, repoName: r.fullName, isActive: r.isActive, passed: 0, failed: 0, neutral: 0, complianceRate: null }]),
    );
    for (const e of latest.values()) {
      const r = byRepo.get(e.repoId);
      if (r) r[e.status]++;
    }
    for (const r of byRepo.values()) {
      const decided = r.passed + r.failed;
      r.complianceRate = decided ? r.passed / decided : null;
    }
    const all = [...byRepo.values()];
    const totalPassed = all.reduce((s, r) => s + r.passed, 0);
    const totalDecided = all.reduce((s, r) => s + r.passed + r.failed, 0);

    const driftCut = daysAgo(DRIFT_WINDOW_DAYS, now);
    const names = new Map(repos.map((r) => [r.id, r.fullName]));
    const hits = new Map<string, Set<number>>();
    for (const e of latest.values()) {
      if (e.createdAt < driftCut) continue;
      for (const v of e.violations as Violation[]) {
        const k = `${e.repoId}|${v.ruleName}`;
        (hits.get(k) ?? hits.set(k, new Set()).get(k)!).add(e.prId);
      }
    }
    const driftAlerts: DriftAlert[] = [...hits]
      .filter(([, prs]) => prs.size >= DRIFT_MIN_PRS)
      .map(([k, prs]) => {
        const [repoId, ruleName] = k.split("|") as [string, string];
        return { repoName: names.get(repoId) ?? repoId, ruleName, prCount: prs.size };
      })
      .sort((a, b) => b.prCount - a.prCount);

    return {
      repos: all.sort((a, b) => a.repoName.localeCompare(b.repoName)),
      overallRate: totalDecided ? totalPassed / totalDecided : null,
      driftAlerts,
      pendingDrafts: pending.length,
      recentFailures: [...latest.values()]
        .filter((e) => e.status === "failed")
        .slice(0, 10)
        .map((e) => ({ repoName: names.get(e.repoId) ?? "", prId: e.prId, prTitle: e.prTitle, createdAt: e.createdAt })),
    };
  });
}

export function approvedTimeline(db: Db, orgId: string, q?: string) {
  return listAdrDrafts(db, orgId, { status: "approved_committed", q });
}
