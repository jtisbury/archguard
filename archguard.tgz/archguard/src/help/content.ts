import fs from "node:fs";
import path from "node:path";
import { marked } from "marked";

export interface HelpPage {
  slug: string;
  title: string;
  order: number;
  summary: string;
  body: string;
}

export const HELP_DIR = path.resolve(process.cwd(), "docs", "help");

function parseFrontMatter(raw: string): { meta: Record<string, string>; body: string } {
  const m = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(raw);
  if (!m) return { meta: {}, body: raw };
  const meta: Record<string, string> = {};
  for (const line of m[1]!.split(/\r?\n/)) {
    const kv = /^([A-Za-z_]+):\s*(.*)$/.exec(line);
    if (kv) meta[kv[1]!] = kv[2]!.trim();
  }
  return { meta, body: m[2]! };
}

export function loadHelpPages(dir = HELP_DIR): HelpPage[] {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".md"))
    .map((f) => {
      const { meta, body } = parseFrontMatter(fs.readFileSync(path.join(dir, f), "utf8"));
      const slug = f.replace(/\.md$/, "");
      return { slug, title: meta.title ?? slug, order: Number(meta.order ?? 999), summary: meta.summary ?? "", body };
    })
    .sort((a, b) => a.order - b.order || a.title.localeCompare(b.title));
}

export function getHelpPage(slug: string, pages = loadHelpPages()): HelpPage | undefined {
  return pages.find((p) => p.slug === slug);
}

/** Renders our own trusted Markdown. Relative links `slug` or `slug#anchor` become /help/ links. */
export function renderHelp(body: string): string {
  const html = marked.parse(body, { async: false, gfm: true }) as string;
  const withIds = html.replace(/<h([23])>(.*?)<\/h\1>/g, (_m, lvl: string, inner: string) => {
    const id = inner.replace(/<[^>]+>/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    return `<h${lvl} id="${id}">${inner}</h${lvl}>`;
  });
  return withIds.replace(/href="(?!https?:|\/|#|mailto:)([a-z0-9-]+)(#[^"]*)?"/g, (_m, slug: string, hash = "") => `href="/help/${slug}${hash}"`);
}

export interface SearchHit {
  page: HelpPage;
  score: number;
  snippet: string;
}

// Drop link targets "](url)" only; keep ordinary parenthesised text.
const strip = (s: string) => s.replace(/\]\([^)]*\)/g, "]").replace(/[#*`>|_\[\]]/g, " ").replace(/\s+/g, " ").trim();

export function searchHelp(query: string, pages = loadHelpPages()): SearchHit[] {
  const terms = query.toLowerCase().split(/\s+/).filter((t) => t.length > 1);
  if (!terms.length) return [];
  const hits: SearchHit[] = [];
  for (const page of pages) {
    const title = page.title.toLowerCase();
    const body = strip(page.body);
    const lower = body.toLowerCase();
    let score = 0;
    for (const t of terms) {
      if (title.includes(t)) score += 10;
      if (page.summary.toLowerCase().includes(t)) score += 4;
      const count = lower.split(t).length - 1;
      score += Math.min(count, 5);
    }
    if (score === 0) continue;
    const idx = lower.indexOf(terms.find((t) => lower.includes(t)) ?? "");
    const start = Math.max(0, idx - 60);
    const snippet = idx >= 0 ? (start > 0 ? "…" : "") + body.slice(start, start + 200) + "…" : page.summary;
    hits.push({ page, score, snippet });
  }
  return hits.sort((a, b) => b.score - a.score);
}

const LINK_RE = /\]\(([^)\s]+)\)/g;

/** Returns human readable problems: broken internal links, missing titles, duplicate slugs. */
export function checkHelp(pages = loadHelpPages()): string[] {
  const problems: string[] = [];
  const slugs = new Set(pages.map((p) => p.slug));
  for (const p of pages) {
    if (!p.title || p.title === p.slug) problems.push(`${p.slug}: missing title in front matter`);
    if (!p.summary) problems.push(`${p.slug}: missing summary in front matter`);
    const anchors = new Set([...p.body.matchAll(/^#{2,3}\s+(.+)$/gm)].map((m) => m[1]!.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")));
    for (const m of p.body.matchAll(LINK_RE)) {
      const href = m[1]!;
      if (/^(https?:|mailto:)/.test(href)) continue;
      if (href.startsWith("#")) {
        if (!anchors.has(href.slice(1))) problems.push(`${p.slug}: broken anchor ${href}`);
        continue;
      }
      if (href.startsWith("/")) {
        const target = /^\/help\/([a-z0-9-]+)(#.*)?$/.exec(href);
        if (target) {
          if (!slugs.has(target[1]!)) problems.push(`${p.slug}: broken link ${href}`);
        } else if (!/^\/(adrs|rules|settings|signin)?$/.test(href)) {
          problems.push(`${p.slug}: unknown app link ${href}`);
        }
        continue;
      }
      const [slug, hash] = href.split("#");
      const target = pages.find((x) => x.slug === slug);
      if (!target) problems.push(`${p.slug}: broken link ${href}`);
      else if (hash) {
        const ta = new Set([...target.body.matchAll(/^#{2,3}\s+(.+)$/gm)].map((mm) => mm[1]!.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")));
        if (!ta.has(hash)) problems.push(`${p.slug}: broken anchor ${href}`);
      }
    }
  }
  return problems;
}
