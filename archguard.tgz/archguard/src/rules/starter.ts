import { and, eq } from "drizzle-orm";
import type { Tx } from "../db/client";
import { guardrailRules, type Severity } from "../db/schema";

export interface StarterRule {
  name: string;
  description: string;
  severity: Severity;
  rulePrompt: string;
  targetPatterns: string[];
}

export const STARTER_RULES: StarterRule[] = [
  {
    name: "No Cross-Domain Database Coupling",
    description: "A service must not import ORM entities, schemas or DB connection config owned by another bounded context.",
    severity: "blocking",
    rulePrompt:
      "Flag changes where code in one service/bounded context imports ORM entities, table schemas, repositories or database connection configuration that belong to a different bounded context. Cross-domain data access must go through that domain's API or events.",
    targetPatterns: ["**/*.ts", "**/*.java", "**/*.py", "**/*.go", "**/*.cs"],
  },
  {
    name: "Breaking API Contract Detection",
    description: "OpenAPI, GraphQL or Protobuf changes must not remove fields, change types or add required parameters without versioning.",
    severity: "blocking",
    rulePrompt:
      "Flag modifications to OpenAPI/Swagger, GraphQL or Protobuf definitions that remove fields or operations, change field types, rename fields, or make an optional parameter required, unless the API version is also incremented.",
    targetPatterns: ["**/openapi*.y*ml", "**/openapi*.json", "**/swagger*.y*ml", "**/*.graphql", "**/*.gql", "**/*.proto"],
  },
  {
    name: "Unapproved Cloud / IaC Provisioning",
    description: "IaC must not introduce non-standard cloud services or permissive IAM / network rules.",
    severity: "blocking",
    rulePrompt:
      "Flag Terraform, AWS CDK or CloudFormation changes that provision cloud services outside the approved catalogue, or that introduce permissive access: IAM policies with wildcard actions or resources, security groups open to 0.0.0.0/0, or public storage buckets.",
    targetPatterns: ["**/*.tf", "**/*.tfvars", "**/cdk/**", "**/cloudformation/**", "**/*template*.y*ml"],
  },
  {
    name: "Destructive Schema Migration Guard",
    description: "Migrations must not drop tables/columns unsafely or add foreign keys without an index.",
    severity: "blocking",
    rulePrompt:
      "Flag database migrations (Liquibase, Flyway, Prisma, raw SQL) that contain DROP TABLE or DROP COLUMN, or that add a foreign key without a supporting index on the referencing column.",
    targetPatterns: ["**/migrations/**", "**/db/changelog/**", "**/*.sql", "**/prisma/**"],
  },
  {
    name: "New External Dependency & License Check",
    description: "A newly added library requires an ADR and a license review.",
    severity: "warning",
    rulePrompt:
      "Flag any newly added third-party dependency in package.json, pom.xml, build.gradle, go.mod or requirements.txt. Report each as a warning and note that an ADR is required. Mention if the license is unknown or copyleft.",
    targetPatterns: ["**/package.json", "**/pom.xml", "**/build.gradle", "**/go.mod", "**/requirements.txt"],
  },
];

/** Idempotently seeds the starter rules for an organization (call inside withTenant). */
export async function seedStarterRules(tx: Tx, orgId: string): Promise<number> {
  let inserted = 0;
  for (const r of STARTER_RULES) {
    const existing = await tx
      .select({ id: guardrailRules.id })
      .from(guardrailRules)
      .where(and(eq(guardrailRules.orgId, orgId), eq(guardrailRules.name, r.name)));
    if (existing.length) continue;
    await tx.insert(guardrailRules).values({ orgId, ...r, isEnabled: true });
    inserted++;
  }
  return inserted;
}
