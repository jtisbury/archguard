import { getConfig } from "../lib/config";
import { BedrockProvider } from "./bedrock";
import { OpenAiCompatibleProvider } from "./openai";
import type { ILlmProvider } from "./types";

export function createLlmProvider(cfg = getConfig()): ILlmProvider {
  if (!cfg.LLM_MODEL) throw new Error("LLM_MODEL is not configured");
  if (cfg.LLM_PROVIDER === "bedrock") return new BedrockProvider({ region: cfg.AWS_REGION, modelId: cfg.LLM_MODEL });
  if (!cfg.OPENAI_BASE_URL || !cfg.OPENAI_API_KEY) throw new Error("OPENAI_BASE_URL and OPENAI_API_KEY are required");
  return new OpenAiCompatibleProvider({ baseUrl: cfg.OPENAI_BASE_URL, apiKey: cfg.OPENAI_API_KEY, model: cfg.LLM_MODEL });
}
