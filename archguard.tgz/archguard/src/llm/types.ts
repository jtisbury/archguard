import { z } from "zod";

export interface StructuredRequest {
  system: string;
  user: string;
  schemaName: string;
  /** Strict JSON Schema the model output must satisfy. */
  jsonSchema: Record<string, unknown>;
}

export interface StructuredResponse {
  /** Parsed JSON object from the provider (still untrusted: validate with zod). */
  data: unknown;
  tokensUsed: number;
}

/** Pluggable LLM boundary (Bedrock / Azure / OpenAI-compatible). */
export interface ILlmProvider {
  generateStructured(req: StructuredRequest): Promise<StructuredResponse>;
}

export const violationSchema = z.object({
  ruleName: z.string().min(1),
  severity: z.enum(["blocking", "warning"]),
  filePath: z.string().min(1),
  line: z.number().int().nonnegative().nullable(),
  message: z.string().min(1),
  remediation: z.string(),
});

export const adrDraftSchema = z.object({
  title: z.string().min(3).max(120),
  context: z.string().min(1),
  decisionDrivers: z.array(z.string()).min(1),
  consideredOptions: z.array(z.object({ name: z.string().min(1), pros: z.array(z.string()), cons: z.array(z.string()) })).min(1),
  decisionOutcome: z.string().min(1),
  consequences: z.array(z.string()).min(1),
});

export const evaluationSchema = z.object({
  violations: z.array(violationSchema),
  adrDraft: adrDraftSchema.nullable(),
});

export type EvaluationResult = z.infer<typeof evaluationSchema>;
export type AdrDraftData = z.infer<typeof adrDraftSchema>;

/** JSON Schema sent to providers (strict structured output). Kept in sync with evaluationSchema by tests. */
export const EVALUATION_JSON_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: ["violations", "adrDraft"],
  properties: {
    violations: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["ruleName", "severity", "filePath", "line", "message", "remediation"],
        properties: {
          ruleName: { type: "string" },
          severity: { type: "string", enum: ["blocking", "warning"] },
          filePath: { type: "string" },
          line: { type: ["integer", "null"] },
          message: { type: "string" },
          remediation: { type: "string" },
        },
      },
    },
    adrDraft: {
      type: ["object", "null"],
      additionalProperties: false,
      required: ["title", "context", "decisionDrivers", "consideredOptions", "decisionOutcome", "consequences"],
      properties: {
        title: { type: "string" },
        context: { type: "string" },
        decisionDrivers: { type: "array", items: { type: "string" } },
        consideredOptions: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["name", "pros", "cons"],
            properties: {
              name: { type: "string" },
              pros: { type: "array", items: { type: "string" } },
              cons: { type: "array", items: { type: "string" } },
            },
          },
        },
        decisionOutcome: { type: "string" },
        consequences: { type: "array", items: { type: "string" } },
      },
    },
  },
} as const;
