import { BedrockRuntimeClient, ConverseCommand, type ConverseCommandInput, type ConverseCommandOutput } from "@aws-sdk/client-bedrock-runtime";
import type { ILlmProvider, StructuredRequest, StructuredResponse } from "./types";

export interface BedrockOptions {
  region: string;
  /** Model or inference-profile id, e.g. an Anthropic Claude model enabled in your account. */
  modelId: string;
  send?: (input: ConverseCommandInput) => Promise<ConverseCommandOutput>;
}

/**
 * AWS Bedrock (Converse API). Structured output is enforced by forcing a single tool whose
 * input schema is the JSON Schema; the model must answer by calling it.
 */
export class BedrockProvider implements ILlmProvider {
  private readonly send: (input: ConverseCommandInput) => Promise<ConverseCommandOutput>;
  constructor(private readonly o: BedrockOptions) {
    if (o.send) this.send = o.send;
    else {
      const client = new BedrockRuntimeClient({ region: o.region });
      this.send = (input) => client.send(new ConverseCommand(input));
    }
  }

  async generateStructured(req: StructuredRequest): Promise<StructuredResponse> {
    const toolName = req.schemaName.replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 64);
    const out = await this.send({
      modelId: this.o.modelId,
      system: [{ text: req.system }],
      messages: [{ role: "user", content: [{ text: req.user }] }],
      inferenceConfig: { temperature: 0, maxTokens: 4096 },
      toolConfig: {
        tools: [{ toolSpec: { name: toolName, description: "Return the evaluation result.", inputSchema: { json: req.jsonSchema as never } } }],
        toolChoice: { tool: { name: toolName } },
      },
    });
    const block = out.output?.message?.content?.find((c) => c.toolUse);
    if (!block?.toolUse) throw new Error("Bedrock returned no structured tool output");
    return { data: block.toolUse.input, tokensUsed: (out.usage?.inputTokens ?? 0) + (out.usage?.outputTokens ?? 0) };
  }
}
