import type { ILlmProvider, StructuredRequest, StructuredResponse } from "./types";

export interface OpenAiOptions {
  baseUrl: string;
  apiKey: string;
  model: string;
  fetchImpl?: typeof fetch;
}

/**
 * OpenAI-compatible chat completions with strict JSON Schema structured output.
 * Works with Azure OpenAI (set OPENAI_BASE_URL to the deployment URL, e.g.
 * https://<res>.openai.azure.com/openai/deployments/<name>?api-version=...) and OpenAI-style gateways.
 */
export class OpenAiCompatibleProvider implements ILlmProvider {
  constructor(private readonly o: OpenAiOptions) {}

  async generateStructured(req: StructuredRequest): Promise<StructuredResponse> {
    const f = this.o.fetchImpl ?? fetch;
    const base = this.o.baseUrl.replace(/\/+$/, "");
    const [path, query] = base.split("?");
    const url = `${path}/chat/completions${query ? `?${query}` : ""}`;
    const azure = /openai\.azure\.com/i.test(base);
    const res = await f(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(azure ? { "api-key": this.o.apiKey } : { Authorization: `Bearer ${this.o.apiKey}` }),
      },
      body: JSON.stringify({
        model: this.o.model,
        temperature: 0,
        messages: [
          { role: "system", content: req.system },
          { role: "user", content: req.user },
        ],
        response_format: { type: "json_schema", json_schema: { name: req.schemaName, strict: true, schema: req.jsonSchema } },
      }),
    });
    if (!res.ok) throw new Error(`LLM request failed with status ${res.status}`);
    const json = (await res.json()) as {
      choices?: { message?: { content?: string | null; refusal?: string | null } }[];
      usage?: { total_tokens?: number };
    };
    const content = json.choices?.[0]?.message?.content;
    if (!content) throw new Error("LLM returned no content");
    let data: unknown;
    try {
      data = JSON.parse(content);
    } catch {
      throw new LlmOutputError("LLM output was not valid JSON");
    }
    return { data, tokensUsed: json.usage?.total_tokens ?? 0 };
  }
}

export class LlmOutputError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "LlmOutputError";
  }
}
