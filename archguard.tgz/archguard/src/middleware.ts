import { NextResponse, type NextRequest } from "next/server";

/**
 * Coarse gate: requires a session cookie for dashboard pages. Real authorization (role checks)
 * happens server-side via requirePrincipal(); the cookie is a signed, verified JWT there.
 */
const PUBLIC = [/^\/api\/health/, /^\/api\/webhooks\//, /^\/api\/auth\//, /^\/signin/, /^\/help/, /^\/_next\//, /^\/favicon/];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC.some((re) => re.test(pathname))) return NextResponse.next();
  const hasSession = req.cookies.has("authjs.session-token") || req.cookies.has("__Secure-authjs.session-token");
  if (hasSession) return NextResponse.next();
  if (pathname.startsWith("/api/")) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  const url = req.nextUrl.clone();
  url.pathname = "/signin";
  return NextResponse.redirect(url);
}

export const config = { matcher: ["/((?!.*\\..*).*)"] };
