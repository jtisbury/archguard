import picomatch from "picomatch";

/** Default structural triggers (REQ-2.1). Editable per repository. */
export const DEFAULT_STRUCTURAL_TRIGGERS = [
  "**/*.tf",
  "**/*.tfvars",
  "**/Dockerfile*",
  "**/docker-compose*",
  "**/migrations/**",
  "**/db/changelog/**",
  "**/openapi*.y*ml",
  "**/openapi*.json",
  "**/swagger*.y*ml",
  "**/*.proto",
  "**/*.graphql",
  "**/package.json",
  "**/pom.xml",
  "**/build.gradle",
  "**/go.mod",
  "**/requirements.txt",
];

/** Returns the changed paths that match at least one structural trigger. */
export function matchStructuralPaths(paths: string[], triggers: string[]): string[] {
  if (triggers.length === 0) return [];
  const isMatch = picomatch(triggers, { dot: true, nocase: true });
  return paths.filter((p) => isMatch(p.replace(/\\/g, "/")));
}
