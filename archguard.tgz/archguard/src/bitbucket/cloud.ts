import {
  ScmError as BitbucketError,
  type BuildStatusInput,
  type CommitFileInput,
  type DiffstatEntry,
  type IScmProvider,
  type PullRequestInfo,
  type RepoInfo,
} from "../scm/provider";

export const STATUS_KEY = "ARCHGUARD";
export const BITBUCKET_WEBHOOK_EVENTS = ["pullrequest:created", "pullrequest:updated"];
const API = "https://api.bitbucket.org/2.0";

type FetchLike = typeof fetch;

export interface CloudOptions {
  workspace: string;
  token: string;
  fetchImpl?: FetchLike;
  baseUrl?: string;
  /** Delay between retries on 429/5xx; tests set 0. */
  retryDelayMs?: number;
}

interface Paged<T> {
  values: T[];
  next?: string;
}

/** Bitbucket Cloud REST v2.0 adapter authenticated with a Workspace Access Token (Bearer). */
export class BitbucketCloudAdapter implements IScmProvider {
  readonly kind = "bitbucket_cloud" as const;
  private readonly f: FetchLike;
  private readonly base: string;
  constructor(private readonly o: CloudOptions) {
    this.f = o.fetchImpl ?? fetch;
    this.base = o.baseUrl ?? API;
  }

  private repoPath(slug: string) {
    return `${this.base}/repositories/${encodeURIComponent(this.o.workspace)}/${encodeURIComponent(slug)}`;
  }

  private async request(url: string, init: RequestInit = {}, attempt = 0): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set("Authorization", `Bearer ${this.o.token}`);
    headers.set("Accept", headers.get("Accept") ?? "application/json");
    const res = await this.f(url, { ...init, headers, redirect: "follow" });
    if ((res.status === 429 || res.status >= 500) && attempt < 2) {
      await new Promise((r) => setTimeout(r, this.o.retryDelayMs ?? 500 * (attempt + 1)));
      return this.request(url, init, attempt + 1);
    }
    if (!res.ok) {
      // Never include response bodies that could echo source code; status + short text only.
      throw new BitbucketError(`Bitbucket ${init.method ?? "GET"} ${new URL(url).pathname} failed: ${res.status}`, res.status);
    }
    return res;
  }

  private async json<T>(url: string, init?: RequestInit): Promise<T> {
    return (await this.request(url, init)).json() as Promise<T>;
  }

  private async all<T>(firstUrl: string): Promise<T[]> {
    const out: T[] = [];
    let url: string | undefined = firstUrl;
    let guard = 0;
    while (url && guard++ < 200) {
      const page: Paged<T> = await this.json<Paged<T>>(url);
      out.push(...page.values);
      url = page.next;
    }
    return out;
  }

  async validateCredentials() {
    try {
      await this.json(`${this.base}/repositories/${encodeURIComponent(this.o.workspace)}?pagelen=1`);
      return { ok: true as const };
    } catch (e) {
      const status = e instanceof BitbucketError ? e.status : 0;
      const reason =
        status === 401 ? "The access token was rejected (401)." :
        status === 403 ? "The token lacks repository read scope (403)." :
        status === 404 ? "Workspace not found (404). Check the workspace slug." :
        "Could not reach Bitbucket.";
      return { ok: false as const, reason };
    }
  }

  async listRepositories(): Promise<RepoInfo[]> {
    const raw = await this.all<{ uuid: string; slug: string; full_name: string }>(
      `${this.base}/repositories/${encodeURIComponent(this.o.workspace)}?pagelen=100&fields=next,values.uuid,values.slug,values.full_name`,
    );
    return raw.map((r) => ({ id: r.uuid, slug: r.slug, fullName: r.full_name }));
  }

  async getMainBranch(repoSlug: string): Promise<string> {
    const r = await this.json<{ mainbranch?: { name: string } }>(`${this.repoPath(repoSlug)}?fields=mainbranch.name`);
    return r.mainbranch?.name ?? "main";
  }

  async createWebhook(repoSlug: string, url: string, secret: string) {
    const res = await this.json<{ uuid: string }>(`${this.repoPath(repoSlug)}/hooks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ description: "ArchGuard", url, active: true, secret, events: BITBUCKET_WEBHOOK_EVENTS }),
    });
    return { uuid: res.uuid };
  }

  async deleteWebhook(repoSlug: string, webhookUuid: string) {
    try {
      await this.request(`${this.repoPath(repoSlug)}/hooks/${encodeURIComponent(webhookUuid)}`, { method: "DELETE" });
    } catch (e) {
      if (e instanceof BitbucketError && e.status === 404) return; // already gone
      throw e;
    }
  }

  async getPullRequest(repoSlug: string, prId: number): Promise<PullRequestInfo> {
    const pr = await this.json<{
      id: number;
      title: string;
      state: PullRequestInfo["state"];
      source: { branch: { name: string }; commit: { hash: string } };
      destination: { branch: { name: string } };
    }>(`${this.repoPath(repoSlug)}/pullrequests/${prId}`);
    return {
      id: pr.id,
      title: pr.title,
      state: pr.state,
      sourceBranch: pr.source.branch.name,
      destinationBranch: pr.destination.branch.name,
      sourceCommit: pr.source.commit.hash,
    };
  }

  async getDiffstat(repoSlug: string, prId: number): Promise<DiffstatEntry[]> {
    const raw = await this.all<{ status: string; old: { path: string } | null; new: { path: string } | null }>(
      `${this.repoPath(repoSlug)}/pullrequests/${prId}/diffstat?pagelen=500`,
    );
    return raw.flatMap((e) => {
      const path = e.new?.path ?? e.old?.path;
      return path ? [{ status: e.status, path, oldPath: e.old?.path }] : [];
    });
  }

  async getDiff(repoSlug: string, prId: number): Promise<string> {
    const res = await this.request(`${this.repoPath(repoSlug)}/pullrequests/${prId}/diff`, { headers: { Accept: "text/plain" } });
    return res.text();
  }

  async postBuildStatus(repoSlug: string, commitSha: string, s: BuildStatusInput) {
    await this.request(`${this.repoPath(repoSlug)}/commit/${encodeURIComponent(commitSha)}/statuses/build`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        key: STATUS_KEY,
        name: "ArchGuard",
        state: s.state,
        description: s.description.slice(0, 255),
        refname: s.refname,
        ...(s.url ? { url: s.url } : { url: "https://archguard.invalid/" }),
      }),
    });
  }

  async upsertPullRequestComment(repoSlug: string, prId: number, body: string, existingCommentId?: string) {
    const base = `${this.repoPath(repoSlug)}/pullrequests/${prId}/comments`;
    const payload = JSON.stringify({ content: { raw: body } });
    const headers = { "Content-Type": "application/json" };
    if (existingCommentId) {
      try {
        const r = await this.json<{ id: number }>(`${base}/${existingCommentId}`, { method: "PUT", headers, body: payload });
        return String(r.id);
      } catch (e) {
        // Comment deleted by a user: fall through and create a new one.
        if (!(e instanceof BitbucketError && (e.status === 404 || e.status === 403))) throw e;
      }
    }
    const r = await this.json<{ id: number }>(base, { method: "POST", headers, body: payload });
    return String(r.id);
  }

  async listFileNames(repoSlug: string, ref: string, dir: string): Promise<string[]> {
    const clean = dir.replace(/^\/+|\/+$/g, "");
    try {
      const entries = await this.all<{ path: string; type: string }>(
        `${this.repoPath(repoSlug)}/src/${encodeURIComponent(ref)}/${clean.split("/").map(encodeURIComponent).join("/")}/?pagelen=100`,
      );
      return entries.filter((e) => e.type === "commit_file").map((e) => e.path.split("/").pop()!);
    } catch (e) {
      if (e instanceof BitbucketError && e.status === 404) return [];
      throw e;
    }
  }

  async commitFile(repoSlug: string, input: CommitFileInput): Promise<{ commitSha: string }> {
    const form = new FormData();
    form.set(input.path, input.content); // field name = file path, value = file content
    form.set("message", input.message);
    form.set("branch", input.branch);
    const res = await this.request(`${this.repoPath(repoSlug)}/src`, { method: "POST", body: form });
    // Bitbucket returns the new commit URL in Location (…/commit/<sha>).
    const loc = res.headers.get("location") ?? "";
    const sha = loc.split("/").filter(Boolean).pop() ?? "";
    return { commitSha: sha };
  }
}
