import type { IScmProvider } from "../scm/provider";

const NOT_IMPLEMENTED = "BitbucketDataCenterAdapter is not implemented yet (Bitbucket Cloud is supported).";

/**
 * Stub for Bitbucket Data Center. Planned mapping (not implemented):
 *  - build status: POST /rest/build-status/1.0/commits/{commitId}
 *  - PR diff/changes: /rest/api/1.0/projects/{p}/repos/{r}/pull-requests/{id}/(diff|changes)
 *  - webhook events: pr:opened, pr:from_ref_updated
 */
export class BitbucketDataCenterAdapter implements IScmProvider {
  readonly kind = "bitbucket_datacenter" as const;
  private fail(): never {
    throw new Error(NOT_IMPLEMENTED);
  }
  validateCredentials = async () => this.fail();
  listRepositories = async () => this.fail();
  getMainBranch = async () => this.fail();
  createWebhook = async () => this.fail();
  deleteWebhook = async () => this.fail();
  getPullRequest = async () => this.fail();
  getDiffstat = async () => this.fail();
  getDiff = async () => this.fail();
  postBuildStatus = async () => this.fail();
  upsertPullRequestComment = async () => this.fail();
  listFileNames = async () => this.fail();
  commitFile = async () => this.fail();
}
