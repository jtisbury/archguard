import {
  DiffTooLargeError,
  ScmError,
  type BuildState,
  type BuildStatusInput,
  type CommitFileInput,
  type DiffstatEntry,
  type IScmProvider,
  type PullRequestInfo,
  type RepoInfo,
} from "../scm/provider";

export const GITHUB_STATUS_CONTEXT = "ArchGuard";
export const GITHUB_WEBHOOK_EVENTS = ["pull_request"];
const API = "https://api.github.com";
const API_VERSION = "2022-11-28";

const STATE: Record<BuildState, "pending" | "success" | "failure"> = {
  INPROGRESS: "pending",
  SUCCESSFUL: "success",
  FAILED: "failure",
};

export interface GitHubOptions {
  /** User or organization login that owns the repositories (fine-grained PAT resource owner). */
  owner: string;
  token: string;
  fetchImpl?: typeof fetch;
  baseUrl?: string;
  retryDelayMs?: number;
}

/** Parses the RFC 5988 Link header GitHub uses for pagination. */
export function nextLink(header: string | null): string | undefined {
  if (!header) return undefined;
  for (const part of header.split(",")) {
    const m = /<([^>]+)>;\s*rel="next"/.exec(part.trim());
    if (m) return m[1];
  }
  return undefined;
}

/** GitHub.com REST adapter authenticated with a fine-grained personal access token. */
export class GitHubAdapter implements IScmProvider {
  readonly kind = "github" as const;
  private readonly f: typeof fetch;
  private readonly base: string;
  constructor(private readonly o: GitHubOptions) {
    this.f = o.fetchImpl ?? fetch;
    this.base = (o.baseUrl ?? API).replace(/\/+$/, "");
  }

  private repoPath(slug: string) {
    return `${this.base}/repos/${encodeURIComponent(this.o.owner)}/${encodeURIComponent(slug)}`;
  }

  private async request(url: string, init: RequestInit = {}, attempt = 0): Promise<Response> {
    const headers = new Headers(init.headers);
    headers.set("Authorization", `Bearer ${this.o.token}`);
    if (!headers.has("Accept")) headers.set("Accept", "application/vnd.github+json");
    headers.set("X-GitHub-Api-Version", API_VERSION);
    headers.set("User-Agent", "ArchGuard");
    const res = await this.f(url, { ...init, headers });
    const rateLimited = res.status === 429 || (res.status === 403 && res.headers.get("x-ratelimit-remaining") === "0");
    if ((rateLimited || res.status >= 500) && attempt < 2) {
      await new Promise((r) => setTimeout(r, this.o.retryDelayMs ?? 1000 * (attempt + 1)));
      return this.request(url, init, attempt + 1);
    }
    if (!res.ok) {
      // Status only: response bodies can echo source code.
      throw new ScmError(`GitHub ${init.method ?? "GET"} ${new URL(url).pathname} failed: ${res.status}`, res.status);
    }
    return res;
  }

  private async json<T>(url: string, init?: RequestInit): Promise<T> {
    return (await this.request(url, init)).json() as Promise<T>;
  }

  private async all<T>(firstUrl: string): Promise<T[]> {
    const out: T[] = [];
    let url: string | undefined = firstUrl;
    let guard = 0;
    while (url && guard++ < 100) {
      const res = await this.request(url);
      out.push(...((await res.json()) as T[]));
      url = nextLink(res.headers.get("link"));
    }
    return out;
  }

  private async viewerLogin(): Promise<string> {
    return (await this.json<{ login: string }>(`${this.base}/user`)).login;
  }

  async validateCredentials() {
    try {
      const login = await this.viewerLogin();
      if (login.toLowerCase() !== this.o.owner.toLowerCase()) {
        await this.json(`${this.base}/orgs/${encodeURIComponent(this.o.owner)}`);
      }
      return { ok: true as const };
    } catch (e) {
      const status = e instanceof ScmError ? e.status : 0;
      const reason =
        status === 401 ? "The access token was rejected (401)." :
        status === 403 ? "The token is not allowed to read this owner (403). Check the token's resource owner." :
        status === 404 ? "Owner not found (404). Use the GitHub user or organization name." :
        "Could not reach GitHub.";
      return { ok: false as const, reason };
    }
  }

  async listRepositories(): Promise<RepoInfo[]> {
    const login = await this.viewerLogin();
    const own = login.toLowerCase() === this.o.owner.toLowerCase();
    const url = own
      ? `${this.base}/user/repos?affiliation=owner&per_page=100`
      : `${this.base}/orgs/${encodeURIComponent(this.o.owner)}/repos?per_page=100`;
    const raw = await this.all<{ id: number; name: string; full_name: string; owner: { login: string }; archived?: boolean }>(url);
    return raw
      .filter((r) => r.owner.login.toLowerCase() === this.o.owner.toLowerCase() && !r.archived)
      .map((r) => ({ id: String(r.id), slug: r.name, fullName: r.full_name }));
  }

  async getMainBranch(repoSlug: string) {
    return (await this.json<{ default_branch: string }>(this.repoPath(repoSlug))).default_branch;
  }

  async createWebhook(repoSlug: string, url: string, secret: string) {
    const res = await this.json<{ id: number }>(`${this.repoPath(repoSlug)}/hooks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: "web",
        active: true,
        events: GITHUB_WEBHOOK_EVENTS,
        config: { url, content_type: "json", secret, insecure_ssl: "0" },
      }),
    });
    return { uuid: String(res.id) };
  }

  async deleteWebhook(repoSlug: string, webhookUuid: string) {
    try {
      await this.request(`${this.repoPath(repoSlug)}/hooks/${encodeURIComponent(webhookUuid)}`, { method: "DELETE" });
    } catch (e) {
      if (e instanceof ScmError && e.status === 404) return;
      throw e;
    }
  }

  async getPullRequest(repoSlug: string, prId: number): Promise<PullRequestInfo> {
    const pr = await this.json<{
      number: number;
      title: string;
      state: "open" | "closed";
      merged?: boolean;
      merged_at?: string | null;
      head: { ref: string; sha: string };
      base: { ref: string };
    }>(`${this.repoPath(repoSlug)}/pulls/${prId}`);
    const merged = pr.merged === true || !!pr.merged_at;
    return {
      id: pr.number,
      title: pr.title,
      state: pr.state === "open" ? "OPEN" : merged ? "MERGED" : "DECLINED",
      sourceBranch: pr.head.ref,
      destinationBranch: pr.base.ref,
      sourceCommit: pr.head.sha,
    };
  }

  async getDiffstat(repoSlug: string, prId: number): Promise<DiffstatEntry[]> {
    const files = await this.all<{ filename: string; status: string; previous_filename?: string }>(
      `${this.repoPath(repoSlug)}/pulls/${prId}/files?per_page=100`,
    );
    return files.map((f) => ({ status: f.status, path: f.filename, oldPath: f.previous_filename }));
  }

  async getDiff(repoSlug: string, prId: number): Promise<string> {
    try {
      const res = await this.request(`${this.repoPath(repoSlug)}/pulls/${prId}`, { headers: { Accept: "application/vnd.github.diff" } });
      return res.text();
    } catch (e) {
      // GitHub refuses diffs above 300 files or 20,000 lines with 406.
      if (e instanceof ScmError && e.status === 406) throw new DiffTooLargeError();
      throw e;
    }
  }

  async postBuildStatus(repoSlug: string, commitSha: string, s: BuildStatusInput) {
    await this.request(`${this.repoPath(repoSlug)}/statuses/${encodeURIComponent(commitSha)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        state: STATE[s.state],
        context: GITHUB_STATUS_CONTEXT,
        description: s.description.slice(0, 140),
        ...(s.url ? { target_url: s.url } : {}),
      }),
    });
  }

  async upsertPullRequestComment(repoSlug: string, prId: number, body: string, existingCommentId?: string) {
    const headers = { "Content-Type": "application/json" };
    const payload = JSON.stringify({ body });
    if (existingCommentId) {
      try {
        const r = await this.json<{ id: number }>(`${this.repoPath(repoSlug)}/issues/comments/${encodeURIComponent(existingCommentId)}`, {
          method: "PATCH",
          headers,
          body: payload,
        });
        return String(r.id);
      } catch (e) {
        if (!(e instanceof ScmError && (e.status === 404 || e.status === 403))) throw e;
      }
    }
    const r = await this.json<{ id: number }>(`${this.repoPath(repoSlug)}/issues/${prId}/comments`, { method: "POST", headers, body: payload });
    return String(r.id);
  }

  async listFileNames(repoSlug: string, ref: string, dir: string): Promise<string[]> {
    const clean = dir.replace(/^\/+|\/+$/g, "").split("/").map(encodeURIComponent).join("/");
    try {
      const entries = await this.json<{ name: string; type: string }[] | { type: string }>(
        `${this.repoPath(repoSlug)}/contents/${clean}?ref=${encodeURIComponent(ref)}`,
      );
      return Array.isArray(entries) ? entries.filter((e) => e.type === "file").map((e) => e.name) : [];
    } catch (e) {
      if (e instanceof ScmError && e.status === 404) return [];
      throw e;
    }
  }

  async commitFile(repoSlug: string, input: CommitFileInput) {
    const path = input.path.split("/").map(encodeURIComponent).join("/");
    const r = await this.json<{ commit: { sha: string } }>(`${this.repoPath(repoSlug)}/contents/${path}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input.message, content: Buffer.from(input.content, "utf8").toString("base64"), branch: input.branch }),
    });
    return { commitSha: r.commit.sha };
  }
}
