/** Supported source-control providers. One provider per organization. */
export type ScmProviderKind = "bitbucket_cloud" | "bitbucket_datacenter" | "github";

export const SCM_LABELS: Record<ScmProviderKind, string> = {
  bitbucket_cloud: "Bitbucket Cloud",
  bitbucket_datacenter: "Bitbucket Data Center",
  github: "GitHub",
};

/** Neutral build states; each adapter maps them (GitHub: pending/success/failure). */
export type BuildState = "SUCCESSFUL" | "FAILED" | "INPROGRESS";

export interface RepoInfo {
  /** Provider's stable repository id (Bitbucket UUID, GitHub numeric id). */
  id: string;
  slug: string;
  fullName: string;
}

export interface DiffstatEntry {
  status: string;
  /** Path after the change (or the old path for removals). */
  path: string;
  oldPath?: string;
}

export interface PullRequestInfo {
  id: number;
  title: string;
  state: "OPEN" | "MERGED" | "DECLINED" | "SUPERSEDED";
  sourceBranch: string;
  destinationBranch: string;
  sourceCommit: string;
}

export interface BuildStatusInput {
  state: BuildState;
  description: string;
  /** Source branch of the PR (Bitbucket uses it to link the status to the PR; GitHub ignores it). */
  refname: string;
  url?: string;
}

export interface CommitFileInput {
  branch: string;
  path: string;
  content: string;
  message: string;
}

/** SCM adapter boundary. Everything provider specific lives behind this interface. */
export interface IScmProvider {
  readonly kind: ScmProviderKind;
  validateCredentials(): Promise<{ ok: true } | { ok: false; reason: string }>;
  listRepositories(): Promise<RepoInfo[]>;
  getMainBranch(repoSlug: string): Promise<string>;
  /** Registers the provider's pull request webhook(s) signed with `secret`. Returns the hook id. */
  createWebhook(repoSlug: string, url: string, secret: string): Promise<{ uuid: string }>;
  deleteWebhook(repoSlug: string, webhookUuid: string): Promise<void>;
  getPullRequest(repoSlug: string, prId: number): Promise<PullRequestInfo>;
  getDiffstat(repoSlug: string, prId: number): Promise<DiffstatEntry[]>;
  /**
   * Raw unified diff. Callers must keep it in memory only and never log or persist it.
   * Throws DiffTooLargeError when the provider refuses to produce it.
   */
  getDiff(repoSlug: string, prId: number): Promise<string>;
  postBuildStatus(repoSlug: string, commitSha: string, status: BuildStatusInput): Promise<void>;
  /** Creates the comment, or updates it when existingCommentId is given. Returns the comment id. */
  upsertPullRequestComment(repoSlug: string, prId: number, body: string, existingCommentId?: string): Promise<string>;
  /** Markdown file names (not content) in a directory at a ref. Empty if the directory does not exist. */
  listFileNames(repoSlug: string, ref: string, dir: string): Promise<string[]>;
  /** Commits one new file to a branch. Returns the new commit SHA. */
  commitFile(repoSlug: string, input: CommitFileInput): Promise<{ commitSha: string }>;
}

export class ScmError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = "ScmError";
  }
}

/** The provider will not return a diff this large (GitHub: HTTP 406 above 300 files / 20,000 lines). */
export class DiffTooLargeError extends Error {
  constructor(message = "Diff too large for the provider to return") {
    super(message);
    this.name = "DiffTooLargeError";
  }
}
