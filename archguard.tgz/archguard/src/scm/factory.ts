import { BitbucketCloudAdapter } from "../bitbucket/cloud";
import { BitbucketDataCenterAdapter } from "../bitbucket/datacenter";
import { GitHubAdapter } from "../github/adapter";
import { decrypt } from "../lib/vault";
import type { IScmProvider, ScmProviderKind } from "./provider";

export interface OrgConnection {
  scmProvider: ScmProviderKind;
  scmOwner: string | null;
  encryptedAccessToken: string | null;
}

/** Builds an adapter from plaintext credentials (used while connecting, before anything is stored). */
export function providerFor(kind: ScmProviderKind, owner: string, token: string): IScmProvider {
  switch (kind) {
    case "github":
      return new GitHubAdapter({ owner, token });
    case "bitbucket_cloud":
      return new BitbucketCloudAdapter({ workspace: owner, token });
    case "bitbucket_datacenter":
      return new BitbucketDataCenterAdapter();
  }
}

/** Builds the organization's adapter from its stored (encrypted) connection. */
export function createProvider(org: OrgConnection): IScmProvider {
  if (org.scmProvider === "bitbucket_datacenter") return new BitbucketDataCenterAdapter();
  if (!org.scmOwner || !org.encryptedAccessToken) {
    throw new Error("Source control connection is not configured for this organization");
  }
  return providerFor(org.scmProvider, org.scmOwner, decrypt(org.encryptedAccessToken));
}

/** Path of the webhook endpoint for a provider. */
export function webhookPath(kind: ScmProviderKind): string {
  return kind === "github" ? "/api/webhooks/github" : "/api/webhooks/bitbucket";
}
