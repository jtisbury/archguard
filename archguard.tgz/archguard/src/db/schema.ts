import { sql } from "drizzle-orm";
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";

import type { ScmProviderKind } from "../scm/provider";

export type Role = "admin" | "architect" | "viewer";
export type Severity = "blocking" | "warning";

export interface Violation {
  ruleName: string;
  severity: Severity;
  filePath: string;
  line: number | null;
  message: string;
  remediation: string;
}

export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  scmProvider: text("scm_provider").$type<ScmProviderKind>().notNull().default("bitbucket_cloud"),
  scmBaseUrl: text("scm_base_url"),
  /** Bitbucket workspace slug or GitHub user/organization login. */
  scmOwner: text("scm_owner"),
  encryptedAccessToken: text("encrypted_access_token"),
  planTier: text("plan_tier").notNull().default("pilot"),
  monthlyEvalCount: integer("monthly_eval_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  oidcSubject: text("oidc_subject").unique(),
  email: text("email").notNull().unique(),
  bitbucketAccountId: text("bitbucket_account_id"),
  name: text("name"),
  avatarUrl: text("avatar_url"),
});

export const organizationMembers = pgTable(
  "organization_members",
  {
    orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    role: text("role").$type<Role>().notNull(),
  },
  (t) => [primaryKey({ columns: [t.orgId, t.userId] })],
);

export const repositories = pgTable(
  "repositories",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
    scmProvider: text("scm_provider").$type<ScmProviderKind>().notNull().default("bitbucket_cloud"),
    /** Provider repository id (Bitbucket UUID or GitHub numeric id). */
    scmRepoId: text("scm_repo_id").notNull(),
    repoSlug: text("repo_slug").notNull(),
    fullName: text("full_name").notNull(),
    webhookUuid: text("webhook_uuid"),
    encryptedWebhookSecret: text("encrypted_webhook_secret"),
    isActive: boolean("is_active").notNull().default(false),
    adrDirectoryPath: text("adr_directory_path").notNull().default("docs/adr"),
    structuralTriggers: jsonb("structural_triggers").$type<string[]>().notNull().default([]),
    baselineAdrTitles: jsonb("baseline_adr_titles").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("repositories_org_provider_repo_key").on(t.orgId, t.scmProvider, t.scmRepoId)],
);

export const guardrailRules = pgTable(
  "guardrail_rules",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    severity: text("severity").$type<Severity>().notNull(),
    rulePrompt: text("rule_prompt").notNull(),
    targetPatterns: jsonb("target_patterns").$type<string[]>().notNull().default([]),
    isEnabled: boolean("is_enabled").notNull().default(true),
  },
  (t) => [unique().on(t.orgId, t.name)],
);

export const prEvaluations = pgTable("pr_evaluations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  repoId: uuid("repo_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
  prId: integer("pr_id").notNull(),
  prTitle: text("pr_title").notNull().default(""),
  sourceBranch: text("source_branch").notNull().default(""),
  commitSha: text("commit_sha").notNull(),
  status: text("status").$type<"passed" | "failed" | "neutral">().notNull(),
  outcomeReason: text("outcome_reason"),
  violations: jsonb("violations").$type<Violation[]>().notNull().default([]),
  tokensUsed: integer("tokens_used").notNull().default(0),
  commentId: text("comment_id"),
  requestUuid: text("request_uuid"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [unique().on(t.repoId, t.requestUuid)]);

export const adrDrafts = pgTable(
  "adr_drafts",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    orgId: uuid("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
    repoId: uuid("repo_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
    evaluationId: uuid("evaluation_id").references(() => prEvaluations.id, { onDelete: "set null" }),
    prId: integer("pr_id"),
    adrNumber: integer("adr_number").notNull(),
    title: text("title").notNull(),
    markdownContent: text("markdown_content").notNull(),
    status: text("status").$type<"pending" | "approved_committed" | "dismissed">().notNull().default("pending"),
    committedSha: text("committed_sha"),
    committedPath: text("committed_path"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique().on(t.repoId, t.adrNumber)],
);

export const schema = {
  organizations,
  users,
  organizationMembers,
  repositories,
  guardrailRules,
  prEvaluations,
  adrDrafts,
};
