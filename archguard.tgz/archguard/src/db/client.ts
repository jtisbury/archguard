import { sql } from "drizzle-orm";
import type { PgDatabase, PgQueryResultHKT } from "drizzle-orm/pg-core";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import { getConfig } from "../lib/config";
import { schema } from "./schema";

/** Driver-agnostic DB handle (node-postgres in production, PGlite in tests). */
export type Db = PgDatabase<PgQueryResultHKT, typeof schema>;
export type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * The ONLY sanctioned way to touch tenant data. Opens a transaction, binds the tenant
 * (`SET LOCAL app.org_id`, transaction scoped) and runs fn. RLS then restricts every row.
 */
export async function withTenant<T>(db: Db, orgId: string, fn: (tx: Tx) => Promise<T>): Promise<T> {
  if (!UUID_RE.test(orgId)) throw new Error("withTenant: invalid organization id");
  return db.transaction(async (tx) => {
    await tx.execute(sql`select set_config('app.org_id', ${orgId}, true)`);
    return fn(tx);
  });
}

/** Rows of a raw `db.execute` result (node-postgres and PGlite both return `{ rows }`). */
export function rowsOf<T>(result: unknown): T[] {
  return ((result as { rows?: T[] }).rows ?? []) as T[];
}

let pool: pg.Pool | undefined;
let db: Db | undefined;

/** Application DB handle. Connects as the restricted archguard_app role (RLS enforced). */
export function getDb(): Db {
  if (!db) {
    pool = new pg.Pool({ connectionString: getConfig().DATABASE_URL, max: 10, connectionTimeoutMillis: 3000 });
    db = drizzle(pool, { schema }) as unknown as Db;
  }
  return db;
}

export async function pingDb(): Promise<boolean> {
  try {
    await getDb().execute(sql`select 1`);
    return true;
  } catch {
    return false;
  }
}

export async function closeDb() {
  await pool?.end();
  pool = undefined;
  db = undefined;
}
