import fs from "node:fs";
import path from "node:path";

/** Minimal executor so the same runner works for pg.Pool and PGlite. */
export interface SqlExecutor {
  exec(sql: string): Promise<unknown>;
  query(sql: string, params?: unknown[]): Promise<{ rows: Record<string, unknown>[] }>;
}

const MIGRATIONS_DIR = path.resolve(process.cwd(), "src", "db", "migrations");

export async function runMigrations(ex: SqlExecutor, dir = MIGRATIONS_DIR): Promise<string[]> {
  await ex.exec(`CREATE TABLE IF NOT EXISTS _migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
  const done = new Set((await ex.query(`SELECT name FROM _migrations`)).rows.map((r) => String(r.name)));
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();
  const applied: string[] = [];
  for (const f of files) {
    if (done.has(f)) continue;
    await ex.exec(fs.readFileSync(path.join(dir, f), "utf8"));
    await ex.query(`INSERT INTO _migrations(name) VALUES ($1)`, [f]);
    applied.push(f);
  }
  return applied;
}
