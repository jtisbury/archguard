-- ArchGuard initial schema. Applied by the OWNER role; the app connects as archguard_app.

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'archguard_app') THEN
    CREATE ROLE archguard_app LOGIN PASSWORD 'archguard_app' NOSUPERUSER NOBYPASSRLS;
  END IF;
END $$;

CREATE TABLE organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  bitbucket_type text NOT NULL DEFAULT 'cloud' CHECK (bitbucket_type IN ('cloud','datacenter')),
  bitbucket_base_url text,
  bitbucket_workspace_or_project text,
  encrypted_access_token text,
  plan_tier text NOT NULL DEFAULT 'pilot',
  monthly_eval_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Identity is global (a person may belong to several orgs); membership is tenant scoped.
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  oidc_subject text UNIQUE,
  email text NOT NULL UNIQUE,
  bitbucket_account_id text,
  name text,
  avatar_url text
);

CREATE TABLE organization_members (
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('admin','architect','viewer')),
  PRIMARY KEY (org_id, user_id)
);

CREATE TABLE repositories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  bitbucket_repo_uuid text NOT NULL,
  repo_slug text NOT NULL,
  full_name text NOT NULL,
  webhook_uuid text,
  encrypted_webhook_secret text,
  is_active boolean NOT NULL DEFAULT false,
  adr_directory_path text NOT NULL DEFAULT 'docs/adr',
  structural_triggers jsonb NOT NULL DEFAULT '[]'::jsonb,
  baseline_adr_titles jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (org_id, bitbucket_repo_uuid)
);

CREATE TABLE guardrail_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  severity text NOT NULL CHECK (severity IN ('blocking','warning')),
  rule_prompt text NOT NULL,
  target_patterns jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_enabled boolean NOT NULL DEFAULT true,
  UNIQUE (org_id, name)
);

CREATE TABLE pr_evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  repo_id uuid NOT NULL REFERENCES repositories(id) ON DELETE CASCADE,
  pr_id integer NOT NULL,
  pr_title text NOT NULL DEFAULT '',
  source_branch text NOT NULL DEFAULT '',
  commit_sha text NOT NULL,
  status text NOT NULL CHECK (status IN ('passed','failed','neutral')),
  outcome_reason text,
  violations jsonb NOT NULL DEFAULT '[]'::jsonb,
  tokens_used integer NOT NULL DEFAULT 0,
  comment_id text,
  request_uuid text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (repo_id, request_uuid)
);
CREATE INDEX pr_evaluations_repo_pr_idx ON pr_evaluations (repo_id, pr_id, created_at DESC);

CREATE TABLE adr_drafts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  repo_id uuid NOT NULL REFERENCES repositories(id) ON DELETE CASCADE,
  evaluation_id uuid REFERENCES pr_evaluations(id) ON DELETE SET NULL,
  pr_id integer,
  adr_number integer NOT NULL,
  title text NOT NULL,
  markdown_content text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved_committed','dismissed')),
  committed_sha text,
  committed_path text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (repo_id, adr_number)
);

-- ---------- Tenant context + RLS ----------
CREATE FUNCTION app_org_id() RETURNS uuid LANGUAGE sql STABLE AS
  $$ SELECT nullif(current_setting('app.org_id', true), '')::uuid $$;

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON organizations
  USING (id = app_org_id()) WITH CHECK (id = app_org_id());

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['organization_members','repositories','guardrail_rules','pr_evaluations','adr_drafts'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_isolation ON %I USING (org_id = app_org_id()) WITH CHECK (org_id = app_org_id())', t);
  END LOOP;
END $$;

GRANT SELECT, INSERT, UPDATE, DELETE ON
  organizations, users, organization_members, repositories, guardrail_rules, pr_evaluations, adr_drafts
  TO archguard_app;
-- Creating an organization is an administrative/bootstrap action performed by the owner role
-- (seed script). The app role may update but not insert/delete organizations.
REVOKE INSERT, DELETE ON organizations FROM archguard_app;

-- ---------- Narrow, audited cross-tenant lookups (SECURITY DEFINER) ----------
-- Webhook ingress cannot know the tenant before verifying who sent the request.
-- Bitbucket sends the webhook UUID in X-Hook-UUID, which lets us find the signing secret
-- BEFORE reading the (unauthenticated) body.
CREATE FUNCTION lookup_repo_for_webhook(p_hook_uuid text)
RETURNS TABLE (org_id uuid, repo_id uuid, encrypted_webhook_secret text, is_active boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT r.org_id, r.id, r.encrypted_webhook_secret, r.is_active
   FROM repositories r
   WHERE r.webhook_uuid IS NOT NULL
     AND lower(btrim(r.webhook_uuid, '{}')) = lower(btrim(p_hook_uuid, '{}')) $$;

-- Sign-in needs to resolve the default org before a tenant context exists.
CREATE FUNCTION lookup_org_id_by_slug(p_slug text) RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS
$$ SELECT id FROM organizations WHERE slug = p_slug $$;

REVOKE ALL ON FUNCTION lookup_repo_for_webhook(text), lookup_org_id_by_slug(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION lookup_repo_for_webhook(text), lookup_org_id_by_slug(text) TO archguard_app;
GRANT EXECUTE ON FUNCTION app_org_id() TO archguard_app;
