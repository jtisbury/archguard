-- Generalize the Bitbucket-only connection to a source-control provider (Bitbucket or GitHub).
-- One provider per organization; each repository records the provider it came from so history
-- survives a provider change. Existing data is migrated in place.

ALTER TABLE organizations DROP CONSTRAINT IF EXISTS organizations_bitbucket_type_check;
ALTER TABLE organizations RENAME COLUMN bitbucket_type TO scm_provider;
UPDATE organizations SET scm_provider = CASE scm_provider WHEN 'datacenter' THEN 'bitbucket_datacenter' ELSE 'bitbucket_cloud' END;
ALTER TABLE organizations ALTER COLUMN scm_provider SET DEFAULT 'bitbucket_cloud';
ALTER TABLE organizations ADD CONSTRAINT organizations_scm_provider_check
  CHECK (scm_provider IN ('bitbucket_cloud', 'bitbucket_datacenter', 'github'));
ALTER TABLE organizations RENAME COLUMN bitbucket_base_url TO scm_base_url;
ALTER TABLE organizations RENAME COLUMN bitbucket_workspace_or_project TO scm_owner;

ALTER TABLE repositories RENAME COLUMN bitbucket_repo_uuid TO scm_repo_id;
ALTER TABLE repositories ADD COLUMN scm_provider text NOT NULL DEFAULT 'bitbucket_cloud'
  CHECK (scm_provider IN ('bitbucket_cloud', 'bitbucket_datacenter', 'github'));
ALTER TABLE repositories DROP CONSTRAINT IF EXISTS repositories_org_id_bitbucket_repo_uuid_key;
ALTER TABLE repositories ADD CONSTRAINT repositories_org_provider_repo_key UNIQUE (org_id, scm_provider, scm_repo_id);
