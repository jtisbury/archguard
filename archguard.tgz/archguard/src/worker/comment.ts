import type { Violation } from "../db/schema";

export const COMMENT_MARKER = "<!-- archguard -->";

export interface CommentInput {
  status: "passed" | "failed" | "neutral";
  outcomeReason?: string | null;
  violations: Violation[];
  adrDraftUrl?: string | null;
  adrTitle?: string | null;
}

const ICON = { passed: "✅", failed: "❌", neutral: "⚠️" } as const;

/** Markdown for the single, updatable ArchGuard PR comment. Contains no source code. */
export function formatComment(c: CommentInput): string {
  const lines: string[] = [COMMENT_MARKER, `## ${ICON[c.status]} ArchGuard`, ""];
  const blocking = c.violations.filter((v) => v.severity === "blocking");
  const warnings = c.violations.filter((v) => v.severity === "warning");

  if (c.status === "neutral") {
    lines.push(
      c.outcomeReason === "too_large"
        ? "This pull request is too large to evaluate automatically. It was **not** blocked. Please request a manual architecture review."
        : "ArchGuard could not complete the evaluation (neutral result). The pull request was **not** blocked.",
    );
  } else if (c.status === "failed") {
    lines.push(`**${blocking.length} blocking violation${blocking.length === 1 ? "" : "s"}** must be resolved before merge.`);
  } else if (c.outcomeReason === "no_structural_changes") {
    lines.push("No architectural impact detected.");
  } else {
    lines.push(warnings.length ? "No blocking violations. Please review the warnings below." : "All guardrails passed.");
  }

  const table = (title: string, vs: Violation[]) => {
    if (!vs.length) return;
    lines.push("", `### ${title}`, "", "| Rule | File | Line | Issue | Suggested fix |", "|---|---|---|---|---|");
    for (const v of vs) {
      const cell = (s: string) => s.replace(/\|/g, "\\|").replace(/\r?\n/g, " ");
      lines.push(`| ${cell(v.ruleName)} | \`${cell(v.filePath)}\` | ${v.line ?? "-"} | ${cell(v.message)} | ${cell(v.remediation)} |`);
    }
  };
  table("Blocking", blocking);
  table("Warnings", warnings);

  if (c.adrDraftUrl) {
    lines.push("", `📝 **ADR draft ready for review:** [${c.adrTitle ?? "Review draft"}](${c.adrDraftUrl})`);
  }
  return lines.join("\n");
}
