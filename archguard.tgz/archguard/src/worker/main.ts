import "../../scripts/load-env";
import { Worker } from "bullmq";
import { createProvider } from "../scm/factory";
import { getDb } from "../db/client";
import { getConfig } from "../lib/config";
import { logger } from "../lib/logger";
import { getRedis } from "../lib/redis";
import { createLlmProvider } from "../llm/factory";
import { JOB_ATTEMPTS } from "../queue";
import { EVALUATE_QUEUE, type EvaluateJob } from "../queue/types";
import { finalizeFailure, processEvaluation, type EvaluateDeps } from "./evaluate";

function buildDeps(): EvaluateDeps {
  const cfg = getConfig();
  return {
    db: getDb(),
    makeProvider: createProvider,
    llm: () => createLlmProvider(cfg),
    appBaseUrl: cfg.APP_BASE_URL,
    limits: { maxDiffBytes: cfg.MAX_DIFF_BYTES, maxInputTokens: cfg.MAX_LLM_INPUT_TOKENS },
    pilotMode: cfg.ENTERPRISE_PILOT_MODE,
  };
}

const deps = buildDeps();

const worker = new Worker<EvaluateJob>(
  EVALUATE_QUEUE,
  async (job) => {
    logger.info("evaluating PR", { repoId: job.data.repoId, prId: job.data.prId, attempt: job.attemptsMade + 1 });
    return processEvaluation(job.data, deps);
  },
  { connection: getRedis(), concurrency: 4 },
);

worker.on("completed", (job, res) => logger.info("evaluation complete", { prId: job.data.prId, result: res }));
worker.on("failed", async (job, err) => {
  if (!job) return;
  const final = job.attemptsMade >= (job.opts.attempts ?? JOB_ATTEMPTS);
  logger.error("evaluation failed", { prId: job.data.prId, attempt: job.attemptsMade, final, error: err });
  if (final) await finalizeFailure(job.data, deps);
});

const shutdown = async () => {
  await worker.close();
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
logger.info("ArchGuard worker started", { queue: EVALUATE_QUEUE });
