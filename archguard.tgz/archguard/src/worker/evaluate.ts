import { and, desc, eq, sql } from "drizzle-orm";
import { saveAdrDraft } from "../adr/drafts";
import { DiffTooLargeError, type IScmProvider, type PullRequestInfo } from "../scm/provider";
import { withTenant, type Db } from "../db/client";
import { guardrailRules, organizations, prEvaluations, repositories, type Violation } from "../db/schema";
import { evaluateDiff } from "../llm/evaluator";
import type { ILlmProvider } from "../llm/types";
import { canRunEvaluation } from "../lib/billing";
import { logger } from "../lib/logger";
import type { EvaluateJob } from "../queue/types";
import { matchStructuralPaths } from "../triage/triggers";
import { formatComment } from "./comment";

export interface EvaluateDeps {
  db: Db;
  makeProvider: (org: typeof organizations.$inferSelect) => IScmProvider;
  llm: () => ILlmProvider;
  appBaseUrl: string;
  limits: { maxDiffBytes: number; maxInputTokens: number };
  pilotMode: boolean;
}

export const NO_IMPACT_DESCRIPTION = "ArchGuard: No architectural impact detected";

type FinalState = { state: "SUCCESSFUL" | "FAILED"; description: string };

/**
 * One PR evaluation (steps 1-7 of the pipeline). Throws on infrastructure errors so BullMQ can
 * retry with backoff; finalizeFailure() runs after the last attempt.
 */
export async function processEvaluation(job: EvaluateJob, deps: EvaluateDeps): Promise<{ status: "passed" | "failed" | "neutral" | "skipped" }> {
  const { db } = deps;
  const ctx = await withTenant(db, job.orgId, async (tx) => {
    const [org] = await tx.select().from(organizations).where(eq(organizations.id, job.orgId));
    const [repo] = await tx.select().from(repositories).where(eq(repositories.id, job.repoId));
    const rules = await tx.select().from(guardrailRules).where(eq(guardrailRules.isEnabled, true));
    const [previous] = await tx
      .select({ commentId: prEvaluations.commentId })
      .from(prEvaluations)
      .where(and(eq(prEvaluations.repoId, job.repoId), eq(prEvaluations.prId, job.prId)))
      .orderBy(desc(prEvaluations.createdAt))
      .limit(1);
    return { org, repo, rules, previousCommentId: previous?.commentId ?? null };
  });
  if (!ctx.org || !ctx.repo || !ctx.repo.isActive || ctx.repo.scmProvider !== ctx.org.scmProvider) {
    logger.warn("evaluation skipped: repository missing, inactive or from a previous provider", { repoId: job.repoId });
    return { status: "skipped" };
  }
  const { org, repo } = ctx;
  const provider = deps.makeProvider(org);

  const pr = await provider.getPullRequest(repo.repoSlug, job.prId);
  if (pr.state !== "OPEN") return { status: "skipped" };

  const statusUrl = deps.appBaseUrl.replace(/\/+$/, "") + "/";
  const post = (state: "INPROGRESS" | "SUCCESSFUL" | "FAILED", description: string) =>
    provider.postBuildStatus(repo.repoSlug, pr.sourceCommit, { state, description, refname: pr.sourceBranch, url: statusUrl });

  // 1. INPROGRESS
  await post("INPROGRESS", "ArchGuard: evaluating architecture");

  // Persist helper (idempotent per request, so BullMQ retries don't duplicate rows).
  const persist = async (v: { status: "passed" | "failed" | "neutral"; reason: string | null; violations: Violation[]; tokens: number }) =>
    withTenant(db, job.orgId, async (tx) => {
      const values = {
        orgId: job.orgId,
        repoId: repo.id,
        prId: job.prId,
        prTitle: pr.title.slice(0, 300),
        sourceBranch: pr.sourceBranch,
        commitSha: pr.sourceCommit,
        status: v.status,
        outcomeReason: v.reason,
        violations: v.violations,
        tokensUsed: v.tokens,
        requestUuid: job.requestUuid,
      };
      const [row] = await tx
        .insert(prEvaluations)
        .values(values)
        .onConflictDoUpdate({ target: [prEvaluations.repoId, prEvaluations.requestUuid], set: values })
        .returning();
      return row!;
    });

  const finish = async (
    ev: { id: string; status: "passed" | "failed" | "neutral" },
    final: FinalState,
    c: { reason: string | null; violations: Violation[]; adr?: { id: string; title: string } | null },
  ) => {
    let commentId: string | null = ctx.previousCommentId;
    try {
      commentId = await provider.upsertPullRequestComment(
        repo.repoSlug,
        job.prId,
        formatComment({
          status: ev.status,
          outcomeReason: c.reason,
          violations: c.violations,
          adrDraftUrl: c.adr ? `${deps.appBaseUrl.replace(/\/+$/, "")}/adrs/${c.adr.id}` : null,
          adrTitle: c.adr?.title,
        }),
        ctx.previousCommentId ?? undefined,
      );
      await withTenant(db, job.orgId, (tx) => tx.update(prEvaluations).set({ commentId }).where(eq(prEvaluations.id, ev.id)));
    } catch (e) {
      logger.warn("could not post PR comment", { error: e }); // never block the status on a comment failure
    }
    await post(final.state, final.description);
    return { status: ev.status };
  };

  // Billing gate (bypassed by ENTERPRISE_PILOT_MODE).
  if (!canRunEvaluation(org, deps.pilotMode)) {
    const ev = await persist({ status: "neutral", reason: "plan_limit", violations: [], tokens: 0 });
    return finish(ev, { state: "SUCCESSFUL", description: "ArchGuard: evaluation limit reached (neutral)" }, { reason: "plan_limit", violations: [] });
  }

  // 2-3. Triage on the diffstat. No LLM call when nothing structural changed.
  const diffstat = await provider.getDiffstat(repo.repoSlug, job.prId);
  const changedPaths = [...new Set(diffstat.map((d) => d.path))];
  const structuralPaths = matchStructuralPaths(changedPaths, repo.structuralTriggers);
  if (structuralPaths.length === 0) {
    const ev = await persist({ status: "passed", reason: "no_structural_changes", violations: [], tokens: 0 });
    return finish(ev, { state: "SUCCESSFUL", description: NO_IMPACT_DESCRIPTION }, { reason: "no_structural_changes", violations: [] });
  }

  // 4. Gather inputs. The diff lives only in this function's memory.
  let diff: string | null;
  try {
    diff = await provider.getDiff(repo.repoSlug, job.prId);
  } catch (e) {
    if (!(e instanceof DiffTooLargeError)) throw e;
    const ev = await persist({ status: "neutral", reason: "too_large", violations: [], tokens: 0 });
    return finish(ev, { state: "SUCCESSFUL", description: "ArchGuard: too large to evaluate (neutral)" }, { reason: "too_large", violations: [] });
  }
  const adrDir = repo.adrDirectoryPath.replace(/^\/+|\/+$/g, "");
  const adrFiles = await provider.listFileNames(repo.repoSlug, pr.destinationBranch, adrDir).catch(() => [] as string[]);
  const adrAlreadyInPr = changedPaths.some((p) => p.startsWith(adrDir + "/"));
  const adrTitles = adrFiles.length
    ? adrFiles.map((f) => f.replace(/\.md$/i, "").replace(/^\d+[-_]/, "").replace(/[-_]+/g, " "))
    : repo.baselineAdrTitles;

  // 5. LLM evaluation (structured output, validated).
  let outcome;
  try {
    outcome = await evaluateDiff({
      llm: deps.llm(),
      rules: ctx.rules,
      diff,
      changedPaths,
      structuralPaths,
      existingAdrTitles: adrTitles,
      prTitle: pr.title,
      adrAlreadyInPr,
      limits: deps.limits,
    });
  } finally {
    diff = null; // purge
  }

  // 6-7. Persist + post.
  if (outcome.kind === "too_large") {
    const ev = await persist({ status: "neutral", reason: "too_large", violations: [], tokens: 0 });
    return finish(ev, { state: "SUCCESSFUL", description: "ArchGuard: too large to evaluate (neutral)" }, { reason: "too_large", violations: [] });
  }
  if (outcome.kind === "invalid_output") {
    const ev = await persist({ status: "neutral", reason: "invalid_llm_output", violations: [], tokens: outcome.tokensUsed });
    return finish(ev, { state: "SUCCESSFUL", description: "ArchGuard: could not evaluate (neutral)" }, { reason: "invalid_llm_output", violations: [] });
  }

  const blocking = outcome.violations.filter((v) => v.severity === "blocking");
  const status = blocking.length ? "failed" : "passed";
  const ev = await persist({ status, reason: null, violations: outcome.violations, tokens: outcome.tokensUsed });
  await withTenant(db, job.orgId, (tx) =>
    tx.update(organizations).set({ monthlyEvalCount: sql`${organizations.monthlyEvalCount} + 1` }).where(eq(organizations.id, job.orgId)),
  );

  let adr: { id: string; title: string } | null = null;
  if (outcome.adrDraft) {
    const saved = await saveAdrDraft(db, job.orgId, {
      repoId: repo.id,
      prId: job.prId,
      evaluationId: ev.id,
      data: outcome.adrDraft,
      existingFileNames: adrFiles,
    });
    adr = { id: saved.id, title: saved.title };
  }

  const final: FinalState = blocking.length
    ? { state: "FAILED", description: `ArchGuard: ${blocking.length} blocking violation${blocking.length === 1 ? "" : "s"}` }
    : { state: "SUCCESSFUL", description: outcome.violations.length ? `ArchGuard: passed with ${outcome.violations.length} warning(s)` : "ArchGuard: all guardrails passed" };
  return finish(ev, final, { reason: null, violations: outcome.violations, adr });
}

/**
 * Called after the final failed attempt: never leave INPROGRESS stuck. Posts a neutral
 * (SUCCESSFUL) status and records a neutral evaluation.
 */
export async function finalizeFailure(job: EvaluateJob, deps: EvaluateDeps): Promise<void> {
  try {
    const ctx = await withTenant(deps.db, job.orgId, async (tx) => ({
      org: (await tx.select().from(organizations).where(eq(organizations.id, job.orgId)))[0],
      repo: (await tx.select().from(repositories).where(eq(repositories.id, job.repoId)))[0],
    }));
    if (!ctx.org || !ctx.repo) return;
    const provider = deps.makeProvider(ctx.org);
    const pr: PullRequestInfo = await provider.getPullRequest(ctx.repo.repoSlug, job.prId);
    await provider.postBuildStatus(ctx.repo.repoSlug, pr.sourceCommit, {
      state: "SUCCESSFUL",
      description: "ArchGuard: evaluation failed (neutral). Merge is not blocked.",
      refname: pr.sourceBranch,
    });
    await withTenant(deps.db, job.orgId, (tx) =>
      tx
        .insert(prEvaluations)
        .values({
          orgId: job.orgId,
          repoId: ctx.repo!.id,
          prId: job.prId,
          prTitle: pr.title.slice(0, 300),
          sourceBranch: pr.sourceBranch,
          commitSha: pr.sourceCommit,
          status: "neutral",
          outcomeReason: "evaluation_error",
          requestUuid: job.requestUuid,
        })
        .onConflictDoNothing(),
    );
  } catch (e) {
    logger.error("could not finalize failed evaluation", { error: e });
  }
}
