export const EVALUATE_QUEUE = "evaluate-bitbucket-pr";

export interface EvaluateJob {
  orgId: string;
  repoId: string;
  prId: number;
  eventKey: string;
  requestUuid: string;
}

/** Narrow interface so ingestion is testable without Redis. */
export interface EvaluateQueue {
  enqueue(job: EvaluateJob): Promise<void>;
}

/** Minimal Redis surface used for deduplication. */
export interface DedupeStore {
  set(key: string, value: string, mode: "EX", seconds: number, nx: "NX"): Promise<"OK" | null>;
  del(key: string): Promise<number>;
}
