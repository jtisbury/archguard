import { Queue } from "bullmq";
import { getRedis } from "../lib/redis";
import { EVALUATE_QUEUE, type EvaluateJob, type EvaluateQueue } from "./types";

export const JOB_ATTEMPTS = 4;

let queue: Queue<EvaluateJob> | undefined;

function getQueue(): Queue<EvaluateJob> {
  queue ??= new Queue<EvaluateJob>(EVALUATE_QUEUE, {
    connection: getRedis(),
    defaultJobOptions: {
      attempts: JOB_ATTEMPTS,
      backoff: { type: "exponential", delay: 5_000 },
      removeOnComplete: 1000,
      removeOnFail: 1000,
    },
  });
  return queue;
}

export const bullQueue: EvaluateQueue = {
  async enqueue(job) {
    // jobId = request UUID: BullMQ itself also refuses a duplicate id.
    await getQueue().add("evaluate", job, { jobId: job.requestUuid });
  },
};
