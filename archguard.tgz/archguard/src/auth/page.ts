import { redirect } from "next/navigation";
import { getPrincipal } from "./index";
import { hasRole, type Principal } from "./roles";
import type { Role } from "../db/schema";

/** For server components: redirect to sign-in, or show 403 content via the returned flag. */
export async function pagePrincipal(minimum: Role): Promise<{ principal: Principal; allowed: boolean }> {
  const principal = await getPrincipal();
  if (!principal) redirect("/signin");
  return { principal, allowed: hasRole(principal.role, minimum) };
}
