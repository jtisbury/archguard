import type { Role } from "../db/schema";

const RANK: Record<Role, number> = { viewer: 1, architect: 2, admin: 3 };

export interface RoleGroupMap {
  admin: string[];
  architect: string[];
  viewer: string[];
}

/** Normalizes a groups claim (array, comma/space separated string, or missing) to a string[]. */
export function normalizeGroups(claim: unknown): string[] {
  if (Array.isArray(claim)) return claim.map(String);
  if (typeof claim === "string") return claim.split(/[,\s]+/).filter(Boolean);
  return [];
}

/** Highest role granted by the IdP groups, or null if the user has no ArchGuard group. */
export function mapGroupsToRole(groups: string[], map: RoleGroupMap): Role | null {
  const set = new Set(groups.map((g) => g.toLowerCase()));
  const has = (list: string[]) => list.some((g) => set.has(g.toLowerCase()));
  if (has(map.admin)) return "admin";
  if (has(map.architect)) return "architect";
  if (has(map.viewer)) return "viewer";
  return null;
}

export function hasRole(actual: Role | null | undefined, minimum: Role): boolean {
  return !!actual && RANK[actual] >= RANK[minimum];
}

export class ForbiddenError extends Error {
  constructor(message = "Forbidden") {
    super(message);
    this.name = "ForbiddenError";
  }
}
export class UnauthenticatedError extends Error {
  constructor() {
    super("Unauthenticated");
    this.name = "UnauthenticatedError";
  }
}

export interface Principal {
  userId: string;
  orgId: string;
  role: Role;
  email?: string | null;
  name?: string | null;
}

/** Throws unless the principal exists and has at least the minimum role. */
export function requireRole(principal: Principal | null | undefined, minimum: Role): Principal {
  if (!principal) throw new UnauthenticatedError();
  if (!hasRole(principal.role, minimum)) throw new ForbiddenError(`Requires ${minimum} role`);
  return principal;
}
