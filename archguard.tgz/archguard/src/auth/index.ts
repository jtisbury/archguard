import NextAuth, { type NextAuthConfig } from "next-auth";
import { getDb } from "../db/client";
import { getConfig } from "../lib/config";
import { provisionUser } from "./provision";
import type { Principal } from "./roles";
import { requireRole } from "./roles";
import type { Role } from "../db/schema";

declare module "next-auth" {
  interface Session {
    principal?: Principal;
  }
}

const config: NextAuthConfig = {
  trustHost: true,
  session: { strategy: "jwt", maxAge: 8 * 60 * 60 },
  pages: { signIn: "/signin", error: "/signin" },
  providers: [
    {
      id: "oidc",
      name: "Enterprise SSO",
      type: "oidc",
      issuer: process.env.AUTH_OIDC_ISSUER,
      clientId: process.env.AUTH_OIDC_CLIENT_ID,
      clientSecret: process.env.AUTH_OIDC_CLIENT_SECRET,
    },
  ],
  callbacks: {
    async signIn({ user, profile }) {
      if (!profile) return false;
      const cfg = getConfig();
      const principal = await provisionUser(getDb(), profile as never, {
        defaultOrgSlug: cfg.AUTH_DEFAULT_ORG_SLUG,
        groupsClaim: cfg.AUTH_OIDC_GROUPS_CLAIM,
        roleMap: { admin: cfg.AUTH_ROLE_ADMIN_GROUPS, architect: cfg.AUTH_ROLE_ARCHITECT_GROUPS, viewer: cfg.AUTH_ROLE_VIEWER_GROUPS },
      });
      if (!principal) return false; // no ArchGuard group => access denied
      (user as { principal?: Principal }).principal = principal;
      return true;
    },
    async jwt({ token, user }) {
      const p = (user as { principal?: Principal } | undefined)?.principal;
      if (p) token.principal = p;
      return token;
    },
    async session({ session, token }) {
      session.principal = token.principal as Principal | undefined;
      return session;
    },
  },
};

export const { handlers, auth, signIn, signOut } = NextAuth(config);

/** Current signed-in principal or null. */
export async function getPrincipal(): Promise<Principal | null> {
  const session = await auth();
  return session?.principal ?? null;
}

/** For server components / actions / route handlers. Throws Unauthenticated/Forbidden errors. */
export async function requirePrincipal(minimum: Role): Promise<Principal> {
  return requireRole(await getPrincipal(), minimum);
}
