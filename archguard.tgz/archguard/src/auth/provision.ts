import { eq, sql } from "drizzle-orm";
import { rowsOf, withTenant, type Db } from "../db/client";
import { organizationMembers, users } from "../db/schema";
import { mapGroupsToRole, normalizeGroups, type Principal, type RoleGroupMap } from "./roles";

export interface OidcProfile {
  sub: string;
  email?: string | null;
  name?: string | null;
  picture?: string | null;
  [claim: string]: unknown;
}

export interface ProvisionOptions {
  defaultOrgSlug: string;
  groupsClaim: string;
  roleMap: RoleGroupMap;
}

/**
 * Called on every sign-in. Upserts the user, resolves the org, and (re)applies the role from
 * the IdP groups so access changes in the IdP take effect at next sign-in. Users with no
 * ArchGuard group are refused (and any existing membership is removed).
 */
export async function provisionUser(db: Db, profile: OidcProfile, opts: ProvisionOptions): Promise<Principal | null> {
  if (!profile.sub || !profile.email) return null;

  const orgRes = await db.execute(sql`select lookup_org_id_by_slug(${opts.defaultOrgSlug}) as id`);
  const orgId = rowsOf<{ id: string | null }>(orgRes)[0]?.id;
  if (!orgId) return null;

  const role = mapGroupsToRole(normalizeGroups(profile[opts.groupsClaim]), opts.roleMap);
  const email = profile.email.toLowerCase();

  const [user] = await db
    .insert(users)
    .values({ oidcSubject: profile.sub, email, name: profile.name ?? null, avatarUrl: profile.picture ?? null })
    .onConflictDoUpdate({
      target: users.email,
      set: { oidcSubject: profile.sub, name: profile.name ?? null, avatarUrl: profile.picture ?? null },
    })
    .returning();
  if (!user) return null;

  return withTenant(db, orgId, async (tx) => {
    if (!role) {
      await tx.delete(organizationMembers).where(eq(organizationMembers.userId, user.id));
      return null;
    }
    await tx
      .insert(organizationMembers)
      .values({ orgId, userId: user.id, role })
      .onConflictDoUpdate({ target: [organizationMembers.orgId, organizationMembers.userId], set: { role } });
    return { userId: user.id, orgId, role, email, name: user.name };
  });
}
