/**
 * Structured JSON logger with key-based redaction. Diff content, tokens and secrets
 * must never appear in logs (see steering: ephemeral diffs).
 */
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40, silent: 100 } as const;
type Level = keyof typeof LEVELS;

const REDACT_KEYS = /diff|token|secret|authorization|password|api[-_]?key|content|markdown|patch|cookie/i;
const MAX_STRING = 300;

export function redact(value: unknown, depth = 0): unknown {
  if (value == null) return value;
  if (depth > 5) return "[depth]";
  if (typeof value === "string") return value.length > MAX_STRING ? value.slice(0, MAX_STRING) + "…[truncated]" : value;
  if (Array.isArray(value)) return value.slice(0, 50).map((v) => redact(v, depth + 1));
  if (value instanceof Error) return { name: value.name, message: value.message };
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = REDACT_KEYS.test(k) ? "[REDACTED]" : redact(v, depth + 1);
    }
    return out;
  }
  return value;
}

function current(): number {
  const lvl = (process.env.LOG_LEVEL ?? "info") as Level;
  return LEVELS[lvl] ?? LEVELS.info;
}

export const sink: { write: (line: string) => void } = { write: (line) => void process.stdout.write(line + "\n") };

function log(level: Exclude<Level, "silent">, msg: string, fields?: Record<string, unknown>) {
  if (LEVELS[level] < current()) return;
  sink.write(JSON.stringify({ ts: new Date().toISOString(), level, msg, ...(redact(fields) as object) }));
}

export const logger = {
  debug: (m: string, f?: Record<string, unknown>) => log("debug", m, f),
  info: (m: string, f?: Record<string, unknown>) => log("info", m, f),
  warn: (m: string, f?: Record<string, unknown>) => log("warn", m, f),
  error: (m: string, f?: Record<string, unknown>) => log("error", m, f),
};
