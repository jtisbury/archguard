import { getConfig } from "./config";

/**
 * Billing gate stub. When ENTERPRISE_PILOT_MODE is on, all Stripe-style limits are
 * bypassed. Tenant isolation is unaffected by this flag.
 */
export const FREE_TIER_MONTHLY_EVALS = 50;

export interface OrgBillingState {
  planTier: string;
  monthlyEvalCount: number;
}

export function canRunEvaluation(org: OrgBillingState, pilotMode = getConfig().ENTERPRISE_PILOT_MODE): boolean {
  if (pilotMode) return true;
  if (org.planTier !== "free") return true;
  return org.monthlyEvalCount < FREE_TIER_MONTHLY_EVALS;
}
