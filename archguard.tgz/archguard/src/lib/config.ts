import { z } from "zod";

const bool = z
  .enum(["true", "false", "1", "0", ""])
  .optional()
  .transform((v) => v === "true" || v === "1");

const csv = (def: string) =>
  z
    .string()
    .default(def)
    .transform((s) =>
      s
        .split(",")
        .map((x) => x.trim())
        .filter(Boolean),
    );

const schema = z.object({
  DATABASE_URL: z.string().default("postgres://archguard_app:archguard_app@localhost:5432/archguard"),
  DATABASE_OWNER_URL: z.string().default("postgres://postgres:postgres@localhost:5432/archguard"),
  REDIS_URL: z.string().default("redis://localhost:6379"),
  TOKEN_ENCRYPTION_KEY: z
    .string()
    .min(1, "TOKEN_ENCRYPTION_KEY is required")
    .refine((v) => Buffer.from(v, "base64").length === 32, "TOKEN_ENCRYPTION_KEY must be 32 bytes, base64 encoded"),
  APP_BASE_URL: z.string().default("http://localhost:3000"),
  WEBHOOK_PUBLIC_URL: z.string().default("http://localhost:3000"),
  ENTERPRISE_PILOT_MODE: bool,
  AUTH_OIDC_GROUPS_CLAIM: z.string().default("groups"),
  AUTH_ROLE_ADMIN_GROUPS: csv("archguard-admins"),
  AUTH_ROLE_ARCHITECT_GROUPS: csv("archguard-architects"),
  AUTH_ROLE_VIEWER_GROUPS: csv("archguard-viewers"),
  AUTH_DEFAULT_ORG_SLUG: z.string().default("pilot"),
  LLM_PROVIDER: z.enum(["openai-compatible", "bedrock"]).default("openai-compatible"),
  LLM_MODEL: z.string().default(""),
  OPENAI_BASE_URL: z.string().default(""),
  OPENAI_API_KEY: z.string().default(""),
  AWS_REGION: z.string().default("us-east-1"),
  MAX_DIFF_BYTES: z.coerce.number().int().positive().default(200_000),
  MAX_LLM_INPUT_TOKENS: z.coerce.number().int().positive().default(60_000),
  LOG_LEVEL: z.enum(["debug", "info", "warn", "error", "silent"]).default("info"),
});

export type Config = z.infer<typeof schema>;

export function parseConfig(env: Record<string, string | undefined>): Config {
  const cleaned: Record<string, string | undefined> = {};
  for (const [k, v] of Object.entries(env)) {
    // Strip inline comments left in .env values ("value   # comment").
    cleaned[k] = typeof v === "string" ? v.replace(/\s+#.*$/, "").trim() : v;
  }
  const res = schema.safeParse(cleaned);
  if (!res.success) {
    const msg = res.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(`Invalid configuration: ${msg}`);
  }
  return res.data;
}

let cached: Config | undefined;
export function getConfig(): Config {
  cached ??= parseConfig(process.env);
  return cached;
}
export function resetConfigForTests() {
  cached = undefined;
}
