import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

/**
 * AES-256-GCM vault. Payload format: "v1:<iv b64>:<tag b64>:<ciphertext b64>".
 * The version prefix allows key/format rotation later.
 */
const VERSION = "v1";

function keyFrom(b64: string): Buffer {
  const key = Buffer.from(b64, "base64");
  if (key.length !== 32) throw new Error("Vault key must be 32 bytes (base64)");
  return key;
}

export function encrypt(plaintext: string, keyB64: string = process.env.TOKEN_ENCRYPTION_KEY ?? ""): string {
  const key = keyFrom(keyB64);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [VERSION, iv.toString("base64"), tag.toString("base64"), ct.toString("base64")].join(":");
}

export function decrypt(payload: string, keyB64: string = process.env.TOKEN_ENCRYPTION_KEY ?? ""): string {
  const parts = payload.split(":");
  if (parts.length !== 4 || parts[0] !== VERSION) throw new Error("Unsupported vault payload");
  const [, ivB64, tagB64, ctB64] = parts as [string, string, string, string];
  const key = keyFrom(keyB64);
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  try {
    return Buffer.concat([decipher.update(Buffer.from(ctB64, "base64")), decipher.final()]).toString("utf8");
  } catch {
    throw new Error("Vault decryption failed (wrong key or tampered data)");
  }
}
