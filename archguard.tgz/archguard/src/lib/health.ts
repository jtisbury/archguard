export interface HealthDeps {
  pingDb: () => Promise<boolean>;
  pingRedis: () => Promise<boolean>;
}

export async function getHealth(deps: HealthDeps) {
  const [db, redis] = await Promise.all([deps.pingDb(), deps.pingRedis()]);
  return { status: db && redis ? "ok" : "degraded", db: db ? "up" : "down", redis: redis ? "up" : "down" };
}
