import IORedis, { type Redis } from "ioredis";
import { getConfig } from "./config";

let client: Redis | undefined;

/** Shared Redis connection. maxRetriesPerRequest=null is required by BullMQ workers. */
export function getRedis(): Redis {
  client ??= new IORedis(getConfig().REDIS_URL, { maxRetriesPerRequest: null, lazyConnect: false });
  return client;
}

/** Rejects after ms. Redis commands otherwise wait indefinitely while the server is down. */
export function withTimeout<T>(p: Promise<T>, ms: number, label = "operation"): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      },
    );
  });
}

export async function pingRedis(timeoutMs = 2000): Promise<boolean> {
  try {
    return (await withTimeout(getRedis().ping(), timeoutMs, "redis ping")) === "PONG";
  } catch {
    return false;
  }
}
