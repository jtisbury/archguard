import type { AdrDraftData } from "../llm/types";

export function slugify(title: string): string {
  return (
    title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "decision"
  );
}

export const pad4 = (n: number) => String(n).padStart(4, "0");

export function adrFilePath(dir: string, n: number, title: string): string {
  return `${dir.replace(/^\/+|\/+$/g, "")}/${pad4(n)}-${slugify(title)}.md`;
}

/** Renders the MADR sections: Context, Decision Drivers, Considered Options, Decision Outcome, Consequences. */
export function renderMadr(n: number, d: AdrDraftData, date: Date = new Date()): string {
  const list = (xs: string[]) => xs.map((x) => `* ${x}`).join("\n");
  const options = d.consideredOptions
    .map((o) => {
      const pros = o.pros.map((p) => `  * Good, because ${p}`).join("\n");
      const cons = o.cons.map((c) => `  * Bad, because ${c}`).join("\n");
      return [`### ${o.name}`, "", pros, cons].filter((x) => x !== "").join("\n");
    })
    .join("\n\n");
  return [
    `# ${pad4(n)}. ${d.title}`,
    "",
    `* Status: proposed`,
    `* Date: ${date.toISOString().slice(0, 10)}`,
    "",
    "## Context and Problem Statement",
    "",
    d.context,
    "",
    "## Decision Drivers",
    "",
    list(d.decisionDrivers),
    "",
    "## Considered Options",
    "",
    options,
    "",
    "## Decision Outcome",
    "",
    d.decisionOutcome,
    "",
    "## Consequences",
    "",
    list(d.consequences),
    "",
  ].join("\n");
}
