import { and, eq, max, sql } from "drizzle-orm";
import { withTenant, type Db } from "../db/client";
import { adrDrafts } from "../db/schema";
import type { AdrDraftData } from "../llm/types";
import { renderMadr } from "./madr";

export function maxAdrNumberFromFiles(names: string[]): number {
  let m = 0;
  for (const n of names) {
    const r = /^(\d{1,6})[-_]/.exec(n);
    if (r) m = Math.max(m, parseInt(r[1]!, 10));
  }
  return m;
}

export interface SavedDraft {
  id: string;
  adrNumber: number;
  title: string;
}

/**
 * Creates (or refreshes) the pending ADR draft for a PR. The number is reserved inside a
 * transaction holding a per-repository advisory lock, so concurrent evaluations cannot collide.
 * A re-run for the same PR updates its pending draft instead of consuming another number.
 */
export async function saveAdrDraft(
  db: Db,
  orgId: string,
  input: { repoId: string; prId: number; evaluationId: string; data: AdrDraftData; existingFileNames: string[]; now?: Date },
): Promise<SavedDraft> {
  return withTenant(db, orgId, async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${input.repoId}))`);

    const [pending] = await tx
      .select()
      .from(adrDrafts)
      .where(and(eq(adrDrafts.repoId, input.repoId), eq(adrDrafts.prId, input.prId), eq(adrDrafts.status, "pending")));
    if (pending) {
      const [row] = await tx
        .update(adrDrafts)
        .set({ title: input.data.title, markdownContent: renderMadr(pending.adrNumber, input.data, input.now), evaluationId: input.evaluationId })
        .where(eq(adrDrafts.id, pending.id))
        .returning();
      return { id: row!.id, adrNumber: row!.adrNumber, title: row!.title };
    }

    const [{ maxNum } = { maxNum: null }] = await tx
      .select({ maxNum: max(adrDrafts.adrNumber) })
      .from(adrDrafts)
      .where(eq(adrDrafts.repoId, input.repoId));
    const next = Math.max(maxNum ?? 0, maxAdrNumberFromFiles(input.existingFileNames)) + 1;
    const [row] = await tx
      .insert(adrDrafts)
      .values({
        orgId,
        repoId: input.repoId,
        evaluationId: input.evaluationId,
        prId: input.prId,
        adrNumber: next,
        title: input.data.title,
        markdownContent: renderMadr(next, input.data, input.now),
      })
      .returning();
    return { id: row!.id, adrNumber: row!.adrNumber, title: row!.title };
  });
}
