import { NextResponse } from "next/server";
import { getDb } from "../db/client";
import { logger } from "../lib/logger";
import { getRedis, withTimeout } from "../lib/redis";
import { bullQueue } from "../queue";
import { ingestWebhook } from "./ingest";
import { rateLimit } from "./ratelimit";

/** Providers expect a quick answer. If Redis/Postgres are unreachable, fail fast with 503 so they retry. */
const DEADLINE_MS = 2000;

/** Shared HTTP handler for the Bitbucket and GitHub webhook routes. */
export async function handleWebhook(req: Request): Promise<Response> {
  // Behind Caddy the client address is the first X-Forwarded-For entry.
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  try {
    if (!(await withTimeout(rateLimit(getRedis(), `ip:${ip}`), DEADLINE_MS, "rate limit"))) {
      return NextResponse.json({ error: "rate limited" }, { status: 429 });
    }
    const rawBody = await req.text(); // raw body as text: required for HMAC verification
    const result = await withTimeout(
      ingestWebhook({ rawBody, headers: req.headers }, { db: getDb(), dedupe: getRedis(), queue: bullQueue }),
      DEADLINE_MS,
      "webhook ingest",
    );
    return NextResponse.json(result.body, { status: result.status });
  } catch (e) {
    logger.error("webhook ingest unavailable", { error: e });
    return NextResponse.json({ error: "temporarily unavailable" }, { status: 503 });
  }
}
