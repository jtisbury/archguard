import { createHmac, timingSafeEqual } from "node:crypto";

/** Computes the Bitbucket header value for a body: "sha256=<hex>". */
export function signBody(rawBody: string | Buffer, secret: string): string {
  return "sha256=" + createHmac("sha256", secret).update(rawBody).digest("hex");
}

/**
 * Verifies X-Hub-Signature over the RAW body (never a re-serialized one) in constant time.
 * Only sha256 is accepted.
 */
export function verifySignature(rawBody: string | Buffer, header: string | null | undefined, secret: string): boolean {
  if (!header || !secret) return false;
  const m = /^sha256=([0-9a-f]{64})$/i.exec(header.trim());
  if (!m) return false;
  const expected = Buffer.from(signBody(rawBody, secret).slice("sha256=".length), "hex");
  const given = Buffer.from(m[1]!, "hex");
  return given.length === expected.length && timingSafeEqual(given, expected);
}
