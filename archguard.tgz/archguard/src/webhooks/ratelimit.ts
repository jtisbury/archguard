export interface CounterStore {
  incr(key: string): Promise<number>;
  expire(key: string, seconds: number): Promise<number>;
}

export const RATE_LIMIT_PER_MINUTE = 300;

/** Fixed-window limiter (per key, per minute). Returns false when the caller is over the limit. */
export async function rateLimit(store: CounterStore, key: string, limit = RATE_LIMIT_PER_MINUTE, now = Date.now()): Promise<boolean> {
  const window = Math.floor(now / 60_000);
  const k = `archguard:rl:${key}:${window}`;
  const n = await store.incr(k);
  if (n === 1) await store.expire(k, 70);
  return n <= limit;
}
