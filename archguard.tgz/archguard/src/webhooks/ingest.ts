import { sql } from "drizzle-orm";
import { rowsOf, type Db } from "../db/client";
import { logger } from "../lib/logger";
import { decrypt } from "../lib/vault";
import type { DedupeStore, EvaluateQueue } from "../queue/types";
import { verifySignature } from "./signature";

export const DEDUPE_TTL_SECONDS = 24 * 60 * 60;
export const HANDLED_EVENTS = new Set(["pullrequest:created", "pullrequest:updated"]);
/** GitHub pull_request actions that change the code under review. */
export const GITHUB_HANDLED_ACTIONS = new Set(["opened", "synchronize", "reopened", "ready_for_review"]);

export interface IngestInput {
  rawBody: string;
  headers: { get(name: string): string | null };
}
export interface IngestResult {
  status: 202 | 400 | 401 | 503;
  body: Record<string, unknown>;
}
export interface IngestDeps {
  db: Db;
  dedupe: DedupeStore;
  queue: EvaluateQueue;
}

interface Candidate {
  org_id: string;
  repo_id: string;
  encrypted_webhook_secret: string | null;
  is_active: boolean;
}

interface Delivery {
  provider: "bitbucket" | "github";
  hookId: string | null;
  signature: string | null;
  requestId: string | null;
  event: string;
}

/** Normalizes provider-specific delivery headers. GitHub is detected by X-GitHub-Event. */
export function readDelivery(h: IngestInput["headers"]): Delivery {
  if (h.get("x-github-event")) {
    return {
      provider: "github",
      hookId: h.get("x-github-hook-id"),
      signature: h.get("x-hub-signature-256"), // never the SHA-1 X-Hub-Signature
      requestId: h.get("x-github-delivery"),
      event: h.get("x-github-event") ?? "",
    };
  }
  return {
    provider: "bitbucket",
    hookId: h.get("x-hook-uuid"),
    signature: h.get("x-hub-signature"),
    requestId: h.get("x-request-uuid"),
    event: h.get("x-event-key") ?? "",
  };
}

/** Pull request number from an authenticated payload, or null if this delivery should be ignored. */
function prNumberFor(d: Delivery, rawBody: string): number | null {
  let payload: { pullrequest?: { id?: number }; action?: string; pull_request?: { number?: number; draft?: boolean } };
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return null;
  }
  if (d.provider === "bitbucket") {
    if (!HANDLED_EVENTS.has(d.event)) return null;
    const id = payload.pullrequest?.id;
    return Number.isInteger(id) ? id! : null;
  }
  if (d.event !== "pull_request" || !GITHUB_HANDLED_ACTIONS.has(payload.action ?? "")) return null;
  const n = payload.pull_request?.number;
  return Number.isInteger(n) ? n! : null;
}

/**
 * Order matters (steering): authenticate the raw body -> parse -> dedupe -> enqueue -> 202.
 * No LLM or SCM API calls happen here.
 */
export async function ingestWebhook(input: IngestInput, deps: IngestDeps): Promise<IngestResult> {
  const d = readDelivery(input.headers);

  // 1. Authenticate. Identical 401 for unknown hook, missing and bad signatures.
  if (!d.hookId || !d.signature) return { status: 401, body: { error: "unauthorized" } };
  const found = await deps.db.execute(sql`select * from lookup_repo_for_webhook(${d.hookId})`);
  const match = rowsOf<Candidate>(found).find((c) => {
    if (!c.encrypted_webhook_secret) return false;
    try {
      return verifySignature(input.rawBody, d.signature, decrypt(c.encrypted_webhook_secret));
    } catch {
      return false;
    }
  });
  if (!match) return { status: 401, body: { error: "unauthorized" } };

  // 2. Only react to pull request changes on active repositories (GitHub "ping" etc. are ignored).
  if (!match.is_active) return { status: 202, body: { ignored: true } };
  const prId = prNumberFor(d, input.rawBody);
  if (prId == null) return { status: 202, body: { ignored: true } };
  if (!d.requestId) return { status: 400, body: { error: "missing delivery id" } };

  // 3. Idempotency: first delivery wins; retries/redeliveries reuse the same delivery id.
  const dedupeKey = `archguard:webhook:${d.provider}:${d.requestId}`;
  const first = await deps.dedupe.set(dedupeKey, "1", "EX", DEDUPE_TTL_SECONDS, "NX");
  if (first !== "OK") return { status: 202, body: { duplicate: true } };

  try {
    await deps.queue.enqueue({ orgId: match.org_id, repoId: match.repo_id, prId, eventKey: d.event, requestUuid: d.requestId });
  } catch (e) {
    await deps.dedupe.del(dedupeKey); // let the provider's retry succeed
    logger.error("webhook enqueue failed", { error: e });
    return { status: 503, body: { error: "queue unavailable" } };
  }
  logger.info("webhook accepted", { provider: d.provider, repoId: match.repo_id, prId, event: d.event });
  return { status: 202, body: { accepted: true } };
}
