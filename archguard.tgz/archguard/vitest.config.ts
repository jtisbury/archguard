import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    testTimeout: 30000,
    hookTimeout: 60000,
    env: {
      TOKEN_ENCRYPTION_KEY: Buffer.alloc(32, 7).toString("base64"),
      ENTERPRISE_PILOT_MODE: "true",
      LOG_LEVEL: "silent",
    },
  },
});
