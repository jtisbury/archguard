---
title: Security and data handling
order: 12
summary: How ArchGuard protects source code, credentials and tenant data.
---

## Source code is never stored

- The diff is downloaded from Bitbucket into the worker's memory, filtered, sent to your configured language model, and then discarded.
- ArchGuard does not save the diff or any file contents. It saves the outcome, violations (rule, file path, line, a short explanation and fix), token counts and ADR Markdown.
- Logs never contain diffs. Fields with names such as `diff`, `token`, `secret` and `content` are replaced by `[REDACTED]`, and long strings are cut.
- Error messages from Bitbucket and the model include the status code only, never the response body.

## Language model

The model is reached through a pluggable connection, so you can use the endpoint your company approved:

- **AWS Bedrock** (for example Anthropic Claude), selected with `LLM_PROVIDER=bedrock`.
- **Azure OpenAI or any OpenAI-compatible gateway**, selected with `LLM_PROVIDER=openai-compatible` and `OPENAI_BASE_URL`.

Answers must follow a strict JSON schema and are validated. The prompt marks the diff and the pull request title as untrusted data, and ArchGuard discards anything that references an unknown rule or a file that is not in the diff. Text inside a pull request therefore cannot change a result by giving instructions to the model.

## Credentials

- Bitbucket tokens and webhook signing secrets are encrypted with AES-256-GCM. The key is `TOKEN_ENCRYPTION_KEY`, which stays in the environment.
- The Bitbucket token is never shown after you save it.
- Webhooks must carry a valid HMAC-SHA256 signature over the exact request body: `X-Hub-Signature` from Bitbucket, `X-Hub-Signature-256` from GitHub. GitHub's older SHA-1 header is never accepted. Anything else gets `401`.
- Sign-in uses your company single sign-on. Sessions last 8 hours.

## Tenant isolation

All organization data lives in PostgreSQL tables protected by row-level security. The application connects with a restricted database role that cannot bypass those policies, and every query runs inside a transaction that names the organization. Without that, a query returns nothing. Automated tests check this for every table.

## Rate limiting and repeats

The webhook endpoint limits requests per source address and ignores repeated deliveries of the same request.

## Hosting

When you host ArchGuard yourself, you are responsible for the server. The [cloud deployment](cloud-deployment#security-notes) setup exposes only HTTPS, keeps the database and Redis off the internet, and gives database owner credentials only to the migration task. Host it only where the code you connect is allowed to go.

## Related

- [How evaluation works](how-evaluation-works)
- [Roles and permissions](roles-and-permissions)
