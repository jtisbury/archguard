---
title: Pilot mode and shadow mode
order: 11
summary: Roll out gradually with ENTERPRISE_PILOT_MODE and without blocking merges for the first week.
---

## ENTERPRISE_PILOT_MODE

Set `ENTERPRISE_PILOT_MODE=true` in the environment during internal rollout.

- Billing limits are **bypassed**, so evaluations are never refused for plan reasons.
- Everything else is unchanged. Data isolation between organizations stays fully enforced, so the same build can later run as a multi-customer service.

**Settings** shows whether the mode is on. Turning it off applies plan limits to organizations on the `free` tier (50 evaluations). Organizations on other tiers, including the default `pilot` tier, are not limited.

## Shadow mode: advise first, block later

In shadow mode, ArchGuard comments and drafts ADRs but cannot block anyone, because Bitbucket is not set to require the check.

**Week 1 (shadow mode)**

1. Do not make the ArchGuard check required. In Bitbucket, leave **Require successful builds to merge** unchecked in the repository's **Branch restrictions**. In GitHub, do not add **ArchGuard** to a **Require status checks to pass** rule.
2. Enable ArchGuard on a few repositories.
3. Review each failed result with the team. Note false positives and misses.
4. Adjust rules: tighten the instructions, narrow the target patterns, or lower the severity to *warning*. See [Guardrail rules](guardrail-rules#tuning-rules).

**After you trust the results**

1. Check the dashboard for the compliance rate and drift alerts.
2. Require the check for merging into your main branches. In Bitbucket, require a successful build. In GitHub, follow [Require the check before merging](connect-github#require-the-check-before-merging).
3. Tell teams what the **failed** check means and how to fix it. See [Build statuses and PR comments](build-statuses-and-comments#fixing-a-failed-check).

Neutral results never block, so a model outage or a very large pull request does not stop a release even when the check is required.
