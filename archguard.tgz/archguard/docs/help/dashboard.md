---
title: Using the dashboard
order: 10
summary: Compliance rates, drift alerts, pending ADR drafts and the approved ADR timeline.
---

The dashboard is the home page. Everyone with a role can see it.

## Summary cards

- **Overall compliance (30 days)**: passed pull requests divided by passed plus failed pull requests, across all repositories.
- **Pending ADR drafts**: drafts waiting for review. Select the number to open the list.
- **Drift alerts**: how many alerts are active.

## How compliance is calculated

Compliance looks at the **latest evaluation of each pull request** in the last 30 days. A pull request that failed and was then fixed counts as passed. Neutral results (too large, could not evaluate, errors) are shown separately and are **not** counted for or against compliance. A repository with no decided pull requests shows **n/a**.

## Repositories table

One row per repository: whether it is enabled, and the number of passed, failed and neutral pull requests, plus its compliance rate.

## Drift alerts

An alert appears when the **same rule** was violated in **three or more different pull requests** of one repository within the last 14 days. It points at a pattern, such as repeated migrations that drop columns. Consider a team conversation, a clearer rule, or an ADR.

## Recent failing pull requests

The latest pull requests whose newest evaluation failed, with repository, number and title.

## Approved ADR timeline

Every committed ADR with its date, number, repository and file path. Type in the search box and select **Search** to filter by title or content. Select an entry to read it. See [Review and commit ADRs](adr-workflow).
