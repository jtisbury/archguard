---
title: Enable repositories and webhooks
order: 4
summary: Turn ArchGuard on for a repository, set its triggers and ADR folder.
---

After connecting [Bitbucket Cloud](connect-bitbucket) or [GitHub](connect-github), each repository is listed under **Settings** and is disabled until you enable it.

## Enable

Select **Enable** next to a repository. ArchGuard then:

1. Generates a random signing secret and stores it encrypted.
2. Registers a webhook signed with that secret: in Bitbucket for **pull request created** and **pull request updated**; in GitHub for **Pull requests** events.
3. Reads the ADR folder (default `docs/adr`) on the repository's main branch and remembers the titles of existing ADRs as baseline context.

Enabling again replaces the webhook, so only one exists. The secret changes each time.

## Disable

Select **Disable**. The webhook is removed from Bitbucket and the secret is deleted. Existing results stay in the dashboard.

## Triage settings

Open **Triage settings** under a repository to edit:

- **Structural triggers**: glob patterns, one per line. Only pull requests that change at least one matching file are evaluated. The defaults cover Terraform, Dockerfiles, docker-compose files, migrations, OpenAPI and Swagger files, Protobuf and GraphQL schemas, and the common dependency files.
- **ADR directory**: where ADRs live in the repository. Default `docs/adr`.

Add your own domain boundary paths here, for example `services/**` or `src/domain/**`. Rules that look at ordinary source code, such as *No Cross-Domain Database Coupling*, only run on pull requests that also change a file matching a trigger. See [How evaluation works](how-evaluation-works#triage-structural-triggers).

## Checking that it works

1. Open a pull request that edits `README.md` only. The **ArchGuard** check should turn green with "No architectural impact detected".
2. Open one that edits a `.tf` file or `package.json`. The check shows *in progress*, then a result.

If nothing appears, see [Troubleshooting and FAQ](troubleshooting-faq#no-check-appears-on-the-pull-request).
