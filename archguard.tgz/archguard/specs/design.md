# ArchGuard for Bitbucket: Design

## 1. Architecture

```mermaid
flowchart LR
  BB[Bitbucket Cloud] -->|webhook| API["Next.js route: verify HMAC, dedupe, 202"]
  API --> Q[(Redis / BullMQ)]
  Q --> W["Worker: evaluate-bitbucket-pr"]
  W --> P["IBitbucketProvider / BitbucketCloudAdapter"]
  W --> L["ILlmProvider: Bedrock / OpenAI-compatible"]
  W --> DB[("Postgres + RLS")]
  UI["Dashboard + OIDC"] --> DB
  UI -->|"Approve and commit ADR"| P
  P --> BB
```

## 2. Pipeline

```text
Webhook (pullrequest:created / updated)
  -> look up repo by X-Hook-UUID, verify X-Hub-Signature over the raw body   (401 on failure)
  -> ignore other events / inactive repos                                     (202)
  -> Redis SET NX EX 86400 on X-Request-UUID                                  (duplicate: 202, dropped)
  -> BullMQ evaluate-bitbucket-pr, 202
Worker
  1. INPROGRESS build status (key ARCHGUARD, refname = source branch)
  2. diffstat (paginated)
  3. structural trigger match; 0 matches -> SUCCESSFUL "No architectural impact detected", stop
  4. fetch diff, enabled rules, existing ADR file names
  5. keep only relevant files; size/token caps (too large -> neutral)
  6. LLM structured call -> violations[] + optional MADR adr_draft (validated; one retry; then neutral)
  7. persist evaluation (+ ADR draft); purge diff
  8. upsert the PR comment; post final status (FAILED if any blocking, else SUCCESSFUL)
Failure after final retry -> neutral SUCCESSFUL status + neutral evaluation row
```

## 3. Components

| Area | Module | Notes |
|---|---|---|
| Tenancy | `src/db/client.ts` `withTenant` | Transaction + `set_config('app.org_id', …, true)`. App connects as `archguard_app` (no superuser, no BYPASSRLS, FORCE RLS). |
| Cross-tenant lookups | SQL functions `lookup_repo_for_webhook`, `lookup_org_id_by_slug` | `SECURITY DEFINER`, minimal columns, granted only to the app role. |
| Vault | `src/lib/vault.ts` | `v1:<iv>:<tag>:<ct>` AES-256-GCM. |
| Auth | `src/auth/*` | Auth.js generic OIDC; roles from group claims at sign-in; `requirePrincipal`. |
| SCM | `src/bitbucket/*` | `IBitbucketProvider`; `BitbucketCloudAdapter`; Data Center stub. |
| Ingest | `src/webhooks/*` | Signature, dedupe, rate limit. |
| Queue/worker | `src/queue/*`, `src/worker/*` | BullMQ, 4 attempts, exponential backoff. |
| LLM | `src/llm/*` | `ILlmProvider`; OpenAI-compatible (also Azure) and Bedrock (forced tool use). |
| ADR | `src/adr/*`, `src/services/adrs.ts` | MADR renderer, advisory-lock numbering, row-locked approve/commit. |
| Help | `docs/help`, `src/help/*`, `/help` | Markdown rendered in the app, with search. |

## 4. Data model

Seven tables as specified, with these implementation details:

- `organizations`: no `webhook_secret` column. Secrets are per repository (`repositories.encrypted_webhook_secret`), because each webhook has its own secret.
- `users`: global identity (not tenant scoped). `organization_members` carries the tenant-scoped role.
- `repositories`: adds `encrypted_webhook_secret`, `baseline_adr_titles`.
- `pr_evaluations`: adds `outcome_reason`, `comment_id`, `request_uuid` (unique per repo, so retries do not duplicate rows).
- `adr_drafts`: adds `pr_id`, `committed_path`; unique `(repo_id, adr_number)`.
- Creating organizations is an owner-role action (seed script); the app role cannot insert or delete organizations.

## 5. Key decisions

- **Webhook secret lookup by `X-Hook-UUID`.** The body is untrusted until verified, so the secret cannot be found from the payload.
- **Neutral outcomes never block a merge.** They post `SUCCESSFUL` with an explanatory description.
- **Severity is deterministic.** The evaluator takes severity from the rule, not from the model, and drops violations for unknown rules or files not in the diff.
- **Prompt-injection stance.** The diff and PR title are marked untrusted in the system prompt, output is schema constrained, and a violation can only reference known rules and real files.
- **ADR numbering.** Next number = max(files on target branch, existing drafts) + 1, reserved under `pg_advisory_xact_lock`. A collision at commit time renumbers.
- **Source-code rules need triggers.** Triage skips PRs with no structural change, so rules over ordinary source (for example No Cross-Domain Database Coupling) apply only when the repository lists its domain paths as structural triggers.

## 6. GitHub connector

| Concern | Bitbucket Cloud | GitHub.com |
|---|---|---|
| Credential | Workspace Access Token | Fine-grained PAT (one resource owner) |
| Owner | workspace slug | user or organization login |
| Webhook route | `/api/webhooks/bitbucket` | `/api/webhooks/github` |
| Hook lookup header | `X-Hook-UUID` | `X-GitHub-Hook-ID` |
| Signature | `X-Hub-Signature` | `X-Hub-Signature-256` |
| Delivery id (dedupe) | `X-Request-UUID` | `X-GitHub-Delivery` |
| Events | `pullrequest:created`, `pullrequest:updated` | `pull_request` (opened, synchronize, reopened, ready_for_review) |
| Changed files | `/pullrequests/{id}/diffstat` | `/pulls/{n}/files` (Link pagination) |
| Diff | `/pullrequests/{id}/diff` | `/pulls/{n}` with `Accept: application/vnd.github.diff`; 406 means too large |
| Status | build status key `ARCHGUARD` | commit status context `ArchGuard` |
| Comment | PR comment (PUT to update) | issue comment (PATCH to update) |
| ADR commit | `/src` multipart | `PUT /contents/{path}` (base64) |

Both adapters implement `IScmProvider` (`src/scm/provider.ts`). Migration `0002` renames the Bitbucket columns to `scm_provider`, `scm_owner`, `scm_base_url` and `scm_repo_id`, and adds `repositories.scm_provider`, so repositories from a previous provider keep their history while Settings shows only the current provider's repositories.

## 7. Cloud deployment

`docker-compose.prod.yml` runs postgres, redis (AOF, `noeviction` for BullMQ), app, worker and Caddy on one VM. Images build natively on arm64. Caddy terminates TLS with Let's Encrypt for a DuckDNS name. Only the `migrate` task receives database owner credentials; app and worker use `archguard_app`. Provider-neutral scripts live in `deploy/vm/`; `setup-vm.sh` detects the host firewall (active `ufw`, `iptables` REJECT/DROP rules, or none) and adds swap below 6 GB of memory. `scripts/check-compose.ps1` statically checks the credential and port rules.

## 8. Out of scope

Data Center adapter, GitHub Apps and GitHub Enterprise Server, Stripe integration (only the gate stub), monthly counter reset, managed cloud databases, multi-VM high availability.
