# ArchGuard for Bitbucket: Requirements

## 1. Product overview

ArchGuard is an automated architectural governance and ADR platform for Bitbucket organizations. This build targets **Bitbucket Cloud** (Workspace Access Token). Data Center is an interface stub only.

When a pull request (PR) changes significant structural components (infrastructure, database schemas, API contracts, dependencies, service boundaries), ArchGuard:

1. evaluates the diff against enterprise guardrail rules,
2. sets the Bitbucket commit build status to gate the merge,
3. posts one summary comment on the PR,
4. drafts a Markdown Any Decision Record (MADR) ADR for one-click approval and commit back to the repository.

## 2. Functional requirements (EARS)

### 2.1 Connection and onboarding
- **REQ-1.1** WHEN an Organization Admin configures a Bitbucket connection (Cloud Workspace Access Token), THE SYSTEM SHALL validate the credentials, store the token encrypted, and sync accessible repositories within 15 seconds.
- **REQ-1.2** WHEN a repository is enabled, THE SYSTEM SHALL register the `pullrequest:created` and `pullrequest:updated` webhooks with a generated HMAC signing secret and scan the ADR directory (default `docs/adr`) for existing ADRs to establish baseline context.

### 2.2 Structural diff triage
- **REQ-2.1** WHEN a `pullrequest:created` or `pullrequest:updated` webhook is received, THE SYSTEM SHALL fetch the PR diffstat and filter the changed paths against the repository's configurable structural triggers (for example `*.tf`, `Dockerfile`, `docker-compose*`, `**/migrations/**`, `openapi.yaml`, `package.json`, `pom.xml`, `build.gradle`, `go.mod`, or domain boundary paths).
- **REQ-2.2** IF a PR contains zero files matching structural triggers, THEN THE SYSTEM SHALL post a `SUCCESSFUL` build status with the description "ArchGuard: No architectural impact detected" and finish without invoking the LLM.

### 2.3 Guardrail policy engine
- **REQ-2.3** WHEN a PR triggers evaluation, THE SYSTEM SHALL load the organization's enabled guardrail rules.
- **REQ-2.4** THE SYSTEM SHALL evaluate the filtered diff and the existing ADR titles against those rules using an LLM structured-output pipeline (AWS Bedrock or an OpenAI-compatible enterprise endpoint) and return `violations` (severity `blocking` or `warning`, file path, line number, remediation guidance).
- **REQ-2.5** IF one or more `blocking` violations are found, THEN THE SYSTEM SHALL post a `FAILED` build status on the source commit and a structured summary comment on the PR.

### 2.4 ADR drafting and commit
- **REQ-2.6** WHEN a PR introduces a new architectural pattern, external dependency, database schema change or service contract and contains no ADR file, THE SYSTEM SHALL draft an ADR in MADR format (Context, Decision Drivers, Considered Options, Decision Outcome, Consequences).
- **REQ-2.7** THE SYSTEM SHALL show the draft in the dashboard and link to it from the PR comment.
- **REQ-2.8** WHEN an Architect or Admin selects "Approve & Commit ADR", THE SYSTEM SHALL commit `docs/adr/NNNN-title.md` to the PR source branch (or the target branch if the PR is already merged) using the Bitbucket `/src` `multipart/form-data` API.

### 2.5 Dashboard, RBAC and enterprise mode
- **REQ-2.9** THE SYSTEM SHALL provide a dashboard with guardrail compliance by repository, drift alerts, pending ADR drafts and a searchable timeline of approved ADRs.
- **REQ-2.10** THE SYSTEM SHALL enforce RBAC with three roles: `admin` (connection, webhooks, settings), `architect` (guardrail rules, approve and edit ADRs) and `viewer` (read-only). Roles are derived from IdP group claims at each sign-in.
- **REQ-2.11** THE SYSTEM SHALL support an `ENTERPRISE_PILOT_MODE` flag that bypasses billing gates while keeping full multi-tenant isolation.

## 3. Agreed additions

- **REQ-3.1** THE SYSTEM SHALL enforce a configurable maximum diff size (`MAX_DIFF_BYTES`) and input token budget (`MAX_LLM_INPUT_TOKENS`). IF either is exceeded, THEN the outcome is `neutral`, posted as a `SUCCESSFUL` status with a description containing "too large to evaluate".
- **REQ-3.2** THE SYSTEM SHALL post every build status with the fixed key `ARCHGUARD` and `refname` set to the PR source branch, so a later status overwrites an earlier one.
- **REQ-3.3** THE SYSTEM SHALL retry failed evaluations with exponential backoff. IF the final attempt fails, THEN it SHALL post a neutral `SUCCESSFUL` status so `INPROGRESS` is never left stuck.
- **REQ-3.4** THE SYSTEM SHALL document the Workspace Access Token scopes verified against a real workspace (see README, "Verified vs mocked").

## 4. Non-functional and security requirements

- All tenant tables use PostgreSQL Row-Level Security; every query runs through `withTenant`.
- Webhooks: verify `X-Hub-Signature` (`sha256=<hex>`) over the raw body with `timingSafeEqual` before parsing; return 202 quickly; no LLM work in the handler; dedupe `X-Request-UUID` with Redis `SET NX EX 86400`.
- Bitbucket tokens and webhook secrets are encrypted with AES-256-GCM.
- Diffs are held in memory only. They are never persisted or logged.
- All LLM output uses strict JSON Schema and is validated before use.

## 5. GitHub connector and cloud hosting (added)

- **REQ-4.1** WHEN an Admin connects GitHub.com with a fine-grained personal access token and a user or organization owner, THE SYSTEM SHALL validate the token, store it encrypted and sync the owner's non-archived repositories.
- **REQ-4.2** THE SYSTEM SHALL allow one source-control provider per organization. IF an Admin connects a different provider while any repository is enabled, THEN THE SYSTEM SHALL refuse and ask to disable those repositories first. Repositories from a previous provider keep their history.
- **REQ-4.3** WHEN a GitHub repository is enabled, THE SYSTEM SHALL register a `pull_request` webhook (JSON, signed secret) and evaluate the `opened`, `synchronize`, `reopened` and `ready_for_review` actions. Other actions and the `ping` event are ignored.
- **REQ-4.4** THE SYSTEM SHALL verify GitHub deliveries with `X-Hub-Signature-256`, find the secret via `X-GitHub-Hook-ID`, and dedupe on `X-GitHub-Delivery`.
- **REQ-4.5** THE SYSTEM SHALL report on GitHub through commit statuses with context `ArchGuard` (pending, success, failure), one updatable issue comment, and ADR commits through the contents API.
- **REQ-4.6** IF GitHub refuses to return a pull request diff (HTTP 406), THEN THE SYSTEM SHALL record a neutral "too large to evaluate" outcome.
- **REQ-5.1** THE SYSTEM SHALL be deployable to a single Linux VM (any Ubuntu 22.04/24.04 server; example: Hetzner CX23/CAX11/CPX22) with Docker Compose, automatic HTTPS (Caddy and Let's Encrypt), only ports 80 and 443 exposed, nightly database backups, and database owner credentials limited to the migration task.
