#!/usr/bin/env bash
# Nightly PostgreSQL backup with 14-day retention. Install with:
#   (crontab -l 2>/dev/null; echo "15 2 * * * $HOME/archguard/deploy/vm/backup.sh >> $HOME/archguard-backup.log 2>&1") | crontab -
set -euo pipefail
cd "$(dirname "$0")/../.."
mkdir -p backups
chmod 700 backups
stamp=$(date -u +%Y%m%dT%H%M%SZ)
docker compose -f docker-compose.prod.yml --env-file .env.production exec -T postgres \
  pg_dump -U postgres --format=custom archguard > "backups/archguard-$stamp.dump"
chmod 600 "backups/archguard-$stamp.dump"
find backups -name 'archguard-*.dump' -mtime +14 -delete
echo "$(date -u) backup ok: backups/archguard-$stamp.dump"
# Restore:  docker compose ... exec -T postgres pg_restore -U postgres -d archguard --clean < backups/<file>.dump
