#!/usr/bin/env bash
# Build and (re)start ArchGuard. Safe to run repeatedly: migrations only apply what is new.
# Usage (from the archguard folder):  bash deploy/vm/deploy.sh [org-slug] ["Org name"]
set -euo pipefail
cd "$(dirname "$0")/../.."

COMPOSE=(docker compose -f docker-compose.prod.yml --env-file .env.production)

if [ ! -f .env.production ]; then
  echo "Missing .env.production (copy .env.production.example and fill it in)." >&2
  exit 1
fi
if grep -Eq '^(POSTGRES_PASSWORD|APP_DB_PASSWORD|TOKEN_ENCRYPTION_KEY|AUTH_SECRET|ARCHGUARD_DOMAIN)=$' .env.production; then
  echo "Fill in POSTGRES_PASSWORD, APP_DB_PASSWORD, TOKEN_ENCRYPTION_KEY, AUTH_SECRET and ARCHGUARD_DOMAIN in .env.production first." >&2
  exit 1
fi
chmod 600 .env.production
domain=$(grep -E '^ARCHGUARD_DOMAIN=' .env.production | head -n1 | cut -d= -f2-)

echo "==> Building the image (several minutes on a 2 vCPU server)"
"${COMPOSE[@]}" build app

echo "==> Starting database and Redis"
"${COMPOSE[@]}" up -d postgres redis

echo "==> Applying migrations"
"${COMPOSE[@]}" run --rm migrate

echo "==> Creating the organization and starter rules (idempotent)"
"${COMPOSE[@]}" run --rm migrate npx tsx scripts/seed.ts "${1:-pilot}" "${2:-Pilot Organization}"

echo "==> Starting app, worker and Caddy"
"${COMPOSE[@]}" up -d app worker caddy

"${COMPOSE[@]}" ps
echo
echo "Check: curl -s https://${domain}/api/health   (expect {\"status\":\"ok\",...})"
