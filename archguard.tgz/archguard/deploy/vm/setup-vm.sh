#!/usr/bin/env bash
# One-time preparation of an Ubuntu 22.04/24.04 VM (arm64 or amd64) for ArchGuard.
# Works on Oracle Cloud, Hetzner, AWS, Azure, Google Cloud, DigitalOcean and plain Ubuntu.
# Run as a sudo-capable user (or root):  bash deploy/vm/setup-vm.sh
set -euo pipefail

SUDO=""
[ "$(id -u)" -ne 0 ] && SUDO="sudo"

. /etc/os-release
if [ "${ID:-}" != "ubuntu" ]; then
  echo "This script supports Ubuntu only (found: ${PRETTY_NAME:-unknown})." >&2
  exit 1
fi

echo "==> Installing Docker Engine and the Compose plugin (Docker's official apt repository)"
if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  echo "    Docker and Compose are already installed, skipping."
else
  $SUDO apt-get update -y
  $SUDO apt-get install -y ca-certificates curl gnupg
  $SUDO install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | $SUDO gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
  $SUDO chmod a+r /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
    | $SUDO tee /etc/apt/sources.list.d/docker.list >/dev/null
  $SUDO apt-get update -y
  $SUDO apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
if [ "$(id -u)" -ne 0 ]; then
  $SUDO usermod -aG docker "$USER"
fi

echo "==> Opening ports 80 and 443 in the host firewall (if the server has one)"
# Three cases:
#  1. ufw is active (some VPS images):                add ufw rules.
#  2. iptables INPUT has a REJECT/DROP rule (Oracle): insert ACCEPT rules before it and persist.
#  3. No host firewall (Hetzner, AWS, Azure, GCP, DigitalOcean Ubuntu images): nothing to do;
#     use the provider's cloud firewall instead.
if command -v ufw >/dev/null 2>&1 && $SUDO ufw status 2>/dev/null | grep -q "^Status: active"; then
  $SUDO ufw allow 80/tcp
  $SUDO ufw allow 443/tcp
  $SUDO ufw allow 443/udp
  echo "    ufw rules added."
else
  first_block=$($SUDO iptables -L INPUT --line-numbers -n 2>/dev/null | awk '$2=="REJECT" || $2=="DROP" {print $1; exit}')
  if [ -n "$first_block" ]; then
    for rule in "-p tcp --dport 80" "-p tcp --dport 443" "-p udp --dport 443"; do
      # shellcheck disable=SC2086
      if ! $SUDO iptables -C INPUT -m state --state NEW $rule -j ACCEPT 2>/dev/null; then
        # shellcheck disable=SC2086
        $SUDO iptables -I INPUT "$first_block" -m state --state NEW $rule -j ACCEPT
      fi
    done
    # Persist only where iptables is already managed this way; never replace ufw.
    if ! command -v netfilter-persistent >/dev/null 2>&1; then
      # "env" keeps the variable assignment working when $SUDO is empty (running as root).
      $SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y iptables-persistent
    fi
    $SUDO netfilter-persistent save
    echo "    iptables ACCEPT rules inserted before rule $first_block and saved."
  else
    echo "    No host firewall found. Open ports 80 and 443 in your provider's cloud firewall."
  fi
fi

echo "==> Adding swap if the server has less than 6 GB of memory"
mem_kb=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
if [ "$mem_kb" -lt 6000000 ] && ! $SUDO swapon --show | grep -q .; then
  $SUDO fallocate -l 2G /swapfile
  $SUDO chmod 600 /swapfile
  $SUDO mkswap /swapfile >/dev/null
  $SUDO swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || echo '/swapfile none swap sw 0 0' | $SUDO tee -a /etc/fstab >/dev/null
  echo "    2 GB swap file added (helps the image build on 4 GB servers)."
else
  echo "    Not needed."
fi

echo "==> Enabling automatic security updates"
$SUDO apt-get install -y unattended-upgrades
$SUDO dpkg-reconfigure -f noninteractive unattended-upgrades

echo
echo "Done. Log out and back in (so the docker group applies), then continue with the Help page steps."
