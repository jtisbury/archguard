#!/usr/bin/env bash
# Keeps the DuckDNS name pointing at this VM's public IP. Install with:
#   (crontab -l 2>/dev/null; echo "*/5 * * * * $HOME/archguard/deploy/vm/duckdns-update.sh >/dev/null 2>&1") | crontab -
# Reads DUCKDNS_SUBDOMAIN (without .duckdns.org) and DUCKDNS_TOKEN from ~/.duckdns (chmod 600).
# Optional on providers that give the server a fixed IP (Hetzner's primary IPv4, Elastic IPs, ...).
set -euo pipefail
# shellcheck source=/dev/null
source "$HOME/.duckdns"
# Empty ip= lets DuckDNS use the address the request comes from (the VM's public IPv4).
result=$(curl -4 -fsS --max-time 15 "https://www.duckdns.org/update?domains=${DUCKDNS_SUBDOMAIN}&token=${DUCKDNS_TOKEN}&ip=")
[ "$result" = "OK" ] || { echo "DuckDNS update failed: $result" >&2; exit 1; }
